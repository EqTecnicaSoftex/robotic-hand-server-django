class CAOExtensionManager:
    """
    This class contains methods for manipulate the CAOExtension object. CAOExtension is responsible for creating the
    CAOExtension object.

    From the CaoController object, it is possible to use all the other related methods.
    """

    def __init__(self, cao_extension):
        self.cao_extension = cao_extension

    def get_variable(self, name, option=""):
        """
        Get the variable object from the CAOExtension object.
        Args:
            name: string,
            option: string,

        Returns:
            CAOExtension Variables: Variables list
        """
        return self.cao_extension.AddVariable(name, option)

    def get_variable_names(self, option=""):
        """
        Get the variable names from the CAOExtension object.
        Args:
            option: string,

        Returns:
            CAOExtension Variables: Variables names list
        """
        return self.cao_extension.VariableNames(option)

    def execute(self, command, param=None):
        """
        Execute the command in the CAOExtension object.
        Args:
            command: string,
            param: string,

        Returns:
            CAOExtension Execute: Execute command
        """
        return self.cao_extension.Execute(command, param)

    def get_attribute(self):
        """
        Get the attribute from the CAOExtension object.
        Returns:
            CAOExtension Attribute: Attributes
        """
        return self.cao_extension.Attribute

    def get_help(self):
        """
        Get the help from the CAOExtension object.
        Returns:
            CAOExtension Help: Help
        """
        return self.cao_extension.Help

    def get_name(self):
        """
        Get the name from the CAOExtension object.
        Returns:
            CAOExtension Name: Name
        """
        return self.cao_extension.Name

    def get_tag(self):
        """
        Get the tag from the CAOExtension object.
        Returns:
            CAOExtension Tag: Tag
        """
        return self.cao_extension.Tag

    def put_tag(self, new_value):
        """
        Put the tag in the CAOExtension object.
        Args:
            new_value: new tag

        Returns:

        """
        self.cao_extension.Tag = new_value

    def get_id(self):
        """
        Get the id from the CAOExtension object.
        Returns:
            CAOExtension ID: ID
        """
        return self.cao_extension.Id

    def put_id(self, new_value):
        """
        Put the id in the CAOExtension object.
        Args:
            new_value: new id
        """
        self.cao_extension.Id = new_value

    def get_index(self):
        """
        Get the index from the CAOExtension object.
        Returns:
            CAOExtension Index: Index
        """
        return self.cao_extension.Index

    def get_variables(self):
        """
        Get the variables from the CAOExtension object.
        Returns:
            CAOExtension Variables: Variables
        """
        return self.cao_extension.Variables
