from rria_api_denso.cao.cao_controller import CAOController


class CAOWorkspace:
    """
    The CAOWorkspace class represents the workspace used to manage the controllers and the providers.

    This class contains methods for manipulate the CAOWorkspace object.

    The CAOWorkspace object is used to access the workspace methods and is related to the dispatch object.

    When instantiating this class, you create and add a workspace to the controller.

    All methods of this class are called through the cao_workspace object created in __init__().

    This class manipulates the CAOWorkspace dispatch object.
    Every method of this class is a wrapper of the CAOWorkspace dispatch object methods.
    """

    def __init__(self, cao_engine, workspace_name):
        self.cao_controller = None
        self.cao_controller_dispatch = None
        self.cao_engine = cao_engine
        self.cao_workspace = self.cao_engine.AddWorkspace(workspace_name, "")

    def get_controllers(self):
        """
        The Controllers property returns a collection of the controllers that are registered in the workspace.
        Returns:
            CAOWorkspace Controllers: Controllers list
        """
        return self.cao_workspace.Controllers

    def get_index(self):
        """
        The Index property returns the index of the workspace in the collection of the workspaces.
        Returns:
            CAOWorkspace Index: Workspace index
        """
        return self.cao_workspace.Index

    def get_name(self):
        """
        The Name property returns the name of the workspace.
        Returns:
            CAOWorkspace Name: Workspace name
        """
        return self.cao_workspace.Name

    def get_provider_names(self):
        """
        The ProviderNames property returns the collection names of the providers that are registered in the workspace.

        Returns:
            CAOWorkspace ProviderNames: Providers list
        """
        return self.cao_workspace.ProviderNames

    def add_controller(
        self, controller_name: str = "", provider_name="CaoProv.DENSO.RC8", machine_name="", option="Server=192.168.0.1"
    ):
        """
        RC8 provider establishes the connection to the target controller by referring to the parameters that have been
        passed at the AddController method execution.

        The option strings specify the communication method, connection parameters and timeout period. Options are
        delimited by ",".

        For more information, check the documentation off the RC8 Provider in page 50.

        Args:
            controller_name: string,
            provider_name: string,
            machine_name: string,
            option: string
        """
        self.cao_controller_dispatch = self.cao_workspace.AddController(
            controller_name, provider_name, machine_name, option
        )
        self.cao_controller = CAOController(self.cao_controller_dispatch)

        return self.cao_controller

    def execute(self, command, parameter=""):
        """
        The Execute method executes the command specified by the parameter.
        Args:
            command: string,
            parameter: string,

        Returns:
            CAOWorkspace Execute: Execute command
        """
        return self.cao_workspace.Execute(command, parameter)

    def remove_controller(self, controller_index):
        """
        The RemoveController method removes the controller specified by the parameter from the workspace.
        Args:
            controller_index: int,

        Returns:
        """
        controller_prev_count = self.cao_workspace.Controllers.Count
        self.cao_workspace.Controllers.Remove(controller_index)
        return controller_prev_count == self.cao_workspace.Controllers.Count + 1

    def remove_all_controllers(self):
        """
        The RemoveController method removes all the controllers from the workspace.
        Returns:
            True if the workspace was removed, False otherwise.
        """
        self.cao_workspace.Controllers.Clear()
        return self.cao_workspace.Controllers.Count == 0
