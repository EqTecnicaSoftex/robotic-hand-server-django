class ControllerExecute:
    def __init__(self, cao_controller):
        self.cao_controller = cao_controller

    def execute(self, command, parameters):
        return self.cao_controller.Execute(command, parameters)
