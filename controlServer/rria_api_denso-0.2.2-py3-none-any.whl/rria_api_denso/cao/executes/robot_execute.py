class RobotExecute:
    def __init__(self, cao_robot):
        self.cao_robot = cao_robot

    def execute(self, command, parameters):
        return self.cao_robot.Execute(command, parameters)
