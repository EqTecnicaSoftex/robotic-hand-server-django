from rria_api_denso.cao.exceptions.cao.level_description import LevelDescriptionError


class ControllerError(Exception):
    def __init__(self, error_code, error_details):
        self.__error_code = error_code
        self.__message = error_details["Message"]
        self.__level = error_details["Level"]
        self.__description = error_details["Description"]
        self.__remedy = error_details["Remedy"]
        self.__level_description = LevelDescriptionError(self.__level)
        super().__init__(self.__message)

    def __str__(self):
        child_str = str(self.__level_description).replace("\n", "\n\t\t")
        return f"ControllerError(\n\tCode: {self.__error_code}\n\tMessage: {self.__message}\n\tDescription: {self.__description}\n\tRemedy: {self.__remedy}\n\t{child_str}\n)"


class CAOEngineError(Exception):
    def __init__(self, error_code, table):
        error_details = table[error_code]
        self.__message = error_details["name"]
        self.__explanation = error_details["explanation"]
        self.__error_code = error_code
        super().__init__(self.__message)

    def __str__(self):
        return f"CAOEngineError(\n\tCode: {self.__error_code}\n\tMessage: {self.__message}\n\tExplanation: {self.__explanation}\n)"


class CAOProviderError(Exception):
    def __init__(self, error_code, table):
        error_details = table[error_code]
        self.__message = error_details["name"]
        self.__explanation = error_details["explanation"]
        self.__error_code = error_code
        super().__init__(self.__message)

    def __str__(self):
        return f"CAOProviderError(\n\tCode: {self.__error_code}\n\tMessage: {self.__message}\n\tExplanation: {self.__explanation}\n)"
