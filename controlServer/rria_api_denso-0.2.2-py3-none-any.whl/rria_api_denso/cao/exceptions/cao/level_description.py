LEVEL_DESCRIPTION = {
    "0": {
        "Description": "Minor error (warning)",
        "Robot Motion": "Normal",
        "Tasks": "Normal",
        "Motor Power": "Status quo",
    },
    "1": {
        "Description": "Minor error (Recoverable error by error handling)",
        "Robot Motion": "Pause",
        "Tasks": "Pause all tasks",
        "Motor Power": "Status quo",
    },
    "2": {
        "Description": "Warning in robot",
        "Robot Motion": "Pause",
        "Tasks": "Pause all tasks",
        "Motor Power": "Status quo",
    },
    "3": {
        "Description": "Abnormal condition in robot",
        "Robot Motion": "All stop",
        "Tasks": "Reset-stop all tasks",
        "Motor Power": " OFF",
    },
    "4": {
        "Description": "E-STOP error",
        "Robot Motion": 'All stop "E-STOP"',
        "Tasks": "Reset-stop all tasks",
        "Motor Power": " OFF",
    },
    "5": {
        "Description": "Catastrophic failure",
        "Robot Motion": 'All stop "E-STOP"',
        "Tasks": "Reset-stop all tasks",
        "Motor Power": " OFF",
    },
}


class LevelDescriptionError:
    def __init__(self, level):
        details = LEVEL_DESCRIPTION[level]
        self.__description = details["Description"]
        self.__robot_motion = details["Robot Motion"]
        self.__tasks = details["Tasks"]
        self.__motor_power = details["Motor Power"]

    def __str__(self):
        return f"LevelDescriptionError(\nDescription: {self.__description}\nRobot Motion: {self.__robot_motion}\nTasks: {self.__tasks}\nMotor Power: {self.__motor_power}\n)"
