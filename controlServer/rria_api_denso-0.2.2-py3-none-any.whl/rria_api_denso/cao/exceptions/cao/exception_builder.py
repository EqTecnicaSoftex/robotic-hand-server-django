from rria_api_denso.cao.exceptions.cao.exceptions_table import CAO_ENGINE_ERRORS, CAO_PROVIDER_ERRORS
from rria_api_denso.cao.exceptions.cao.exceptions_types import CAOEngineError, CAOProviderError, ControllerError
from rria_api_denso.cao.exceptions.cao.parser_errors_csv import create_errors_database, search_error_details
from rria_api_denso.utils.utils import dec_complemented2_to_hex


class ControllerExceptionBuilder:
    def __new__(cls, raw_error_code) -> ControllerError | CAOEngineError | CAOProviderError | Exception:
        hex_error_code = dec_complemented2_to_hex(raw_error_code, 32)
        error_details = search_error_details(create_errors_database(), hex_error_code)

        if error_details is not None:
            return ControllerError(hex_error_code, error_details)

        if hex_error_code in CAO_ENGINE_ERRORS.keys():
            return CAOEngineError(hex_error_code, CAO_ENGINE_ERRORS)

        if hex_error_code in CAO_PROVIDER_ERRORS.keys():
            return CAOProviderError(hex_error_code, CAO_PROVIDER_ERRORS)

        return Exception("unknown error code to denso controller:", hex_error_code)
