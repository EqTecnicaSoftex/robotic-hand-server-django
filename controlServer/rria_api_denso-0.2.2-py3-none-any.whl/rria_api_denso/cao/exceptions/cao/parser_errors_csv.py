"""
This module is responsible for returning errors related to the control of the robotic arm. It uses the errors.csv as
a basis to search for errors through the search_error_details function, passing the error_code as a parameter and
receiving the error details in return.

All values returned by this module are strings. To perform data manipulation, it is important not to forget to cast it
to the type you want to work with.
"""

import csv
from pathlib import Path


def create_errors_database() -> list[dict]:
    """
    Create a "database" with all errors from errors.csv based on ErrorLists from CAO.
    """

    current_lib_directory = Path(__file__).parent.absolute()

    with open(str(current_lib_directory) + "\\errors.csv", "r", encoding="utf8") as csv_file:
        csv_reader = csv.DictReader(csv_file)
        errors = []

        for line in csv_reader:
            errors.append(line)

        return errors


def search_error_details(error_database, error_code) -> dict | None:
    """
    Search for error details in the error database.
    Args:
        error_database: Error database
        error_code: Error code in hexadecimal format. Example: 0x80800001
    Returns:
        error_details: Error details in dict format, contains Code, Message, Level, Description and Remedy.
    """

    error_details = [row for row in error_database if row["Code"] == (error_code)[2:].upper()]

    if len(error_details) > 0:
        return error_details[0]


if __name__ == "__main__":
    print(search_error_details(create_errors_database(), "0x80800001"))
