DCOM_COMMON_ERRORS = {
    "0x80070006": {"name": "E_HANDLE", "explanation": "Invalid handle."},
    "0x8007xxxx": {"name": "E_WINDOWS_MASK", "explanation": "Windows standard error code."},
    "0x00030200": {
        "name": "STG_S_CONVERTED",
        "explanation": "The underlying file was converted to compound file format.",
    },
    "0x00030201": {
        "name": "STG_S_BLOCK",
        "explanation": "The storage operation should block until more data is available.",
    },
    "0x00030202": {"name": "STG_S_RETRYNOW", "explanation": "The storage operation should retry immediately."},
    "0x00030203": {
        "name": "STG_S_MONITORING",
        "explanation": "The notified event sink will not influence the storage operation.",
    },
    "0x00030204": {
        "name": "STG_S_MULTIPLEOPENS",
        "explanation": "Multiple opens prevent consolidated (commit succeeded).",
    },
    "0x00030205": {
        "name": "STG_S_CONSOLIDATIONFAILED",
        "explanation": "Consolidation of the storage file failed (commit succeeded).",
    },
    "0x00030206": {
        "name": "STG_S_CANNOTCONSOLIDATE",
        "explanation": "Consolidation of the storage file is inappropriate (commit succeeded).",
    },
    "0x00040000": {
        "name": "OLE_S_USEREG",
        "explanation": "Use the registry database to provide the requested information.",
    },
    "0x00040001": {"name": "OLE_S_STATIC", "explanation": "Success, but static."},
    "0x00040002": {"name": "OLE_S_MAC_CLIPFORMAT", "explanation": "Macintosh clipboard format."},
    "0x00040100": {"name": "DRAGDROP_S_DROP", "explanation": "Successful drop took place."},
    "0x00040101": {"name": "DRAGDROP_S_CANCEL", "explanation": "Drag-drop operation canceled."},
    "0x00040102": {"name": "DRAGDROP_S_USEDEFAULTCURSORS", "explanation": "Use the default cursor."},
    "0x00040130": {"name": "DATA_S_SAMEFORMATETC", "explanation": "Data has same FORMATETC."},
    "0x00040140": {"name": "VIEW_S_ALREADY_FROZEN", "explanation": "View is already frozen."},
    "0x00040170": {"name": "CACHE_S_FORMATETC_NOTSUPPORTED", "explanation": "FORMATETC not supported."},
    "0x00040171": {"name": "CACHE_S_SAMECACHE", "explanation": "Same cache."},
    "0x00040172": {"name": "CACHE_S_SOMECACHES_NOTUPDATED", "explanation": "Some caches are not updated."},
    "0x00040180": {"name": "OLEOBJ_S_INVALIDVERB", "explanation": "Invalid verb for OLE object."},
    "0x00040181": {
        "name": "OLEOBJ_S_CANNOT_DOVERB_NOW",
        "explanation": "Verb number is valid but verb cannot be done now.",
    },
    "0x00040182": {"name": "OLEOBJ_S_INVALIDHWND", "explanation": "Invalid window handle passed."},
    "0x000401A0": {
        "name": "INPLACE_S_TRUNCATED",
        "explanation": "Message is too long; some of it had to be truncated before displaying.",
    },
    "0x000401C0": {"name": "CONVERT10_S_NO_PRESENTATION", "explanation": "Unable to convert OLESTREAM to IStorage."},
    "0x000401E2": {"name": "MK_S_REDUCED_TO_SELF", "explanation": "Moniker reduced to itself."},
    "0x000401E4": {"name": "MK_S_ME", "explanation": "Common prefix is this moniker."},
    "0x000401E5": {"name": "MK_S_HIM", "explanation": "Common prefix is input moniker."},
    "0x000401E6": {"name": "MK_S_US", "explanation": "Common prefix is both monikers."},
    "0x000401E7": {
        "name": "MK_S_MONIKERALREADYREGISTERED",
        "explanation": "Moniker is already registered in running object table.",
    },
    "0x00040200": {
        "name": "EVENT_S_SOME_SUBSCRIBERS_FAILED",
        "explanation": "An event was able to invoke some, but not all, of the subscribers.",
    },
    "0x00040202": {
        "name": "EVENT_S_NOSUBSCRIBERS",
        "explanation": "An event was delivered, but there were no subscribers.",
    },
    "0x00041300": {"name": "SCHED_S_TASK_READY", "explanation": "The task is ready to run at its next scheduled time."},
    "0x00041301": {"name": "SCHED_S_TASK_RUNNING", "explanation": "The task is currently running."},
    "0x00041302": {
        "name": "SCHED_S_TASK_DISABLED",
        "explanation": "The task will not run at the scheduled times because it has been disabled.",
    },
    "0x00041303": {"name": "SCHED_S_TASK_HAS_NOT_RUN", "explanation": "The task has not yet run."},
    "0x00041304": {
        "name": "SCHED_S_TASK_NO_MORE_RUNS",
        "explanation": "There are no more runs scheduled for this task.",
    },
    "0x00041305": {
        "name": "SCHED_S_TASK_NOT_SCHEDULED",
        "explanation": "One or more of the properties that are needed to run this task on a schedule have not been set.",
    },
    "0x00041306": {
        "name": "SCHED_S_TASK_TERMINATED",
        "explanation": "The last run of the task was terminated by the user.",
    },
    "0x00041307": {
        "name": "SCHED_S_TASK_NO_VALID_TRIGGERS",
        "explanation": "Either the task has no triggers, or the existing triggers are disabled or not set.",
    },
    "0x00041308": {"name": "SCHED_S_EVENT_TRIGGER", "explanation": "Event triggers do not have set run times."},
    "0x0004131B": {
        "name": "SCHED_S_SOME_TRIGGERS_FAILED",
        "explanation": "The task is registered, but not all specified triggers will start the task.",
    },
    "0x0004131C": {
        "name": "SCHED_S_BATCH_LOGON_PROBLEM",
        "explanation": "The task is registered, but it might fail to start. Batch logon privilege needs to be enabled for the task principal.",
    },
    "0x0004D000": {
        "name": "XACT_S_ASYNC",
        "explanation": "An asynchronous operation was specified. The operation has begun, but its outcome is not known yet.",
    },
    "0x0004D002": {
        "name": "XACT_S_READONLY",
        "explanation": "The method call succeeded because the transaction was read-only.",
    },
    "0x0004D003": {
        "name": "XACT_S_SOMENORETAIN",
        "explanation": "The transaction was successfully aborted. However, this is a coordinated transaction, and a number of enlisted resources were aborted outright because they could not support abort-retaining semantics.",
    },
    "0x0004D004": {
        "name": "XACT_S_OKINFORM",
        "explanation": "No changes were made during this call, but the sink wants another chance to look if any other sinks make further changes.",
    },
    "0x0004D005": {
        "name": "XACT_S_MADECHANGESCONTENT",
        "explanation": "The sink is content and wants the transaction to proceed. Changes were made to one or more resources during this call.",
    },
    "0x0004D006": {
        "name": "XACT_S_MADECHANGESINFORM",
        "explanation": "The sink is for the moment and wants the transaction to proceed, but if other changes are made following this return by other event sinks, this sink wants another chance to look.",
    },
    "0x0004D007": {
        "name": "XACT_S_ALLNORETAIN",
        "explanation": "The transaction was successfully aborted. However, the abort was nonretaining.",
    },
    "0x0004D008": {"name": "XACT_S_ABORTING", "explanation": "An abort operation was already in progress."},
    "0x0004D009": {
        "name": "XACT_S_SINGLEPHASE",
        "explanation": "The resource manager has performed a single-phase commit of the transaction.",
    },
    "0x0004D00A": {"name": "XACT_S_LOCALLY_OK", "explanation": "The local transaction has not aborted."},
    "0x0004D010": {
        "name": "XACT_S_LASTRESOURCEMANAGER",
        "explanation": "The resource manager has requested to be the coordinator (last resource manager) for the transaction.",
    },
    "0x00080012": {"name": "CO_S_NOTALLINTERFACES", "explanation": "Not all the requested interfaces were available."},
    "0x00080013": {
        "name": "CO_S_MACHINENAMENOTFOUND",
        "explanation": "The specified machine name was not found in the cache.",
    },
    "0x00090312": {
        "name": "SEC_I_CONTINUE_NEEDED",
        "explanation": "The function completed successfully, but it must be called again to complete the context.",
    },
    "0x00090313": {
        "name": "SEC_I_COMPLETE_NEEDED",
        "explanation": "The function completed successfully, but CompleteToken must be called.",
    },
    "0x00090314": {
        "name": "SEC_I_COMPLETE_AND_CONTINUE",
        "explanation": "The function completed successfully, but both CompleteToken and this function must be called to complete the context.",
    },
    "0x00090315": {
        "name": "SEC_I_LOCAL_LOGON",
        "explanation": "The logon was completed, but no network authority was available. The logon was made using locally known information.",
    },
    "0x00090317": {
        "name": "SEC_I_CONTEXT_EXPIRED",
        "explanation": "The context has expired and can no longer be used.",
    },
    "0x00090320": {
        "name": "SEC_I_INCOMPLETE_CREDENTIALS",
        "explanation": "The credentials supplied were not complete and could not be verified. Additional information can be returned from the context.",
    },
    "0x00090321": {"name": "SEC_I_RENEGOTIATE", "explanation": "The context data must be renegotiated with the peer."},
    "0x00090323": {
        "name": "SEC_I_NO_LSA_CONTEXT",
        "explanation": "There is no LSA mode context associated with this context.",
    },
    "0x0009035C": {
        "name": "SEC_I_SIGNATURE_NEEDED",
        "explanation": "A signature operation must be performed before the user can authenticate.",
    },
    "0x00091012": {
        "name": "CRYPT_I_NEW_PROTECTION_REQUIRED",
        "explanation": "The protected data needs to be reprotected.",
    },
    "0x000D0000": {"name": "NS_S_CALLPENDING", "explanation": "The requested operation is pending completion."},
    "0x000D0001": {"name": "NS_S_CALLABORTED", "explanation": "The requested operation was aborted by the client."},
    "0x000D0002": {
        "name": "NS_S_STREAM_TRUNCATED",
        "explanation": "The stream was purposefully stopped before completion.",
    },
    "0x000D0BC8": {
        "name": "NS_S_REBUFFERING",
        "explanation": "The requested operation has caused the source to rebuffer.",
    },
    "0x000D0BC9": {
        "name": "NS_S_DEGRADING_QUALITY",
        "explanation": "The requested operation has caused the source to degrade codec quality.",
    },
    "0x000D0BDB": {"name": "NS_S_TRANSCRYPTOR_EOF", "explanation": "The transcryptor object has reached end of file."},
    "0x000D0FE8": {
        "name": "NS_S_WMP_UI_VERSIONMISMATCH",
        "explanation": "An upgrade is needed for the theme manager to correctly show this skin. Skin reports version: %.1f.",
    },
    "0x000D0FE9": {"name": "NS_S_WMP_EXCEPTION", "explanation": "An error occurred in one of the UI components."},
    "0x000D1040": {"name": "NS_S_WMP_LOADED_GIF_IMAGE", "explanation": "Successfully loaded a GIF file."},
    "0x000D1041": {"name": "NS_S_WMP_LOADED_PNG_IMAGE", "explanation": "Successfully loaded a PNG file."},
    "0x000D1042": {"name": "NS_S_WMP_LOADED_BMP_IMAGE", "explanation": "Successfully loaded a BMP file."},
    "0x000D1043": {"name": "NS_S_WMP_LOADED_JPG_IMAGE", "explanation": "Successfully loaded a JPG file."},
    "0x000D104F": {"name": "NS_S_WMG_FORCE_DROP_FRAME", "explanation": "Drop this frame."},
    "0x000D105F": {
        "name": "NS_S_WMR_ALREADYRENDERED",
        "explanation": "The specified stream has already been rendered.",
    },
    "0x000D1060": {
        "name": "NS_S_WMR_PINTYPEPARTIALMATCH",
        "explanation": "The specified type partially matches this pin type.",
    },
    "0x000D1061": {
        "name": "NS_S_WMR_PINTYPEFULLMATCH",
        "explanation": "The specified type fully matches this pin type.",
    },
    "0x000D1066": {
        "name": "NS_S_WMG_ADVISE_DROP_FRAME",
        "explanation": "The timestamp is late compared to the current render position. Advise dropping this frame.",
    },
    "0x000D1067": {
        "name": "NS_S_WMG_ADVISE_DROP_TO_KEYFRAME",
        "explanation": "The timestamp is severely late compared to the current render position. Advise dropping everything up to the next key frame.",
    },
    "0x000D10DB": {
        "name": "NS_S_NEED_TO_BUY_BURN_RIGHTS",
        "explanation": "No burn rights. You will be prompted to buy burn rights when you try to burn this file to an audio CD.",
    },
    "0x000D10FE": {
        "name": "NS_S_WMPCORE_PLAYLISTCLEARABORT",
        "explanation": "Failed to clear playlist because it was aborted by user.",
    },
    "0x000D10FF": {
        "name": "NS_S_WMPCORE_PLAYLISTREMOVEITEMABORT",
        "explanation": "Failed to remove item in the playlist since it was aborted by user.",
    },
    "0x000D1102": {
        "name": "NS_S_WMPCORE_PLAYLIST_CREATION_PENDING",
        "explanation": "Playlist is being generated asynchronously.",
    },
    "0x000D1103": {
        "name": "NS_S_WMPCORE_MEDIA_VALIDATION_PENDING",
        "explanation": "Validation of the media is pending.",
    },
    "0x000D1104": {
        "name": "NS_S_WMPCORE_PLAYLIST_REPEAT_SECONDARY_SEGMENTS_IGNORED",
        "explanation": "Encountered more than one Repeat block during ASX processing.",
    },
    "0x000D1105": {
        "name": "NS_S_WMPCORE_COMMAND_NOT_AVAILABLE",
        "explanation": "Current state of WMP disallows calling this method or property.",
    },
    "0x000D1106": {
        "name": "NS_S_WMPCORE_PLAYLIST_NAME_AUTO_GENERATED",
        "explanation": "Name for the playlist has been auto generated.",
    },
    "0x000D1107": {
        "name": "NS_S_WMPCORE_PLAYLIST_IMPORT_MISSING_ITEMS",
        "explanation": "The imported playlist does not contain all items from the original.",
    },
    "0x000D1108": {
        "name": "NS_S_WMPCORE_PLAYLIST_COLLAPSED_TO_SINGLE_MEDIA",
        "explanation": "The M3U playlist has been ignored because it only contains one item.",
    },
    "0x000D1109": {
        "name": "NS_S_WMPCORE_MEDIA_CHILD_PLAYLIST_OPEN_PENDING",
        "explanation": "The open for the child playlist associated with this media is pending.",
    },
    "0x000D110A": {
        "name": "NS_S_WMPCORE_MORE_NODES_AVAIABLE",
        "explanation": "More nodes support the interface requested, but the array for returning them is full.",
    },
    "0x000D1135": {"name": "NS_S_WMPBR_SUCCESS", "explanation": "Backup or Restore successful!."},
    "0x000D1136": {"name": "NS_S_WMPBR_PARTIALSUCCESS", "explanation": "Transfer complete with limitations."},
    "0x000D1144": {
        "name": "NS_S_WMPEFFECT_TRANSPARENT",
        "explanation": "Request to the effects control to change transparency status to transparent.",
    },
    "0x000D1145": {
        "name": "NS_S_WMPEFFECT_OPAQUE",
        "explanation": "Request to the effects control to change transparency status to opaque.",
    },
    "0x000D114E": {
        "name": "NS_S_OPERATION_PENDING",
        "explanation": "The requested application pane is performing an operation and will not be released.",
    },
    "0x000D1359": {
        "name": "NS_S_TRACK_BUY_REQUIRES_ALBUM_PURCHASE",
        "explanation": "The file is only available for purchase when you buy the entire album.",
    },
    "0x000D135E": {
        "name": "NS_S_NAVIGATION_COMPLETE_WITH_ERRORS",
        "explanation": "There were problems completing the requested navigation. There are identifiers missing in the catalog.",
    },
    "0x000D1361": {"name": "NS_S_TRACK_ALREADY_DOWNLOADED", "explanation": "Track already downloaded."},
    "0x000D1519": {
        "name": "NS_S_PUBLISHING_POINT_STARTED_WITH_FAILED_SINKS",
        "explanation": "The publishing point successfully started, but one or more of the requested data writer plug-ins failed.",
    },
    "0x000D2726": {"name": "NS_S_DRM_LICENSE_ACQUIRED", "explanation": "Status message: The license was acquired."},
    "0x000D2727": {
        "name": "NS_S_DRM_INDIVIDUALIZED",
        "explanation": "Status message: The security upgrade has been completed.",
    },
    "0x000D2746": {
        "name": "NS_S_DRM_MONITOR_CANCELLED",
        "explanation": "Status message: License monitoring has been canceled.",
    },
    "0x000D2747": {
        "name": "NS_S_DRM_ACQUIRE_CANCELLED",
        "explanation": "Status message: License acquisition has been canceled.",
    },
    "0x000D276E": {
        "name": "NS_S_DRM_BURNABLE_TRACK",
        "explanation": "The track is burnable and had no playlist burn limit.",
    },
    "0x000D276F": {
        "name": "NS_S_DRM_BURNABLE_TRACK_WITH_PLAYLIST_RESTRICTION",
        "explanation": "The track is burnable but has a playlist burn limit.",
    },
    "0x000D27DE": {
        "name": "NS_S_DRM_NEEDS_INDIVIDUALIZATION",
        "explanation": "A security upgrade is required to perform the operation on this media file.",
    },
    "0x000D2AF8": {
        "name": "NS_S_REBOOT_RECOMMENDED",
        "explanation": "Installation was successful; however, some file cleanup is not complete. For best results, restart your computer.",
    },
    "0x000D2AF9": {
        "name": "NS_S_REBOOT_REQUIRED",
        "explanation": "Installation was successful; however, some file cleanup is not complete. To continue, you must restart your computer.",
    },
    "0x000D2F09": {"name": "NS_S_EOSRECEDING", "explanation": "EOS hit during rewinding."},
    "0x000D2F0D": {"name": "NS_S_CHANGENOTICE", "explanation": "Internal."},
    "0x001F0001": {"name": "ERROR_FLT_IO_COMPLETE", "explanation": "The IO was completed by a filter."},
    "0x00262307": {
        "name": "ERROR_GRAPHICS_MODE_NOT_PINNED",
        "explanation": "No mode is pinned on the specified VidPN source or target.",
    },
    "0x0026231E": {
        "name": "ERROR_GRAPHICS_NO_PREFERRED_MODE",
        "explanation": "Specified mode set does not specify preference for one of its modes.",
    },
    "0x0026234B": {
        "name": "ERROR_GRAPHICS_DATASET_IS_EMPTY",
        "explanation": "Specified data set (for example, mode set, frequency range set, descriptor set, and topology) is empty.",
    },
    "0x0026234C": {
        "name": "ERROR_GRAPHICS_NO_MORE_ELEMENTS_IN_DATASET",
        "explanation": "Specified data set (for example, mode set, frequency range set, descriptor set, and topology) does not contain any more elements.",
    },
    "0x00262351": {
        "name": "ERROR_GRAPHICS_PATH_CONTENT_GEOMETRY_TRANSFORMATION_NOT_PINNED",
        "explanation": "Specified content transformation is not pinned on the specified VidPN present path.",
    },
    "0x00300100": {"name": "PLA_S_PROPERTY_IGNORED", "explanation": "Property value will be ignored."},
    "0x00340001": {
        "name": "ERROR_NDIS_INDICATION_REQUIRED",
        "explanation": "The request will be completed later by a Network Driver Interface Specification (NDIS) status indication.",
    },
    "0x0DEAD100": {
        "name": "TRK_S_OUT_OF_SYNC",
        "explanation": "The VolumeSequenceNumber of a MOVE_NOTIFICATION request is incorrect.",
    },
    "0x0DEAD102": {
        "name": "TRK_VOLUME_NOT_FOUND",
        "explanation": "The VolumeID in a request was not found in the server's ServerVolumeTable.",
    },
    "0x0DEAD103": {
        "name": "TRK_VOLUME_NOT_OWNED",
        "explanation": "A notification was sent to the LnkSvrMessage method, but the RequestMachine for the request was not the VolumeOwner for a VolumeID in the request.",
    },
    "0x0DEAD107": {
        "name": "TRK_S_NOTIFICATION_QUOTA_EXCEEDED",
        "explanation": "The server received a MOVE_NOTIFICATION request, but the FileTable size limit has already been reached.",
    },
    "0x400D004F": {"name": "NS_I_TIGER_START", "explanation": "The Title Server %1 is running."},
    "0x400D0051": {"name": "NS_I_CUB_START", "explanation": "Content Server %1 (%2) is starting."},
    "0x400D0052": {"name": "NS_I_CUB_RUNNING", "explanation": "Content Server %1 (%2) is running."},
    "0x400D0054": {"name": "NS_I_DISK_START", "explanation": "Disk %1 ( %2 ) on Content Server %3, is running."},
    "0x400D0056": {
        "name": "NS_I_DISK_REBUILD_STARTED",
        "explanation": "Started rebuilding disk %1 ( %2 ) on Content Server %3.",
    },
    "0x400D0057": {
        "name": "NS_I_DISK_REBUILD_FINISHED",
        "explanation": "Finished rebuilding disk %1 ( %2 ) on Content Server %3.",
    },
    "0x400D0058": {
        "name": "NS_I_DISK_REBUILD_ABORTED",
        "explanation": "Aborted rebuilding disk %1 ( %2 ) on Content Server %3.",
    },
    "0x400D0059": {
        "name": "NS_I_LIMIT_FUNNELS",
        "explanation": "A NetShow administrator at network location %1 set the data stream limit to %2 streams.",
    },
    "0x400D005A": {
        "name": "NS_I_START_DISK",
        "explanation": "A NetShow administrator at network location %1 started disk %2.",
    },
    "0x400D005B": {
        "name": "NS_I_STOP_DISK",
        "explanation": "A NetShow administrator at network location %1 stopped disk %2.",
    },
    "0x400D005C": {
        "name": "NS_I_STOP_CUB",
        "explanation": "A NetShow administrator at network location %1 stopped Content Server %2.",
    },
    "0x400D005D": {
        "name": "NS_I_KILL_USERSESSION",
        "explanation": "A NetShow administrator at network location %1 aborted user session %2 from the system.",
    },
    "0x400D005E": {
        "name": "NS_I_KILL_CONNECTION",
        "explanation": "A NetShow administrator at network location %1 aborted obsolete connection %2 from the system.",
    },
    "0x400D005F": {
        "name": "NS_I_REBUILD_DISK",
        "explanation": "A NetShow administrator at network location %1 started rebuilding disk %2.",
    },
    "0x400D0069": {
        "name": "MCMADM_I_NO_EVENTS",
        "explanation": "Event initialization failed, there will be no MCM events.",
    },
    "0x400D006E": {"name": "NS_I_LOGGING_FAILED", "explanation": "The logging operation failed."},
    "0x400D0070": {
        "name": "NS_I_LIMIT_BANDWIDTH",
        "explanation": "A NetShow administrator at network location %1 set the maximum bandwidth limit to %2 bps.",
    },
    "0x400D0191": {
        "name": "NS_I_CUB_UNFAIL_LINK",
        "explanation": "Content Server %1 (%2) has established its link to Content Server %3.",
    },
    "0x400D0193": {"name": "NS_I_RESTRIPE_START", "explanation": "Restripe operation has started."},
    "0x400D0194": {"name": "NS_I_RESTRIPE_DONE", "explanation": "Restripe operation has completed."},
    "0x400D0196": {
        "name": "NS_I_RESTRIPE_DISK_OUT",
        "explanation": "Content disk %1 (%2) on Content Server %3 has been restriped out.",
    },
    "0x400D0197": {"name": "NS_I_RESTRIPE_CUB_OUT", "explanation": "Content server %1 (%2) has been restriped out."},
    "0x400D0198": {"name": "NS_I_DISK_STOP", "explanation": "Disk %1 ( %2 ) on Content Server %3, has been offlined."},
    "0x400D14BE": {
        "name": "NS_I_PLAYLIST_CHANGE_RECEDING",
        "explanation": "The playlist change occurred while receding.",
    },
    "0x400D2EFF": {"name": "NS_I_RECONNECTED", "explanation": "The client is reconnected."},
    "0x400D2F01": {"name": "NS_I_NOLOG_STOP", "explanation": "Forcing a switch to a pending header on start."},
    "0x400D2F03": {
        "name": "NS_I_EXISTING_PACKETIZER",
        "explanation": "There is already an existing packetizer plugin for the stream.",
    },
    "0x400D2F04": {"name": "NS_I_MANUAL_PROXY", "explanation": "The proxy setting is manual."},
    "0x40262009": {
        "name": "ERROR_GRAPHICS_DRIVER_MISMATCH",
        "explanation": "The kernel driver detected a version mismatch between it and the user mode driver.",
    },
    "0x4026242F": {
        "name": "ERROR_GRAPHICS_UNKNOWN_CHILD_STATUS",
        "explanation": "Child device presence was not reliably detected.",
    },
    "0x40262437": {
        "name": "ERROR_GRAPHICS_LEADLINK_START_DEFERRED",
        "explanation": "Starting the lead-link adapter has been deferred temporarily.",
    },
    "0x40262439": {
        "name": "ERROR_GRAPHICS_POLLING_TOO_FREQUENTLY",
        "explanation": "The display adapter is being polled for children too frequently at the same polling level.",
    },
    "0x4026243A": {
        "name": "ERROR_GRAPHICS_START_DEFERRED",
        "explanation": "Starting the adapter has been deferred temporarily.",
    },
    "0x8000000A": {
        "name": "E_PENDING",
        "explanation": "The data necessary to complete this operation is not yet available.",
    },
    "0x80004001": {"name": "E_NOTIMPL", "explanation": "Not implemented."},
    "0x80004002": {"name": "E_NOINTERFACE", "explanation": "No such interface supported."},
    "0x80004003": {"name": "E_POINTER", "explanation": "Invalid pointer."},
    "0x80004004": {"name": "E_ABORT", "explanation": "Operation aborted."},
    "0x80004005": {"name": "E_FAIL", "explanation": "Unspecified error."},
    "0x80004006": {"name": "CO_E_INIT_TLS", "explanation": "Thread local storage failure."},
    "0x80004007": {"name": "CO_E_INIT_SHARED_ALLOCATOR", "explanation": "Get shared memory allocator failure."},
    "0x80004008": {"name": "CO_E_INIT_MEMORY_ALLOCATOR", "explanation": "Get memory allocator failure."},
    "0x80004009": {"name": "CO_E_INIT_CLASS_CACHE", "explanation": "Unable to initialize class cache."},
    "0x8000400A": {
        "name": "CO_E_INIT_RPC_CHANNEL",
        "explanation": "Unable to initialize remote procedure call (RPC) services.",
    },
    "0x8000400B": {
        "name": "CO_E_INIT_TLS_SET_CHANNEL_CONTROL",
        "explanation": "Cannot set thread local storage channel control.",
    },
    "0x8000400C": {
        "name": "CO_E_INIT_TLS_CHANNEL_CONTROL",
        "explanation": "Could not allocate thread local storage channel control.",
    },
    "0x8000400D": {
        "name": "CO_E_INIT_UNACCEPTED_USER_ALLOCATOR",
        "explanation": "The user-supplied memory allocator is unacceptable.",
    },
    "0x8000400E": {"name": "CO_E_INIT_SCM_MUTEX_EXISTS", "explanation": "The OLE service mutex already exists."},
    "0x8000400F": {
        "name": "CO_E_INIT_SCM_FILE_MAPPING_EXISTS",
        "explanation": "The OLE service file mapping already exists.",
    },
    "0x80004010": {
        "name": "CO_E_INIT_SCM_MAP_VIEW_OF_FILE",
        "explanation": "Unable to map view of file for OLE service.",
    },
    "0x80004011": {"name": "CO_E_INIT_SCM_EXEC_FAILURE", "explanation": "Failure attempting to launch OLE service."},
    "0x80004012": {
        "name": "CO_E_INIT_ONLY_SINGLE_THREADED",
        "explanation": "There was an attempt to call CoInitialize a second time while single-threaded.",
    },
    "0x80004013": {"name": "CO_E_CANT_REMOTE", "explanation": "A Remote activation was necessary but was not allowed."},
    "0x80004014": {
        "name": "CO_E_BAD_SERVER_NAME",
        "explanation": "A Remote activation was necessary, but the server name provided was invalid.",
    },
    "0x80004015": {
        "name": "CO_E_WRONG_SERVER_IDENTITY",
        "explanation": "The class is configured to run as a security ID different from the caller.",
    },
    "0x80004016": {
        "name": "CO_E_OLE1DDE_DISABLED",
        "explanation": "Use of OLE1 services requiring Dynamic Data Exchange (DDE) Windows is disabled.",
    },
    "0x80004017": {
        "name": "CO_E_RUNAS_SYNTAX",
        "explanation": "A RunAs specification must be <domain name>\\<user name> or simply <user name>.",
    },
    "0x80004018": {
        "name": "CO_E_CREATEPROCESS_FAILURE",
        "explanation": "The server process could not be started. The path name might be incorrect.",
    },
    "0x80004019": {
        "name": "CO_E_RUNAS_CREATEPROCESS_FAILURE",
        "explanation": "The server process could not be started as the configured identity. The path name might be incorrect or unavailable.",
    },
    "0x8000401A": {
        "name": "CO_E_RUNAS_LOGON_FAILURE",
        "explanation": "The server process could not be started because the configured identity is incorrect. Check the user name and password.",
    },
    "0x8000401B": {
        "name": "CO_E_LAUNCH_PERMSSION_DENIED",
        "explanation": "The client is not allowed to launch this server.",
    },
    "0x8000401C": {
        "name": "CO_E_START_SERVICE_FAILURE",
        "explanation": "The service providing this server could not be started.",
    },
    "0x8000401D": {
        "name": "CO_E_REMOTE_COMMUNICATION_FAILURE",
        "explanation": "This computer was unable to communicate with the computer providing the server.",
    },
    "0x8000401E": {
        "name": "CO_E_SERVER_START_TIMEOUT",
        "explanation": "The server did not respond after being launched.",
    },
    "0x8000401F": {
        "name": "CO_E_CLSREG_INCONSISTENT",
        "explanation": "The registration information for this server is inconsistent or incomplete.",
    },
    "0x80004020": {
        "name": "CO_E_IIDREG_INCONSISTENT",
        "explanation": "The registration information for this interface is inconsistent or incomplete.",
    },
    "0x80004021": {"name": "CO_E_NOT_SUPPORTED", "explanation": "The operation attempted is not supported."},
    "0x80004022": {"name": "CO_E_RELOAD_DLL", "explanation": "A DLL must be loaded."},
    "0x80004023": {"name": "CO_E_MSI_ERROR", "explanation": "A Microsoft Software Installer error was encountered."},
    "0x80004024": {
        "name": "CO_E_ATTEMPT_TO_CREATE_OUTSIDE_CLIENT_CONTEXT",
        "explanation": "The specified activation could not occur in the client context as specified.",
    },
    "0x80004025": {"name": "CO_E_SERVER_PAUSED", "explanation": "Activations on the server are paused."},
    "0x80004026": {"name": "CO_E_SERVER_NOT_PAUSED", "explanation": "Activations on the server are not paused."},
    "0x80004027": {
        "name": "CO_E_CLASS_DISABLED",
        "explanation": "The component or application containing the component has been disabled.",
    },
    "0x80004028": {"name": "CO_E_CLRNOTAVAILABLE", "explanation": "The common language runtime is not available."},
    "0x80004029": {
        "name": "CO_E_ASYNC_WORK_REJECTED",
        "explanation": "The thread-pool rejected the submitted asynchronous work.",
    },
    "0x8000402A": {
        "name": "CO_E_SERVER_INIT_TIMEOUT",
        "explanation": "The server started, but it did not finish initializing in a timely fashion.",
    },
    "0x8000402B": {
        "name": "CO_E_NO_SECCTX_IN_ACTIVATE",
        "explanation": "Unable to complete the call because there is no COM+ security context inside IObjectControl.Activate.",
    },
    "0x80004030": {"name": "CO_E_TRACKER_CONFIG", "explanation": "The provided tracker configuration is invalid."},
    "0x80004031": {
        "name": "CO_E_THREADPOOL_CONFIG",
        "explanation": "The provided thread pool configuration is invalid.",
    },
    "0x80004032": {"name": "CO_E_SXS_CONFIG", "explanation": "The provided side-by-side configuration is invalid."},
    "0x80004033": {
        "name": "CO_E_MALFORMED_SPN",
        "explanation": "The server principal name (SPN) obtained during security negotiation is malformed.",
    },
    "0x8000FFFF": {"name": "E_UNEXPECTED", "explanation": "Catastrophic failure."},
    "0x80010001": {"name": "RPC_E_CALL_REJECTED", "explanation": "Call was rejected by callee."},
    "0x80010002": {"name": "RPC_E_CALL_CANCELED", "explanation": "Call was canceled by the message filter."},
    "0x80010003": {
        "name": "RPC_E_CANTPOST_INSENDCALL",
        "explanation": "The caller is dispatching an intertask SendMessage call and cannot call out via PostMessage.",
    },
    "0x80010004": {
        "name": "RPC_E_CANTCALLOUT_INASYNCCALL",
        "explanation": "The caller is dispatching an asynchronous call and cannot make an outgoing call on behalf of this call.",
    },
    "0x80010005": {
        "name": "RPC_E_CANTCALLOUT_INEXTERNALCALL",
        "explanation": "It is illegal to call out while inside message filter.",
    },
    "0x80010006": {
        "name": "RPC_E_CONNECTION_TERMINATED",
        "explanation": "The connection terminated or is in a bogus state and can no longer be used. Other connections are still valid.",
    },
    "0x80010007": {
        "name": "RPC_E_SERVER_DIED",
        "explanation": "The callee (the server, not the server application) is not available and disappeared; all connections are invalid. The call might have executed.",
    },
    "0x80010008": {
        "name": "RPC_E_CLIENT_DIED",
        "explanation": "The caller (client) disappeared while the callee (server) was processing a call.",
    },
    "0x80010009": {
        "name": "RPC_E_INVALID_DATAPACKET",
        "explanation": "The data packet with the marshaled parameter data is incorrect.",
    },
    "0x8001000A": {
        "name": "RPC_E_CANTTRANSMIT_CALL",
        "explanation": "The call was not transmitted properly; the message queue was full and was not emptied after yielding.",
    },
    "0x8001000B": {
        "name": "RPC_E_CLIENT_CANTMARSHAL_DATA",
        "explanation": "The client RPC caller cannot marshal the parameter data due to errors (such as low memory).",
    },
    "0x8001000C": {
        "name": "RPC_E_CLIENT_CANTUNMARSHAL_DATA",
        "explanation": "The client RPC caller cannot unmarshal the return data due to errors (such as low memory).",
    },
    "0x8001000D": {
        "name": "RPC_E_SERVER_CANTMARSHAL_DATA",
        "explanation": "The server RPC callee cannot marshal the return data due to errors (such as low memory).",
    },
    "0x8001000E": {
        "name": "RPC_E_SERVER_CANTUNMARSHAL_DATA",
        "explanation": "The server RPC callee cannot unmarshal the parameter data due to errors (such as low memory).",
    },
    "0x8001000F": {
        "name": "RPC_E_INVALID_DATA",
        "explanation": "Received data is invalid. The data might be server or client data.",
    },
    "0x80010010": {
        "name": "RPC_E_INVALID_PARAMETER",
        "explanation": "A particular parameter is invalid and cannot be (un)marshaled.",
    },
    "0x80010011": {
        "name": "RPC_E_CANTCALLOUT_AGAIN",
        "explanation": "There is no second outgoing call on same channel in DDE conversation.",
    },
    "0x80010012": {
        "name": "RPC_E_SERVER_DIED_DNE",
        "explanation": "The callee (the server, not the server application) is not available and disappeared; all connections are invalid. The call did not execute.",
    },
    "0x80010100": {"name": "RPC_E_SYS_CALL_FAILED", "explanation": "System call failed."},
    "0x80010101": {
        "name": "RPC_E_OUT_OF_RESOURCES",
        "explanation": "Could not allocate some required resource (such as memory or events)",
    },
    "0x80010102": {
        "name": "RPC_E_ATTEMPTED_MULTITHREAD",
        "explanation": "Attempted to make calls on more than one thread in single-threaded mode.",
    },
    "0x80010103": {
        "name": "RPC_E_NOT_REGISTERED",
        "explanation": "The requested interface is not registered on the server object.",
    },
    "0x80010104": {
        "name": "RPC_E_FAULT",
        "explanation": "RPC could not call the server or could not return the results of calling the server.",
    },
    "0x80010105": {"name": "RPC_E_SERVERFAULT", "explanation": "The server threw an exception."},
    "0x80010106": {"name": "RPC_E_CHANGED_MODE", "explanation": "Cannot change thread mode after it is set."},
    "0x80010107": {"name": "RPC_E_INVALIDMETHOD", "explanation": "The method called does not exist on the server."},
    "0x80010108": {
        "name": "RPC_E_DISCONNECTED",
        "explanation": "The object invoked has disconnected from its clients.",
    },
    "0x80010109": {
        "name": "RPC_E_RETRY",
        "explanation": "The object invoked chose not to process the call now. Try again later.",
    },
    "0x8001010A": {
        "name": "RPC_E_SERVERCALL_RETRYLATER",
        "explanation": "The message filter indicated that the application is busy.",
    },
    "0x8001010B": {"name": "RPC_E_SERVERCALL_REJECTED", "explanation": "The message filter rejected the call."},
    "0x8001010C": {
        "name": "RPC_E_INVALID_CALLDATA",
        "explanation": "A call control interface was called with invalid data.",
    },
    "0x8001010D": {
        "name": "RPC_E_CANTCALLOUT_ININPUTSYNCCALL",
        "explanation": "An outgoing call cannot be made because the application is dispatching an input-synchronous call.",
    },
    "0x8001010E": {
        "name": "RPC_E_WRONG_THREAD",
        "explanation": "The application called an interface that was marshaled for a different thread.",
    },
    "0x8001010F": {
        "name": "RPC_E_THREAD_NOT_INIT",
        "explanation": "CoInitialize has not been called on the current thread.",
    },
    "0x80010110": {
        "name": "RPC_E_VERSION_MISMATCH",
        "explanation": "The version of OLE on the client and server machines does not match.",
    },
    "0x80010111": {"name": "RPC_E_INVALID_HEADER", "explanation": "OLE received a packet with an invalid header."},
    "0x80010112": {
        "name": "RPC_E_INVALID_EXTENSION",
        "explanation": "OLE received a packet with an invalid extension.",
    },
    "0x80010113": {"name": "RPC_E_INVALID_IPID", "explanation": "The requested object or interface does not exist."},
    "0x80010114": {"name": "RPC_E_INVALID_OBJECT", "explanation": "The requested object does not exist."},
    "0x80010115": {"name": "RPC_S_CALLPENDING", "explanation": "OLE has sent a request and is waiting for a reply."},
    "0x80010116": {"name": "RPC_S_WAITONTIMER", "explanation": "OLE is waiting before retrying a request."},
    "0x80010117": {
        "name": "RPC_E_CALL_COMPLETE",
        "explanation": "Call context cannot be accessed after call completed.",
    },
    "0x80010118": {"name": "RPC_E_UNSECURE_CALL", "explanation": "Impersonate on unsecure calls is not supported."},
    "0x80010119": {
        "name": "RPC_E_TOO_LATE",
        "explanation": "Security must be initialized before any interfaces are marshaled or unmarshaled. It cannot be changed after initialized.",
    },
    "0x8001011A": {
        "name": "RPC_E_NO_GOOD_SECURITY_PACKAGES",
        "explanation": "No security packages are installed on this machine, the user is not logged on, or there are no compatible security packages between the client and server.",
    },
    "0x8001011B": {"name": "RPC_E_ACCESS_DENIED", "explanation": "Access is denied."},
    "0x8001011C": {"name": "RPC_E_REMOTE_DISABLED", "explanation": "Remote calls are not allowed for this process."},
    "0x8001011D": {
        "name": "RPC_E_INVALID_OBJREF",
        "explanation": "The marshaled interface data packet (OBJREF) has an invalid or unknown format.",
    },
    "0x8001011E": {
        "name": "RPC_E_NO_CONTEXT",
        "explanation": "No context is associated with this call. This happens for some custom marshaled calls and on the client side of the call.",
    },
    "0x8001011F": {
        "name": "RPC_E_TIMEOUT",
        "explanation": "This operation returned because the time-out period expired.",
    },
    "0x80010120": {"name": "RPC_E_NO_SYNC", "explanation": "There are no synchronize objects to wait on."},
    "0x80010121": {
        "name": "RPC_E_FULLSIC_REQUIRED",
        "explanation": "Full subject issuer chain Secure Sockets Layer (SSL) principal name expected from the server.",
    },
    "0x80010122": {
        "name": "RPC_E_INVALID_STD_NAME",
        "explanation": "Principal name is not a valid Microsoft standard (msstd) name.",
    },
    "0x80010123": {"name": "CO_E_FAILEDTOIMPERSONATE", "explanation": "Unable to impersonate DCOM client."},
    "0x80010124": {"name": "CO_E_FAILEDTOGETSECCTX", "explanation": "Unable to obtain server's security context."},
    "0x80010125": {
        "name": "CO_E_FAILEDTOOPENTHREADTOKEN",
        "explanation": "Unable to open the access token of the current thread.",
    },
    "0x80010126": {
        "name": "CO_E_FAILEDTOGETTOKENINFO",
        "explanation": "Unable to obtain user information from an access token.",
    },
    "0x80010127": {
        "name": "CO_E_TRUSTEEDOESNTMATCHCLIENT",
        "explanation": "The client who called IAccessControl::IsAccessPermitted was not the trustee provided to the method.",
    },
    "0x80010128": {
        "name": "CO_E_FAILEDTOQUERYCLIENTBLANKET",
        "explanation": "Unable to obtain the client's security blanket.",
    },
    "0x80010129": {
        "name": "CO_E_FAILEDTOSETDACL",
        "explanation": "Unable to set a discretionary access control list (ACL) into a security descriptor.",
    },
    "0x8001012A": {"name": "CO_E_ACCESSCHECKFAILED", "explanation": "The system function AccessCheck returned false."},
    "0x8001012B": {
        "name": "CO_E_NETACCESSAPIFAILED",
        "explanation": "Either NetAccessDel or NetAccessAdd returned an error code.",
    },
    "0x8001012C": {
        "name": "CO_E_WRONGTRUSTEENAMESYNTAX",
        "explanation": 'One of the trustee strings provided by the user did not conform to the <Domain>\\<Name> syntax and it was not the *" string".',
    },
    "0x8001012D": {
        "name": "CO_E_INVALIDSID",
        "explanation": "One of the security identifiers provided by the user was invalid.",
    },
    "0x8001012E": {
        "name": "CO_E_CONVERSIONFAILED",
        "explanation": "Unable to convert a wide character trustee string to a multiple-byte trustee string.",
    },
    "0x8001012F": {
        "name": "CO_E_NOMATCHINGSIDFOUND",
        "explanation": "Unable to find a security identifier that corresponds to a trustee string provided by the user.",
    },
    "0x80010130": {"name": "CO_E_LOOKUPACCSIDFAILED", "explanation": "The system function LookupAccountSID failed."},
    "0x80010131": {
        "name": "CO_E_NOMATCHINGNAMEFOUND",
        "explanation": "Unable to find a trustee name that corresponds to a security identifier provided by the user.",
    },
    "0x80010132": {"name": "CO_E_LOOKUPACCNAMEFAILED", "explanation": "The system function LookupAccountName failed."},
    "0x80010133": {"name": "CO_E_SETSERLHNDLFAILED", "explanation": "Unable to set or reset a serialization handle."},
    "0x80010134": {"name": "CO_E_FAILEDTOGETWINDIR", "explanation": "Unable to obtain the Windows directory."},
    "0x80010135": {"name": "CO_E_PATHTOOLONG", "explanation": "Path too long."},
    "0x80010136": {"name": "CO_E_FAILEDTOGENUUID", "explanation": "Unable to generate a UUID."},
    "0x80010137": {"name": "CO_E_FAILEDTOCREATEFILE", "explanation": "Unable to create file."},
    "0x80010138": {
        "name": "CO_E_FAILEDTOCLOSEHANDLE",
        "explanation": "Unable to close a serialization handle or a file handle.",
    },
    "0x80010139": {
        "name": "CO_E_EXCEEDSYSACLLIMIT",
        "explanation": "The number of access control entries (ACEs) in an ACL exceeds the system limit.",
    },
    "0x8001013A": {
        "name": "CO_E_ACESINWRONGORDER",
        "explanation": "Not all the DENY_ACCESS ACEs are arranged in front of the GRANT_ACCESS ACEs in the stream.",
    },
    "0x8001013B": {
        "name": "CO_E_INCOMPATIBLESTREAMVERSION",
        "explanation": "The version of ACL format in the stream is not supported by this implementation of IAccessControl.",
    },
    "0x8001013C": {
        "name": "CO_E_FAILEDTOOPENPROCESSTOKEN",
        "explanation": "Unable to open the access token of the server process.",
    },
    "0x8001013D": {
        "name": "CO_E_DECODEFAILED",
        "explanation": "Unable to decode the ACL in the stream provided by the user.",
    },
    "0x8001013F": {"name": "CO_E_ACNOTINITIALIZED", "explanation": "The COM IAccessControl object is not initialized."},
    "0x80010140": {"name": "CO_E_CANCEL_DISABLED", "explanation": "Call Cancellation is disabled."},
    "0x8001FFFF": {"name": "RPC_E_UNEXPECTED", "explanation": "An internal error occurred."},
    "0x80020001": {"name": "DISP_E_UNKNOWNINTERFACE", "explanation": "Unknown interface."},
    "0x80020003": {"name": "DISP_E_MEMBERNOTFOUND", "explanation": "Member not found."},
    "0x80020004": {"name": "DISP_E_PARAMNOTFOUND", "explanation": "Parameter not found."},
    "0x80020005": {"name": "DISP_E_TYPEMISMATCH", "explanation": "Type mismatch."},
    "0x80020006": {"name": "DISP_E_UNKNOWNNAME", "explanation": "Unknown name."},
    "0x80020007": {"name": "DISP_E_NONAMEDARGS", "explanation": "No named arguments."},
    "0x80020008": {"name": "DISP_E_BADVARTYPE", "explanation": "Bad variable type."},
    "0x80020009": {"name": "DISP_E_EXCEPTION", "explanation": "Exception occurred."},
    "0x8002000A": {"name": "DISP_E_OVERFLOW", "explanation": "Out of present range."},
    "0x8002000B": {"name": "DISP_E_BADINDEX", "explanation": "Invalid index."},
    "0x8002000C": {"name": "DISP_E_UNKNOWNLCID", "explanation": "Unknown language."},
    "0x8002000D": {"name": "DISP_E_ARRAYISLOCKED", "explanation": "Memory is locked."},
    "0x8002000E": {"name": "DISP_E_BADPARAMCOUNT", "explanation": "Invalid number of parameters."},
    "0x8002000F": {"name": "DISP_E_PARAMNOTOPTIONAL", "explanation": "Parameter not optional."},
    "0x80020010": {"name": "DISP_E_BADCALLEE", "explanation": "Invalid callee."},
    "0x80020011": {"name": "DISP_E_NOTACOLLECTION", "explanation": "Does not support a collection."},
    "0x80020012": {"name": "DISP_E_DIVBYZERO", "explanation": "Division by zero."},
    "0x80020013": {"name": "DISP_E_BUFFERTOOSMALL", "explanation": "Buffer too small."},
    "0x80028016": {"name": "TYPE_E_BUFFERTOOSMALL", "explanation": "Buffer too small."},
    "0x80028017": {"name": "TYPE_E_FIELDNOTFOUND", "explanation": "Field name not defined in the record."},
    "0x80028018": {"name": "TYPE_E_INVDATAREAD", "explanation": "Old format or invalid type library."},
    "0x80028019": {"name": "TYPE_E_UNSUPFORMAT", "explanation": "Old format or invalid type library."},
    "0x8002801C": {"name": "TYPE_E_REGISTRYACCESS", "explanation": "Error accessing the OLE registry."},
    "0x8002801D": {"name": "TYPE_E_LIBNOTREGISTERED", "explanation": "Library not registered."},
    "0x80028027": {"name": "TYPE_E_UNDEFINEDTYPE", "explanation": "Bound to unknown type."},
    "0x80028028": {"name": "TYPE_E_QUALIFIEDNAMEDISALLOWED", "explanation": "Qualified name disallowed."},
    "0x80028029": {
        "name": "TYPE_E_INVALIDSTATE",
        "explanation": "Invalid forward reference, or reference to uncompiled type.",
    },
    "0x8002802A": {"name": "TYPE_E_WRONGTYPEKIND", "explanation": "Type mismatch."},
    "0x8002802B": {"name": "TYPE_E_ELEMENTNOTFOUND", "explanation": "Element not found."},
    "0x8002802C": {"name": "TYPE_E_AMBIGUOUSNAME", "explanation": "Ambiguous name."},
    "0x8002802D": {"name": "TYPE_E_NAMECONFLICT", "explanation": "Name already exists in the library."},
    "0x8002802E": {"name": "TYPE_E_UNKNOWNLCID", "explanation": "Unknown language code identifier (LCID)."},
    "0x8002802F": {"name": "TYPE_E_DLLFUNCTIONNOTFOUND", "explanation": "Function not defined in specified DLL."},
    "0x800288BD": {"name": "TYPE_E_BADMODULEKIND", "explanation": "Wrong module kind for the operation."},
    "0x800288C5": {"name": "TYPE_E_SIZETOOBIG", "explanation": "Size cannot exceed 64 KB."},
    "0x800288C6": {"name": "TYPE_E_DUPLICATEID", "explanation": "Duplicate ID in inheritance hierarchy."},
    "0x800288CF": {"name": "TYPE_E_INVALIDID", "explanation": "Incorrect inheritance depth in standard OLE hmember."},
    "0x80028CA0": {"name": "TYPE_E_TYPEMISMATCH", "explanation": "Type mismatch."},
    "0x80028CA1": {"name": "TYPE_E_OUTOFBOUNDS", "explanation": "Invalid number of arguments."},
    "0x80028CA2": {"name": "TYPE_E_IOERROR", "explanation": "I/O error."},
    "0x80028CA3": {"name": "TYPE_E_CANTCREATETMPFILE", "explanation": "Error creating unique .tmp file."},
    "0x80029C4A": {"name": "TYPE_E_CANTLOADLIBRARY", "explanation": "Error loading type library or DLL."},
    "0x80029C83": {"name": "TYPE_E_INCONSISTENTPROPFUNCS", "explanation": "Inconsistent property functions."},
    "0x80029C84": {"name": "TYPE_E_CIRCULARTYPE", "explanation": "Circular dependency between types and modules."},
    "0x80030001": {"name": "STG_E_INVALIDFUNCTION", "explanation": "Unable to perform requested operation."},
    "0x80030002": {"name": "STG_E_FILENOTFOUND", "explanation": "%1 could not be found."},
    "0x80030003": {"name": "STG_E_PATHNOTFOUND", "explanation": "The path %1 could not be found."},
    "0x80030004": {
        "name": "STG_E_TOOMANYOPENFILES",
        "explanation": "There are insufficient resources to open another file.",
    },
    "0x80030005": {"name": "STG_E_ACCESSDENIED", "explanation": "Access denied."},
    "0x80030006": {"name": "STG_E_INVALIDHANDLE", "explanation": "Attempted an operation on an invalid object."},
    "0x80030008": {
        "name": "STG_E_INSUFFICIENTMEMORY",
        "explanation": "There is insufficient memory available to complete operation.",
    },
    "0x80030009": {"name": "STG_E_INVALIDPOINTER", "explanation": "Invalid pointer error."},
    "0x80030012": {"name": "STG_E_NOMOREFILES", "explanation": "There are no more entries to return."},
    "0x80030013": {"name": "STG_E_DISKISWRITEPROTECTED", "explanation": "Disk is write-protected."},
    "0x80030019": {"name": "STG_E_SEEKERROR", "explanation": "An error occurred during a seek operation."},
    "0x8003001D": {"name": "STG_E_WRITEFAULT", "explanation": "A disk error occurred during a write operation."},
    "0x8003001E": {"name": "STG_E_READFAULT", "explanation": "A disk error occurred during a read operation."},
    "0x80030020": {"name": "STG_E_SHAREVIOLATION", "explanation": "A share violation has occurred."},
    "0x80030021": {"name": "STG_E_LOCKVIOLATION", "explanation": "A lock violation has occurred."},
    "0x80030050": {"name": "STG_E_FILEALREADYEXISTS", "explanation": "%1 already exists."},
    "0x80030057": {"name": "STG_E_INVALIDPARAMETER", "explanation": "Invalid parameter error."},
    "0x80030070": {
        "name": "STG_E_MEDIUMFULL",
        "explanation": "There is insufficient disk space to complete operation.",
    },
    "0x800300F0": {
        "name": "STG_E_PROPSETMISMATCHED",
        "explanation": "Illegal write of non-simple property to simple property set.",
    },
    "0x800300FA": {
        "name": "STG_E_ABNORMALAPIEXIT",
        "explanation": "An application programming interface (API) call exited abnormally.",
    },
    "0x800300FB": {"name": "STG_E_INVALIDHEADER", "explanation": "The file %1 is not a valid compound file."},
    "0x800300FC": {"name": "STG_E_INVALIDNAME", "explanation": "The name %1 is not valid."},
    "0x800300FD": {"name": "STG_E_UNKNOWN", "explanation": "An unexpected error occurred."},
    "0x800300FE": {"name": "STG_E_UNIMPLEMENTEDFUNCTION", "explanation": "That function is not implemented."},
    "0x800300FF": {"name": "STG_E_INVALIDFLAG", "explanation": "Invalid flag error."},
    "0x80030100": {"name": "STG_E_INUSE", "explanation": "Attempted to use an object that is busy."},
    "0x80030101": {"name": "STG_E_NOTCURRENT", "explanation": "The storage has been changed since the last commit."},
    "0x80030102": {"name": "STG_E_REVERTED", "explanation": "Attempted to use an object that has ceased to exist."},
    "0x80030103": {"name": "STG_E_CANTSAVE", "explanation": "Cannot save."},
    "0x80030104": {
        "name": "STG_E_OLDFORMAT",
        "explanation": "The compound file %1 was produced with an incompatible version of storage.",
    },
    "0x80030105": {
        "name": "STG_E_OLDDLL",
        "explanation": "The compound file %1 was produced with a newer version of storage.",
    },
    "0x80030106": {"name": "STG_E_SHAREREQUIRED", "explanation": "Share.exe or equivalent is required for operation."},
    "0x80030107": {
        "name": "STG_E_NOTFILEBASEDSTORAGE",
        "explanation": "Illegal operation called on non-file based storage.",
    },
    "0x80030108": {
        "name": "STG_E_EXTANTMARSHALLINGS",
        "explanation": "Illegal operation called on object with extant marshalings.",
    },
    "0x80030109": {"name": "STG_E_DOCFILECORRUPT", "explanation": "The docfile has been corrupted."},
    "0x80030110": {"name": "STG_E_BADBASEADDRESS", "explanation": "OLE32.DLL has been loaded at the wrong address."},
    "0x80030111": {
        "name": "STG_E_DOCFILETOOLARGE",
        "explanation": "The compound file is too large for the current implementation.",
    },
    "0x80030112": {
        "name": "STG_E_NOTSIMPLEFORMAT",
        "explanation": "The compound file was not created with the STGM_SIMPLE flag.",
    },
    "0x80030201": {
        "name": "STG_E_INCOMPLETE",
        "explanation": "The file download was aborted abnormally. The file is incomplete.",
    },
    "0x80030202": {"name": "STG_E_TERMINATED", "explanation": "The file download has been terminated."},
    "0x80030305": {"name": "STG_E_STATUS_COPY_PROTECTION_FAILURE", "explanation": "Generic Copy Protection Error."},
    "0x80030306": {
        "name": "STG_E_CSS_AUTHENTICATION_FAILURE",
        "explanation": "Copy Protection Errorâ€”DVD CSS Authentication failed.",
    },
    "0x80030307": {
        "name": "STG_E_CSS_KEY_NOT_PRESENT",
        "explanation": "Copy Protection Errorâ€”The given sector does not have a valid CSS key.",
    },
    "0x80030308": {
        "name": "STG_E_CSS_KEY_NOT_ESTABLISHED",
        "explanation": "Copy Protection Errorâ€”DVD session key not established.",
    },
    "0x80030309": {
        "name": "STG_E_CSS_SCRAMBLED_SECTOR",
        "explanation": "Copy Protection Errorâ€”The read failed because the sector is encrypted.",
    },
    "0x8003030A": {
        "name": "STG_E_CSS_REGION_MISMATCH",
        "explanation": "Copy Protection Errorâ€”The current DVD's region does not correspond to the region setting of the drive.",
    },
    "0x8003030B": {
        "name": "STG_E_RESETS_EXHAUSTED",
        "explanation": "Copy Protection Errorâ€”The drive's region setting might be permanent or the number of user resets has been exhausted.",
    },
    "0x80040000": {"name": "OLE_E_OLEVERB", "explanation": "Invalid OLEVERB structure."},
    "0x80040001": {"name": "OLE_E_ADVF", "explanation": "Invalid advise flags."},
    "0x80040002": {
        "name": "OLE_E_ENUM_NOMORE",
        "explanation": "Cannot enumerate any more because the associated data is missing.",
    },
    "0x80040003": {"name": "OLE_E_ADVISENOTSUPPORTED", "explanation": "This implementation does not take advises."},
    "0x80040004": {"name": "OLE_E_NOCONNECTION", "explanation": "There is no connection for this connection ID."},
    "0x80040005": {"name": "OLE_E_NOTRUNNING", "explanation": "Need to run the object to perform this operation."},
    "0x80040006": {"name": "OLE_E_NOCACHE", "explanation": "There is no cache to operate on."},
    "0x80040007": {"name": "OLE_E_BLANK", "explanation": "Uninitialized object."},
    "0x80040008": {"name": "OLE_E_CLASSDIFF", "explanation": "Linked object's source class has changed."},
    "0x80040009": {"name": "OLE_E_CANT_GETMONIKER", "explanation": "Not able to get the moniker of the object."},
    "0x8004000A": {"name": "OLE_E_CANT_BINDTOSOURCE", "explanation": "Not able to bind to the source."},
    "0x8004000B": {"name": "OLE_E_STATIC", "explanation": "Object is static; operation not allowed."},
    "0x8004000C": {"name": "OLE_E_PROMPTSAVECANCELLED", "explanation": "User canceled out of the Save dialog box."},
    "0x8004000D": {"name": "OLE_E_INVALIDRECT", "explanation": "Invalid rectangle."},
    "0x8004000E": {"name": "OLE_E_WRONGCOMPOBJ", "explanation": "compobj.dll is too old for the ole2.dll initialized."},
    "0x8004000F": {"name": "OLE_E_INVALIDHWND", "explanation": "Invalid window handle."},
    "0x80040010": {
        "name": "OLE_E_NOT_INPLACEACTIVE",
        "explanation": "Object is not in any of the inplace active states.",
    },
    "0x80040011": {"name": "OLE_E_CANTCONVERT", "explanation": "Not able to convert object."},
    "0x80040012": {
        "name": "OLE_E_NOSTORAGE",
        "explanation": "Not able to perform the operation because object is not given storage yet.",
    },
    "0x80040064": {"name": "DV_E_FORMATETC", "explanation": "Invalid FORMATETC structure."},
    "0x80040065": {"name": "DV_E_DVTARGETDEVICE", "explanation": "Invalid DVTARGETDEVICE structure."},
    "0x80040066": {"name": "DV_E_STGMEDIUM", "explanation": "Invalid STDGMEDIUM structure."},
    "0x80040067": {"name": "DV_E_STATDATA", "explanation": "Invalid STATDATA structure."},
    "0x80040068": {"name": "DV_E_LINDEX", "explanation": "Invalid lindex."},
    "0x80040069": {"name": "DV_E_TYMED", "explanation": "Invalid TYMED structure."},
    "0x8004006A": {"name": "DV_E_CLIPFORMAT", "explanation": "Invalid clipboard format."},
    "0x8004006B": {"name": "DV_E_DVASPECT", "explanation": "Invalid aspects."},
    "0x8004006C": {
        "name": "DV_E_DVTARGETDEVICE_SIZE",
        "explanation": "The tdSize parameter of the DVTARGETDEVICE structure is invalid.",
    },
    "0x8004006D": {"name": "DV_E_NOIVIEWOBJECT", "explanation": "Object does not support IViewObject interface."},
    "0x80040100": {
        "name": "DRAGDROP_E_NOTREGISTERED",
        "explanation": "Trying to revoke a drop target that has not been registered.",
    },
    "0x80040101": {
        "name": "DRAGDROP_E_ALREADYREGISTERED",
        "explanation": "This window has already been registered as a drop target.",
    },
    "0x80040102": {"name": "DRAGDROP_E_INVALIDHWND", "explanation": "Invalid window handle."},
    "0x80040110": {
        "name": "CLASS_E_NOAGGREGATION",
        "explanation": "Class does not support aggregation (or class object is remote).",
    },
    "0x80040111": {"name": "CLASS_E_CLASSNOTAVAILABLE", "explanation": "ClassFactory cannot supply requested class."},
    "0x80040112": {"name": "CLASS_E_NOTLICENSED", "explanation": "Class is not licensed for use."},
    "0x80040140": {"name": "VIEW_E_DRAW", "explanation": "Error drawing view."},
    "0x80040150": {"name": "REGDB_E_READREGDB", "explanation": "Could not read key from registry."},
    "0x80040151": {"name": "REGDB_E_WRITEREGDB", "explanation": "Could not write key to registry."},
    "0x80040152": {"name": "REGDB_E_KEYMISSING", "explanation": "Could not find the key in the registry."},
    "0x80040153": {"name": "REGDB_E_INVALIDVALUE", "explanation": "Invalid value for registry."},
    "0x80040154": {"name": "REGDB_E_CLASSNOTREG", "explanation": "Class not registered."},
    "0x80040155": {"name": "REGDB_E_IIDNOTREG", "explanation": "Interface not registered."},
    "0x80040156": {"name": "REGDB_E_BADTHREADINGMODEL", "explanation": "Threading model entry is not valid."},
    "0x80040160": {"name": "CAT_E_CATIDNOEXIST", "explanation": "CATID does not exist."},
    "0x80040161": {"name": "CAT_E_NODESCRIPTION", "explanation": "Description not found."},
    "0x80040164": {
        "name": "CS_E_PACKAGE_NOTFOUND",
        "explanation": "No package in the software installation data in Active Directory meets this criteria.",
    },
    "0x80040165": {
        "name": "CS_E_NOT_DELETABLE",
        "explanation": "Deleting this will break the referential integrity of the software installation data in Active Directory.",
    },
    "0x80040166": {
        "name": "CS_E_CLASS_NOTFOUND",
        "explanation": "The CLSID was not found in the software installation data in Active Directory.",
    },
    "0x80040167": {
        "name": "CS_E_INVALID_VERSION",
        "explanation": "The software installation data in Active Directory is corrupt.",
    },
    "0x80040168": {
        "name": "CS_E_NO_CLASSSTORE",
        "explanation": "There is no software installation data in Active Directory.",
    },
    "0x80040169": {
        "name": "CS_E_OBJECT_NOTFOUND",
        "explanation": "There is no software installation data object in Active Directory.",
    },
    "0x8004016A": {
        "name": "CS_E_OBJECT_ALREADY_EXISTS",
        "explanation": "The software installation data object in Active Directory already exists.",
    },
    "0x8004016B": {
        "name": "CS_E_INVALID_PATH",
        "explanation": "The path to the software installation data in Active Directory is not correct.",
    },
    "0x8004016C": {"name": "CS_E_NETWORK_ERROR", "explanation": "A network error interrupted the operation."},
    "0x8004016D": {
        "name": "CS_E_ADMIN_LIMIT_EXCEEDED",
        "explanation": "The size of this object exceeds the maximum size set by the administrator.",
    },
    "0x8004016E": {
        "name": "CS_E_SCHEMA_MISMATCH",
        "explanation": "The schema for the software installation data in Active Directory does not match the required schema.",
    },
    "0x8004016F": {
        "name": "CS_E_INTERNAL_ERROR",
        "explanation": "An error occurred in the software installation data in Active Directory.",
    },
    "0x80040170": {"name": "CACHE_E_NOCACHE_UPDATED", "explanation": "Cache not updated."},
    "0x80040180": {"name": "OLEOBJ_E_NOVERBS", "explanation": "No verbs for OLE object."},
    "0x80040181": {"name": "OLEOBJ_E_INVALIDVERB", "explanation": "Invalid verb for OLE object."},
    "0x800401A0": {"name": "INPLACE_E_NOTUNDOABLE", "explanation": "Undo is not available."},
    "0x800401A1": {"name": "INPLACE_E_NOTOOLSPACE", "explanation": "Space for tools is not available."},
    "0x800401C0": {"name": "CONVERT10_E_OLESTREAM_GET", "explanation": "OLESTREAM Get method failed."},
    "0x800401C1": {"name": "CONVERT10_E_OLESTREAM_PUT", "explanation": "OLESTREAM Put method failed."},
    "0x800401C2": {
        "name": "CONVERT10_E_OLESTREAM_FMT",
        "explanation": "Contents of the OLESTREAM not in correct format.",
    },
    "0x800401C3": {
        "name": "CONVERT10_E_OLESTREAM_BITMAP_TO_DIB",
        "explanation": "There was an error in a Windows GDI call while converting the bitmap to a device-independent bitmap (DIB).",
    },
    "0x800401C4": {"name": "CONVERT10_E_STG_FMT", "explanation": "Contents of the IStorage not in correct format."},
    "0x800401C5": {
        "name": "CONVERT10_E_STG_NO_STD_STREAM",
        "explanation": "Contents of IStorage is missing one of the standard streams.",
    },
    "0x800401C6": {
        "name": "CONVERT10_E_STG_DIB_TO_BITMAP",
        "explanation": "There was an error in a Windows Graphics Device Interface (GDI) call while converting the DIB to a bitmap.",
    },
    "0x800401D0": {"name": "CLIPBRD_E_CANT_OPEN", "explanation": "OpenClipboard failed."},
    "0x800401D1": {"name": "CLIPBRD_E_CANT_EMPTY", "explanation": "EmptyClipboard failed."},
    "0x800401D2": {"name": "CLIPBRD_E_CANT_SET", "explanation": "SetClipboard failed."},
    "0x800401D3": {"name": "CLIPBRD_E_BAD_DATA", "explanation": "Data on clipboard is invalid."},
    "0x800401D4": {"name": "CLIPBRD_E_CANT_CLOSE", "explanation": "CloseClipboard failed."},
    "0x800401E0": {"name": "MK_E_CONNECTMANUALLY", "explanation": "Moniker needs to be connected manually."},
    "0x800401E1": {"name": "MK_E_EXCEEDEDDEADLINE", "explanation": "Operation exceeded deadline."},
    "0x800401E2": {"name": "MK_E_NEEDGENERIC", "explanation": "Moniker needs to be generic."},
    "0x800401E3": {"name": "MK_E_UNAVAILABLE", "explanation": "Operation unavailable."},
    "0x800401E4": {"name": "MK_E_SYNTAX", "explanation": "Invalid syntax."},
    "0x800401E5": {"name": "MK_E_NOOBJECT", "explanation": "No object for moniker."},
    "0x800401E6": {"name": "MK_E_INVALIDEXTENSION", "explanation": "Bad extension for file."},
    "0x800401E7": {"name": "MK_E_INTERMEDIATEINTERFACENOTSUPPORTED", "explanation": "Intermediate operation failed."},
    "0x800401E8": {"name": "MK_E_NOTBINDABLE", "explanation": "Moniker is not bindable."},
    "0x800401E9": {"name": "MK_E_NOTBOUND", "explanation": "Moniker is not bound."},
    "0x800401EA": {"name": "MK_E_CANTOPENFILE", "explanation": "Moniker cannot open file."},
    "0x800401EB": {"name": "MK_E_MUSTBOTHERUSER", "explanation": "User input required for operation to succeed."},
    "0x800401EC": {"name": "MK_E_NOINVERSE", "explanation": "Moniker class has no inverse."},
    "0x800401ED": {"name": "MK_E_NOSTORAGE", "explanation": "Moniker does not refer to storage."},
    "0x800401EE": {"name": "MK_E_NOPREFIX", "explanation": "No common prefix."},
    "0x800401EF": {"name": "MK_E_ENUMERATION_FAILED", "explanation": "Moniker could not be enumerated."},
    "0x800401F0": {"name": "CO_E_NOTINITIALIZED", "explanation": "CoInitialize has not been called."},
    "0x800401F1": {"name": "CO_E_ALREADYINITIALIZED", "explanation": "CoInitialize has already been called."},
    "0x800401F2": {"name": "CO_E_CANTDETERMINECLASS", "explanation": "Class of object cannot be determined."},
    "0x800401F3": {"name": "CO_E_CLASSSTRING", "explanation": "Invalid class string."},
    "0x800401F4": {"name": "CO_E_IIDSTRING", "explanation": "Invalid interface string."},
    "0x800401F5": {"name": "CO_E_APPNOTFOUND", "explanation": "Application not found."},
    "0x800401F6": {"name": "CO_E_APPSINGLEUSE", "explanation": "Application cannot be run more than once."},
    "0x800401F7": {"name": "CO_E_ERRORINAPP", "explanation": "Some error in application."},
    "0x800401F8": {"name": "CO_E_DLLNOTFOUND", "explanation": "DLL for class not found."},
    "0x800401F9": {"name": "CO_E_ERRORINDLL", "explanation": "Error in the DLL."},
    "0x800401FA": {
        "name": "CO_E_WRONGOSFORAPP",
        "explanation": "Wrong operating system or operating system version for application.",
    },
    "0x800401FB": {"name": "CO_E_OBJNOTREG", "explanation": "Object is not registered."},
    "0x800401FC": {"name": "CO_E_OBJISREG", "explanation": "Object is already registered."},
    "0x800401FD": {"name": "CO_E_OBJNOTCONNECTED", "explanation": "Object is not connected to server."},
    "0x800401FE": {
        "name": "CO_E_APPDIDNTREG",
        "explanation": "Application was launched, but it did not register a class factory.",
    },
    "0x800401FF": {"name": "CO_E_RELEASED", "explanation": "Object has been released."},
    "0x80040201": {
        "name": "EVENT_E_ALL_SUBSCRIBERS_FAILED",
        "explanation": "An event was unable to invoke any of the subscribers.",
    },
    "0x80040203": {
        "name": "EVENT_E_QUERYSYNTAX",
        "explanation": "A syntax error occurred trying to evaluate a query string.",
    },
    "0x80040204": {"name": "EVENT_E_QUERYFIELD", "explanation": "An invalid field name was used in a query string."},
    "0x80040205": {"name": "EVENT_E_INTERNALEXCEPTION", "explanation": "An unexpected exception was raised."},
    "0x80040206": {"name": "EVENT_E_INTERNALERROR", "explanation": "An unexpected internal error was detected."},
    "0x80040207": {
        "name": "EVENT_E_INVALID_PER_USER_SID",
        "explanation": "The owner security identifier (SID) on a per-user subscription does not exist.",
    },
    "0x80040208": {
        "name": "EVENT_E_USER_EXCEPTION",
        "explanation": "A user-supplied component or subscriber raised an exception.",
    },
    "0x80040209": {
        "name": "EVENT_E_TOO_MANY_METHODS",
        "explanation": "An interface has too many methods to fire events from.",
    },
    "0x8004020A": {
        "name": "EVENT_E_MISSING_EVENTCLASS",
        "explanation": "A subscription cannot be stored unless its event class already exists.",
    },
    "0x8004020B": {"name": "EVENT_E_NOT_ALL_REMOVED", "explanation": "Not all the objects requested could be removed."},
    "0x8004020C": {
        "name": "EVENT_E_COMPLUS_NOT_INSTALLED",
        "explanation": "COM+ is required for this operation, but it is not installed.",
    },
    "0x8004020D": {
        "name": "EVENT_E_CANT_MODIFY_OR_DELETE_UNCONFIGURED_OBJECT",
        "explanation": "Cannot modify or delete an object that was not added using the COM+ Administrative SDK.",
    },
    "0x8004020E": {
        "name": "EVENT_E_CANT_MODIFY_OR_DELETE_CONFIGURED_OBJECT",
        "explanation": "Cannot modify or delete an object that was added using the COM+ Administrative SDK.",
    },
    "0x8004020F": {
        "name": "EVENT_E_INVALID_EVENT_CLASS_PARTITION",
        "explanation": "The event class for this subscription is in an invalid partition.",
    },
    "0x80040210": {
        "name": "EVENT_E_PER_USER_SID_NOT_LOGGED_ON",
        "explanation": "The owner of the PerUser subscription is not logged on to the system specified.",
    },
    "0x80041309": {"name": "SCHED_E_TRIGGER_NOT_FOUND", "explanation": "Trigger not found."},
    "0x8004130A": {
        "name": "SCHED_E_TASK_NOT_READY",
        "explanation": "One or more of the properties that are needed to run this task have not been set.",
    },
    "0x8004130B": {"name": "SCHED_E_TASK_NOT_RUNNING", "explanation": "There is no running instance of the task."},
    "0x8004130C": {
        "name": "SCHED_E_SERVICE_NOT_INSTALLED",
        "explanation": "The Task Scheduler service is not installed on this computer.",
    },
    "0x8004130D": {"name": "SCHED_E_CANNOT_OPEN_TASK", "explanation": "The task object could not be opened."},
    "0x8004130E": {
        "name": "SCHED_E_INVALID_TASK",
        "explanation": "The object is either an invalid task object or is not a task object.",
    },
    "0x8004130F": {
        "name": "SCHED_E_ACCOUNT_INFORMATION_NOT_SET",
        "explanation": "No account information could be found in the Task Scheduler security database for the task indicated.",
    },
    "0x80041310": {
        "name": "SCHED_E_ACCOUNT_NAME_NOT_FOUND",
        "explanation": "Unable to establish existence of the account specified.",
    },
    "0x80041311": {
        "name": "SCHED_E_ACCOUNT_DBASE_CORRUPT",
        "explanation": "Corruption was detected in the Task Scheduler security database; the database has been reset.",
    },
    "0x80041312": {
        "name": "SCHED_E_NO_SECURITY_SERVICES",
        "explanation": "Task Scheduler security services are available only on Windows NT operating system.",
    },
    "0x80041313": {
        "name": "SCHED_E_UNKNOWN_OBJECT_VERSION",
        "explanation": "The task object version is either unsupported or invalid.",
    },
    "0x80041314": {
        "name": "SCHED_E_UNSUPPORTED_ACCOUNT_OPTION",
        "explanation": "The task has been configured with an unsupported combination of account settings and run-time options.",
    },
    "0x80041315": {"name": "SCHED_E_SERVICE_NOT_RUNNING", "explanation": "The Task Scheduler service is not running."},
    "0x80041316": {"name": "SCHED_E_UNEXPECTEDNODE", "explanation": "The task XML contains an unexpected node."},
    "0x80041317": {
        "name": "SCHED_E_NAMESPACE",
        "explanation": "The task XML contains an element or attribute from an unexpected namespace.",
    },
    "0x80041318": {
        "name": "SCHED_E_INVALIDVALUE",
        "explanation": "The task XML contains a value that is incorrectly formatted or out of range.",
    },
    "0x80041319": {
        "name": "SCHED_E_MISSINGNODE",
        "explanation": "The task XML is missing a required element or attribute.",
    },
    "0x8004131A": {"name": "SCHED_E_MALFORMEDXML", "explanation": "The task XML is malformed."},
    "0x8004131D": {
        "name": "SCHED_E_TOO_MANY_NODES",
        "explanation": "The task XML contains too many nodes of the same type.",
    },
    "0x8004131E": {
        "name": "SCHED_E_PAST_END_BOUNDARY",
        "explanation": "The task cannot be started after the trigger's end boundary.",
    },
    "0x8004131F": {"name": "SCHED_E_ALREADY_RUNNING", "explanation": "An instance of this task is already running."},
    "0x80041320": {
        "name": "SCHED_E_USER_NOT_LOGGED_ON",
        "explanation": "The task will not run because the user is not logged on.",
    },
    "0x80041321": {
        "name": "SCHED_E_INVALID_TASK_HASH",
        "explanation": "The task image is corrupt or has been tampered with.",
    },
    "0x80041322": {
        "name": "SCHED_E_SERVICE_NOT_AVAILABLE",
        "explanation": "The Task Scheduler service is not available.",
    },
    "0x80041323": {
        "name": "SCHED_E_SERVICE_TOO_BUSY",
        "explanation": "The Task Scheduler service is too busy to handle your request. Try again later.",
    },
    "0x80041324": {
        "name": "SCHED_E_TASK_ATTEMPTED",
        "explanation": "The Task Scheduler service attempted to run the task, but the task did not run due to one of the constraints in the task definition.",
    },
    "0x8004D000": {
        "name": "XACT_E_ALREADYOTHERSINGLEPHASE",
        "explanation": "Another single phase resource manager has already been enlisted in this transaction.",
    },
    "0x8004D001": {"name": "XACT_E_CANTRETAIN", "explanation": "A retaining commit or abort is not supported."},
    "0x8004D002": {
        "name": "XACT_E_COMMITFAILED",
        "explanation": "The transaction failed to commit for an unknown reason. The transaction was aborted.",
    },
    "0x8004D003": {
        "name": "XACT_E_COMMITPREVENTED",
        "explanation": "Cannot call commit on this transaction object because the calling application did not initiate the transaction.",
    },
    "0x8004D004": {
        "name": "XACT_E_HEURISTICABORT",
        "explanation": "Instead of committing, the resource heuristically aborted.",
    },
    "0x8004D005": {
        "name": "XACT_E_HEURISTICCOMMIT",
        "explanation": "Instead of aborting, the resource heuristically committed.",
    },
    "0x8004D006": {
        "name": "XACT_E_HEURISTICDAMAGE",
        "explanation": "Some of the states of the resource were committed while others were aborted, likely because of heuristic decisions.",
    },
    "0x8004D007": {
        "name": "XACT_E_HEURISTICDANGER",
        "explanation": "Some of the states of the resource might have been committed while others were aborted, likely because of heuristic decisions.",
    },
    "0x8004D008": {
        "name": "XACT_E_ISOLATIONLEVEL",
        "explanation": "The requested isolation level is not valid or supported.",
    },
    "0x8004D009": {
        "name": "XACT_E_NOASYNC",
        "explanation": "The transaction manager does not support an asynchronous operation for this method.",
    },
    "0x8004D00A": {"name": "XACT_E_NOENLIST", "explanation": "Unable to enlist in the transaction."},
    "0x8004D00B": {
        "name": "XACT_E_NOISORETAIN",
        "explanation": "The requested semantics of retention of isolation across retaining commit and abort boundaries cannot be supported by this transaction implementation, or isoFlags was not equal to 0.",
    },
    "0x8004D00C": {
        "name": "XACT_E_NORESOURCE",
        "explanation": "There is no resource presently associated with this enlistment.",
    },
    "0x8004D00D": {
        "name": "XACT_E_NOTCURRENT",
        "explanation": "The transaction failed to commit due to the failure of optimistic concurrency control in at least one of the resource managers.",
    },
    "0x8004D00E": {
        "name": "XACT_E_NOTRANSACTION",
        "explanation": "The transaction has already been implicitly or explicitly committed or aborted.",
    },
    "0x8004D00F": {"name": "XACT_E_NOTSUPPORTED", "explanation": "An invalid combination of flags was specified."},
    "0x8004D010": {
        "name": "XACT_E_UNKNOWNRMGRID",
        "explanation": "The resource manager ID is not associated with this transaction or the transaction manager.",
    },
    "0x8004D011": {"name": "XACT_E_WRONGSTATE", "explanation": "This method was called in the wrong state."},
    "0x8004D012": {
        "name": "XACT_E_WRONGUOW",
        "explanation": "The indicated unit of work does not match the unit of work expected by the resource manager.",
    },
    "0x8004D013": {"name": "XACT_E_XTIONEXISTS", "explanation": "An enlistment in a transaction already exists."},
    "0x8004D014": {
        "name": "XACT_E_NOIMPORTOBJECT",
        "explanation": "An import object for the transaction could not be found.",
    },
    "0x8004D015": {"name": "XACT_E_INVALIDCOOKIE", "explanation": "The transaction cookie is invalid."},
    "0x8004D016": {
        "name": "XACT_E_INDOUBT",
        "explanation": "The transaction status is in doubt. A communication failure occurred, or a transaction manager or resource manager has failed.",
    },
    "0x8004D017": {
        "name": "XACT_E_NOTIMEOUT",
        "explanation": "A time-out was specified, but time-outs are not supported.",
    },
    "0x8004D018": {
        "name": "XACT_E_ALREADYINPROGRESS",
        "explanation": "The requested operation is already in progress for the transaction.",
    },
    "0x8004D019": {"name": "XACT_E_ABORTED", "explanation": "The transaction has already been aborted."},
    "0x8004D01A": {"name": "XACT_E_LOGFULL", "explanation": "The Transaction Manager returned a log full error."},
    "0x8004D01B": {"name": "XACT_E_TMNOTAVAILABLE", "explanation": "The transaction manager is not available."},
    "0x8004D01C": {
        "name": "XACT_E_CONNECTION_DOWN",
        "explanation": "A connection with the transaction manager was lost.",
    },
    "0x8004D01D": {
        "name": "XACT_E_CONNECTION_DENIED",
        "explanation": "A request to establish a connection with the transaction manager was denied.",
    },
    "0x8004D01E": {
        "name": "XACT_E_REENLISTTIMEOUT",
        "explanation": "Resource manager reenlistment to determine transaction status timed out.",
    },
    "0x8004D01F": {
        "name": "XACT_E_TIP_CONNECT_FAILED",
        "explanation": "The transaction manager failed to establish a connection with another Transaction Internet Protocol (TIP) transaction manager.",
    },
    "0x8004D020": {
        "name": "XACT_E_TIP_PROTOCOL_ERROR",
        "explanation": "The transaction manager encountered a protocol error with another TIP transaction manager.",
    },
    "0x8004D021": {
        "name": "XACT_E_TIP_PULL_FAILED",
        "explanation": "The transaction manager could not propagate a transaction from another TIP transaction manager.",
    },
    "0x8004D022": {
        "name": "XACT_E_DEST_TMNOTAVAILABLE",
        "explanation": "The transaction manager on the destination machine is not available.",
    },
    "0x8004D023": {
        "name": "XACT_E_TIP_DISABLED",
        "explanation": "The transaction manager has disabled its support for TIP.",
    },
    "0x8004D024": {
        "name": "XACT_E_NETWORK_TX_DISABLED",
        "explanation": "The transaction manager has disabled its support for remote or network transactions.",
    },
    "0x8004D025": {
        "name": "XACT_E_PARTNER_NETWORK_TX_DISABLED",
        "explanation": "The partner transaction manager has disabled its support for remote or network transactions.",
    },
    "0x8004D026": {
        "name": "XACT_E_XA_TX_DISABLED",
        "explanation": "The transaction manager has disabled its support for XA transactions.",
    },
    "0x8004D027": {
        "name": "XACT_E_UNABLE_TO_READ_DTC_CONFIG",
        "explanation": "Microsoft Distributed Transaction Coordinator (MSDTC) was unable to read its configuration information.",
    },
    "0x8004D028": {
        "name": "XACT_E_UNABLE_TO_LOAD_DTC_PROXY",
        "explanation": "MSDTC was unable to load the DTC proxy DLL.",
    },
    "0x8004D029": {"name": "XACT_E_ABORTING", "explanation": "The local transaction has aborted."},
    "0x8004D080": {
        "name": "XACT_E_CLERKNOTFOUND",
        "explanation": "The specified CRM clerk was not found. It might have completed before it could be held.",
    },
    "0x8004D081": {"name": "XACT_E_CLERKEXISTS", "explanation": "The specified CRM clerk does not exist."},
    "0x8004D082": {
        "name": "XACT_E_RECOVERYINPROGRESS",
        "explanation": "Recovery of the CRM log file is still in progress.",
    },
    "0x8004D083": {
        "name": "XACT_E_TRANSACTIONCLOSED",
        "explanation": "The transaction has completed, and the log records have been discarded from the log file. They are no longer available.",
    },
    "0x8004D084": {"name": "XACT_E_INVALIDLSN", "explanation": "lsnToRead is outside of the current limits of the log"},
    "0x8004D085": {
        "name": "XACT_E_REPLAYREQUEST",
        "explanation": "The COM+ Compensating Resource Manager has records it wishes to replay.",
    },
    "0x8004D100": {
        "name": "XACT_E_CONNECTION_REQUEST_DENIED",
        "explanation": "The request to connect to the specified transaction coordinator was denied.",
    },
    "0x8004D101": {
        "name": "XACT_E_TOOMANY_ENLISTMENTS",
        "explanation": "The maximum number of enlistments for the specified transaction has been reached.",
    },
    "0x8004D102": {
        "name": "XACT_E_DUPLICATE_GUID",
        "explanation": "A resource manager with the same identifier is already registered with the specified transaction coordinator.",
    },
    "0x8004D103": {
        "name": "XACT_E_NOTSINGLEPHASE",
        "explanation": "The prepare request given was not eligible for single-phase optimizations.",
    },
    "0x8004D104": {
        "name": "XACT_E_RECOVERYALREADYDONE",
        "explanation": "RecoveryComplete has already been called for the given resource manager.",
    },
    "0x8004D105": {
        "name": "XACT_E_PROTOCOL",
        "explanation": "The interface call made was incorrect for the current state of the protocol.",
    },
    "0x8004D106": {"name": "XACT_E_RM_FAILURE", "explanation": "The xa_open call failed for the XA resource."},
    "0x8004D107": {"name": "XACT_E_RECOVERY_FAILED", "explanation": "The xa_recover call failed for the XA resource."},
    "0x8004D108": {"name": "XACT_E_LU_NOT_FOUND", "explanation": "The logical unit of work specified cannot be found."},
    "0x8004D109": {"name": "XACT_E_DUPLICATE_LU", "explanation": "The specified logical unit of work already exists."},
    "0x8004D10A": {
        "name": "XACT_E_LU_NOT_CONNECTED",
        "explanation": "Subordinate creation failed. The specified logical unit of work was not connected.",
    },
    "0x8004D10B": {
        "name": "XACT_E_DUPLICATE_TRANSID",
        "explanation": "A transaction with the given identifier already exists.",
    },
    "0x8004D10C": {"name": "XACT_E_LU_BUSY", "explanation": "The resource is in use."},
    "0x8004D10D": {"name": "XACT_E_LU_NO_RECOVERY_PROCESS", "explanation": "The LU Recovery process is down."},
    "0x8004D10E": {"name": "XACT_E_LU_DOWN", "explanation": "The remote session was lost."},
    "0x8004D10F": {"name": "XACT_E_LU_RECOVERING", "explanation": "The resource is currently recovering."},
    "0x8004D110": {"name": "XACT_E_LU_RECOVERY_MISMATCH", "explanation": "There was a mismatch in driving recovery."},
    "0x8004D111": {"name": "XACT_E_RM_UNAVAILABLE", "explanation": "An error occurred with the XA resource."},
    "0x8004E002": {
        "name": "CONTEXT_E_ABORTED",
        "explanation": "The root transaction wanted to commit, but the transaction aborted.",
    },
    "0x8004E003": {
        "name": "CONTEXT_E_ABORTING",
        "explanation": "The COM+ component on which the method call was made has a transaction that has already aborted or is in the process of aborting.",
    },
    "0x8004E004": {
        "name": "CONTEXT_E_NOCONTEXT",
        "explanation": "There is no Microsoft Transaction Server (MTS) object context.",
    },
    "0x8004E005": {
        "name": "CONTEXT_E_WOULD_DEADLOCK",
        "explanation": "The component is configured to use synchronization, and this method call would cause a deadlock to occur.",
    },
    "0x8004E006": {
        "name": "CONTEXT_E_SYNCH_TIMEOUT",
        "explanation": "The component is configured to use synchronization, and a thread has timed out waiting to enter the context.",
    },
    "0x8004E007": {
        "name": "CONTEXT_E_OLDREF",
        "explanation": "You made a method call on a COM+ component that has a transaction that has already committed or aborted.",
    },
    "0x8004E00C": {
        "name": "CONTEXT_E_ROLENOTFOUND",
        "explanation": "The specified role was not configured for the application.",
    },
    "0x8004E00F": {"name": "CONTEXT_E_TMNOTAVAILABLE", "explanation": "COM+ was unable to talk to the MSDTC."},
    "0x8004E021": {
        "name": "CO_E_ACTIVATIONFAILED",
        "explanation": "An unexpected error occurred during COM+ activation.",
    },
    "0x8004E022": {
        "name": "CO_E_ACTIVATIONFAILED_EVENTLOGGED",
        "explanation": "COM+ activation failed. Check the event log for more information.",
    },
    "0x8004E023": {
        "name": "CO_E_ACTIVATIONFAILED_CATALOGERROR",
        "explanation": "COM+ activation failed due to a catalog or configuration error.",
    },
    "0x8004E024": {
        "name": "CO_E_ACTIVATIONFAILED_TIMEOUT",
        "explanation": "COM+ activation failed because the activation could not be completed in the specified amount of time.",
    },
    "0x8004E025": {
        "name": "CO_E_INITIALIZATIONFAILED",
        "explanation": "COM+ activation failed because an initialization function failed. Check the event log for more information.",
    },
    "0x8004E026": {
        "name": "CONTEXT_E_NOJIT",
        "explanation": "The requested operation requires that just-in-time (JIT) be in the current context, and it is not.",
    },
    "0x8004E027": {
        "name": "CONTEXT_E_NOTRANSACTION",
        "explanation": "The requested operation requires that the current context have a transaction, and it does not.",
    },
    "0x8004E028": {
        "name": "CO_E_THREADINGMODEL_CHANGED",
        "explanation": "The components threading model has changed after install into a COM+ application. Re-install component.",
    },
    "0x8004E029": {
        "name": "CO_E_NOIISINTRINSICS",
        "explanation": "Internet Information Services (IIS) intrinsics not available. Start your work with IIS.",
    },
    "0x8004E02A": {"name": "CO_E_NOCOOKIES", "explanation": "An attempt to write a cookie failed."},
    "0x8004E02B": {
        "name": "CO_E_DBERROR",
        "explanation": "An attempt to use a database generated a database-specific error.",
    },
    "0x8004E02C": {
        "name": "CO_E_NOTPOOLED",
        "explanation": "The COM+ component you created must use object pooling to work.",
    },
    "0x8004E02D": {
        "name": "CO_E_NOTCONSTRUCTED",
        "explanation": "The COM+ component you created must use object construction to work correctly.",
    },
    "0x8004E02E": {
        "name": "CO_E_NOSYNCHRONIZATION",
        "explanation": "The COM+ component requires synchronization, and it is not configured for it.",
    },
    "0x8004E02F": {
        "name": "CO_E_ISOLEVELMISMATCH",
        "explanation": "The TxIsolation Level property for the COM+ component being created is stronger than the TxIsolationLevel for the root.",
    },
    "0x8004E030": {
        "name": "CO_E_CALL_OUT_OF_TX_SCOPE_NOT_ALLOWED",
        "explanation": "The component attempted to make a cross-context call between invocations of EnterTransactionScope and ExitTransactionScope. This is not allowed. Cross-context calls cannot be made while inside a transaction scope.",
    },
    "0x8004E031": {
        "name": "CO_E_EXIT_TRANSACTION_SCOPE_NOT_CALLED",
        "explanation": "The component made a call to EnterTransactionScope, but did not make a corresponding call to ExitTransactionScope before returning.",
    },
    "0x80070005": {"name": "E_ACCESSDENIED", "explanation": "General access denied error."},
    "0x8007000E": {
        "name": "E_OUTOFMEMORY",
        "explanation": "The server does not have enough memory for the new channel.",
    },
    "0x80070032": {
        "name": "ERROR_NOT_SUPPORTED",
        "explanation": "The server cannot support a client request for a dynamic virtual channel.",
    },
    "0x80070057": {"name": "E_INVALIDARG", "explanation": "One or more arguments are invalid."},
    "0x80070070": {"name": "ERROR_DISK_FULL", "explanation": "There is not enough space on the disk."},
    "0x80080001": {"name": "CO_E_CLASS_CREATE_FAILED", "explanation": "Attempt to create a class object failed."},
    "0x80080002": {"name": "CO_E_SCM_ERROR", "explanation": "OLE service could not bind object."},
    "0x80080003": {"name": "CO_E_SCM_RPC_FAILURE", "explanation": "RPC communication failed with OLE service."},
    "0x80080004": {"name": "CO_E_BAD_PATH", "explanation": "Bad path to object."},
    "0x80080005": {"name": "CO_E_SERVER_EXEC_FAILURE", "explanation": "Server execution failed."},
    "0x80080006": {
        "name": "CO_E_OBJSRV_RPC_FAILURE",
        "explanation": "OLE service could not communicate with the object server.",
    },
    "0x80080007": {"name": "MK_E_NO_NORMALIZED", "explanation": "Moniker path could not be normalized."},
    "0x80080008": {
        "name": "CO_E_SERVER_STOPPING",
        "explanation": "Object server is stopping when OLE service contacts it.",
    },
    "0x80080009": {"name": "MEM_E_INVALID_ROOT", "explanation": "An invalid root block pointer was specified."},
    "0x80080010": {
        "name": "MEM_E_INVALID_LINK",
        "explanation": "An allocation chain contained an invalid link pointer.",
    },
    "0x80080011": {"name": "MEM_E_INVALID_SIZE", "explanation": "The requested allocation size was too large."},
    "0x80080015": {
        "name": "CO_E_MISSING_DISPLAYNAME",
        "explanation": "The activation requires a display name to be present under the class identifier (CLSID) key.",
    },
    "0x80080016": {
        "name": "CO_E_RUNAS_VALUE_MUST_BE_AAA",
        "explanation": "The activation requires that the RunAs value for the application is Activate As Activator.",
    },
    "0x80080017": {
        "name": "CO_E_ELEVATION_DISABLED",
        "explanation": "The class is not configured to support elevated activation.",
    },
    "0x80090001": {"name": "NTE_BAD_UID", "explanation": "Bad UID."},
    "0x80090002": {"name": "NTE_BAD_HASH", "explanation": "Bad hash."},
    "0x80090003": {"name": "NTE_BAD_KEY", "explanation": "Bad key."},
    "0x80090004": {"name": "NTE_BAD_LEN", "explanation": "Bad length."},
    "0x80090005": {"name": "NTE_BAD_DATA", "explanation": "Bad data."},
    "0x80090006": {"name": "NTE_BAD_SIGNATURE", "explanation": "Invalid signature."},
    "0x80090007": {"name": "NTE_BAD_VER", "explanation": "Bad version of provider."},
    "0x80090008": {"name": "NTE_BAD_ALGID", "explanation": "Invalid algorithm specified."},
    "0x80090009": {"name": "NTE_BAD_FLAGS", "explanation": "Invalid flags specified."},
    "0x8009000A": {"name": "NTE_BAD_TYPE", "explanation": "Invalid type specified."},
    "0x8009000B": {"name": "NTE_BAD_KEY_STATE", "explanation": "Key not valid for use in specified state."},
    "0x8009000C": {"name": "NTE_BAD_HASH_STATE", "explanation": "Hash not valid for use in specified state."},
    "0x8009000D": {"name": "NTE_NO_KEY", "explanation": "Key does not exist."},
    "0x8009000E": {"name": "NTE_NO_MEMORY", "explanation": "Insufficient memory available for the operation."},
    "0x8009000F": {"name": "NTE_EXISTS", "explanation": "Object already exists."},
    "0x80090010": {"name": "NTE_PERM", "explanation": "Access denied."},
    "0x80090011": {"name": "NTE_NOT_FOUND", "explanation": "Object was not found."},
    "0x80090012": {"name": "NTE_DOUBLE_ENCRYPT", "explanation": "Data already encrypted."},
    "0x80090013": {"name": "NTE_BAD_PROVIDER", "explanation": "Invalid provider specified."},
    "0x80090014": {"name": "NTE_BAD_PROV_TYPE", "explanation": "Invalid provider type specified."},
    "0x80090015": {"name": "NTE_BAD_PUBLIC_KEY", "explanation": "Provider's public key is invalid."},
    "0x80090016": {"name": "NTE_BAD_KEYSET", "explanation": "Key set does not exist."},
    "0x80090017": {"name": "NTE_PROV_TYPE_NOT_DEF", "explanation": "Provider type not defined."},
    "0x80090018": {"name": "NTE_PROV_TYPE_ENTRY_BAD", "explanation": "The provider type, as registered, is invalid."},
    "0x80090019": {"name": "NTE_KEYSET_NOT_DEF", "explanation": "The key set is not defined."},
    "0x8009001A": {"name": "NTE_KEYSET_ENTRY_BAD", "explanation": "The key set, as registered, is invalid."},
    "0x8009001B": {"name": "NTE_PROV_TYPE_NO_MATCH", "explanation": "Provider type does not match registered value."},
    "0x8009001C": {"name": "NTE_SIGNATURE_FILE_BAD", "explanation": "The digital signature file is corrupt."},
    "0x8009001D": {"name": "NTE_PROVIDER_DLL_FAIL", "explanation": "Provider DLL failed to initialize correctly."},
    "0x8009001E": {"name": "NTE_PROV_DLL_NOT_FOUND", "explanation": "Provider DLL could not be found."},
    "0x8009001F": {"name": "NTE_BAD_KEYSET_PARAM", "explanation": "The keyset parameter is invalid."},
    "0x80090020": {"name": "NTE_FAIL", "explanation": "An internal error occurred."},
    "0x80090021": {"name": "NTE_SYS_ERR", "explanation": "A base error occurred."},
    "0x80090022": {
        "name": "NTE_SILENT_CONTEXT",
        "explanation": "Provider could not perform the action because the context was acquired as silent.",
    },
    "0x80090023": {
        "name": "NTE_TOKEN_KEYSET_STORAGE_FULL",
        "explanation": "The security token does not have storage space available for an additional container.",
    },
    "0x80090024": {"name": "NTE_TEMPORARY_PROFILE", "explanation": "The profile for the user is a temporary profile."},
    "0x80090025": {
        "name": "NTE_FIXEDPARAMETER",
        "explanation": "The key parameters could not be set because the configuration service provider (CSP) uses fixed parameters.",
    },
    "0x80090026": {"name": "NTE_INVALID_HANDLE", "explanation": "The supplied handle is invalid."},
    "0x80090027": {"name": "NTE_INVALID_PARAMETER", "explanation": "The parameter is incorrect."},
    "0x80090028": {"name": "NTE_BUFFER_TOO_SMALL", "explanation": "The buffer supplied to a function was too small."},
    "0x80090029": {"name": "NTE_NOT_SUPPORTED", "explanation": "The requested operation is not supported."},
    "0x8009002A": {"name": "NTE_NO_MORE_ITEMS", "explanation": "No more data is available."},
    "0x8009002B": {"name": "NTE_BUFFERS_OVERLAP", "explanation": "The supplied buffers overlap incorrectly."},
    "0x8009002C": {"name": "NTE_DECRYPTION_FAILURE", "explanation": "The specified data could not be decrypted."},
    "0x8009002D": {"name": "NTE_INTERNAL_ERROR", "explanation": "An internal consistency check failed."},
    "0x8009002E": {"name": "NTE_UI_REQUIRED", "explanation": "This operation requires input from the user."},
    "0x8009002F": {
        "name": "NTE_HMAC_NOT_SUPPORTED",
        "explanation": "The cryptographic provider does not support Hash Message Authentication Code (HMAC).",
    },
    "0x80090300": {
        "name": "SEC_E_INSUFFICIENT_MEMORY",
        "explanation": "Not enough memory is available to complete this request.",
    },
    "0x80090301": {"name": "SEC_E_INVALID_HANDLE", "explanation": "The handle specified is invalid."},
    "0x80090302": {"name": "SEC_E_UNSUPPORTED_FUNCTION", "explanation": "The function requested is not supported."},
    "0x80090303": {"name": "SEC_E_TARGET_UNKNOWN", "explanation": "The specified target is unknown or unreachable."},
    "0x80090304": {
        "name": "SEC_E_INTERNAL_ERROR",
        "explanation": "The Local Security Authority (LSA) cannot be contacted.",
    },
    "0x80090305": {"name": "SEC_E_SECPKG_NOT_FOUND", "explanation": "The requested security package does not exist."},
    "0x80090306": {"name": "SEC_E_NOT_OWNER", "explanation": "The caller is not the owner of the desired credentials."},
    "0x80090307": {
        "name": "SEC_E_CANNOT_INSTALL",
        "explanation": "The security package failed to initialize and cannot be installed.",
    },
    "0x80090308": {"name": "SEC_E_INVALID_TOKEN", "explanation": "The token supplied to the function is invalid."},
    "0x80090309": {
        "name": "SEC_E_CANNOT_PACK",
        "explanation": "The security package is not able to marshal the logon buffer, so the logon attempt has failed.",
    },
    "0x8009030A": {
        "name": "SEC_E_QOP_NOT_SUPPORTED",
        "explanation": "The per-message quality of protection is not supported by the security package.",
    },
    "0x8009030B": {
        "name": "SEC_E_NO_IMPERSONATION",
        "explanation": "The security context does not allow impersonation of the client.",
    },
    "0x8009030C": {"name": "SEC_E_LOGON_DENIED", "explanation": "The logon attempt failed."},
    "0x8009030D": {
        "name": "SEC_E_UNKNOWN_CREDENTIALS",
        "explanation": "The credentials supplied to the package were not recognized.",
    },
    "0x8009030E": {
        "name": "SEC_E_NO_CREDENTIALS",
        "explanation": "No credentials are available in the security package.",
    },
    "0x8009030F": {
        "name": "SEC_E_MESSAGE_ALTERED",
        "explanation": "The message or signature supplied for verification has been altered.",
    },
    "0x80090310": {
        "name": "SEC_E_OUT_OF_SEQUENCE",
        "explanation": "The message supplied for verification is out of sequence.",
    },
    "0x80090311": {
        "name": "SEC_E_NO_AUTHENTICATING_AUTHORITY",
        "explanation": "No authority could be contacted for authentication.",
    },
    "0x80090316": {"name": "SEC_E_BAD_PKGID", "explanation": "The requested security package does not exist."},
    "0x80090317": {
        "name": "SEC_E_CONTEXT_EXPIRED",
        "explanation": "The context has expired and can no longer be used.",
    },
    "0x80090318": {
        "name": "SEC_E_INCOMPLETE_MESSAGE",
        "explanation": "The supplied message is incomplete. The signature was not verified.",
    },
    "0x80090320": {
        "name": "SEC_E_INCOMPLETE_CREDENTIALS",
        "explanation": "The credentials supplied were not complete and could not be verified. The context could not be initialized.",
    },
    "0x80090321": {
        "name": "SEC_E_BUFFER_TOO_SMALL",
        "explanation": "The buffers supplied to a function was too small.",
    },
    "0x80090322": {"name": "SEC_E_WRONG_PRINCIPAL", "explanation": "The target principal name is incorrect."},
    "0x80090324": {
        "name": "SEC_E_TIME_SKEW",
        "explanation": "The clocks on the client and server machines are skewed.",
    },
    "0x80090325": {
        "name": "SEC_E_UNTRUSTED_ROOT",
        "explanation": "The certificate chain was issued by an authority that is not trusted.",
    },
    "0x80090326": {
        "name": "SEC_E_ILLEGAL_MESSAGE",
        "explanation": "The message received was unexpected or badly formatted.",
    },
    "0x80090327": {
        "name": "SEC_E_CERT_UNKNOWN",
        "explanation": "An unknown error occurred while processing the certificate.",
    },
    "0x80090328": {"name": "SEC_E_CERT_EXPIRED", "explanation": "The received certificate has expired."},
    "0x80090329": {"name": "SEC_E_ENCRYPT_FAILURE", "explanation": "The specified data could not be encrypted."},
    "0x80090330": {"name": "SEC_E_DECRYPT_FAILURE", "explanation": "The specified data could not be decrypted."},
    "0x80090331": {
        "name": "SEC_E_ALGORITHM_MISMATCH",
        "explanation": "The client and server cannot communicate because they do not possess a common algorithm.",
    },
    "0x80090332": {
        "name": "SEC_E_SECURITY_QOS_FAILED",
        "explanation": "The security context could not be established due to a failure in the requested quality of service (for example, mutual authentication or delegation).",
    },
    "0x80090333": {
        "name": "SEC_E_UNFINISHED_CONTEXT_DELETED",
        "explanation": "A security context was deleted before the context was completed. This is considered a logon failure.",
    },
    "0x80090334": {
        "name": "SEC_E_NO_TGT_REPLY",
        "explanation": "The client is trying to negotiate a context and the server requires user-to-user but did not send a ticket granting ticket (TGT) reply.",
    },
    "0x80090335": {
        "name": "SEC_E_NO_IP_ADDRESSES",
        "explanation": "Unable to accomplish the requested task because the local machine does not have an IP addresses.",
    },
    "0x80090336": {
        "name": "SEC_E_WRONG_CREDENTIAL_HANDLE",
        "explanation": "The supplied credential handle does not match the credential associated with the security context.",
    },
    "0x80090337": {
        "name": "SEC_E_CRYPTO_SYSTEM_INVALID",
        "explanation": "The cryptographic system or checksum function is invalid because a required function is unavailable.",
    },
    "0x80090338": {
        "name": "SEC_E_MAX_REFERRALS_EXCEEDED",
        "explanation": "The number of maximum ticket referrals has been exceeded.",
    },
    "0x80090339": {
        "name": "SEC_E_MUST_BE_KDC",
        "explanation": "The local machine must be a Kerberos domain controller (KDC), and it is not.",
    },
    "0x8009033A": {
        "name": "SEC_E_STRONG_CRYPTO_NOT_SUPPORTED",
        "explanation": "The other end of the security negotiation requires strong cryptographics, but it is not supported on the local machine.",
    },
    "0x8009033B": {
        "name": "SEC_E_TOO_MANY_PRINCIPALS",
        "explanation": "The KDC reply contained more than one principal name.",
    },
    "0x8009033C": {
        "name": "SEC_E_NO_PA_DATA",
        "explanation": "Expected to find PA data for a hint of what etype to use, but it was not found.",
    },
    "0x8009033D": {
        "name": "SEC_E_PKINIT_NAME_MISMATCH",
        "explanation": "The client certificate does not contain a valid user principal name (UPN), or does not match the client name in the logon request. Contact your administrator.",
    },
    "0x8009033E": {
        "name": "SEC_E_SMARTCARD_LOGON_REQUIRED",
        "explanation": "Smart card logon is required and was not used.",
    },
    "0x8009033F": {"name": "SEC_E_SHUTDOWN_IN_PROGRESS", "explanation": "A system shutdown is in progress."},
    "0x80090340": {"name": "SEC_E_KDC_INVALID_REQUEST", "explanation": "An invalid request was sent to the KDC."},
    "0x80090341": {
        "name": "SEC_E_KDC_UNABLE_TO_REFER",
        "explanation": "The KDC was unable to generate a referral for the service requested.",
    },
    "0x80090342": {
        "name": "SEC_E_KDC_UNKNOWN_ETYPE",
        "explanation": "The encryption type requested is not supported by the KDC.",
    },
    "0x80090343": {
        "name": "SEC_E_UNSUPPORTED_PREAUTH",
        "explanation": "An unsupported pre-authentication mechanism was presented to the Kerberos package.",
    },
    "0x80090345": {
        "name": "SEC_E_DELEGATION_REQUIRED",
        "explanation": "The requested operation cannot be completed. The computer must be trusted for delegation, and the current user account must be configured to allow delegation.",
    },
    "0x80090346": {
        "name": "SEC_E_BAD_BINDINGS",
        "explanation": "Client's supplied Security Support Provider Interface (SSPI) channel bindings were incorrect.",
    },
    "0x80090347": {
        "name": "SEC_E_MULTIPLE_ACCOUNTS",
        "explanation": "The received certificate was mapped to multiple accounts.",
    },
    "0x80090348": {"name": "SEC_E_NO_KERB_KEY", "explanation": "No Kerberos key was found."},
    "0x80090349": {
        "name": "SEC_E_CERT_WRONG_USAGE",
        "explanation": "The certificate is not valid for the requested usage.",
    },
    "0x80090350": {
        "name": "SEC_E_DOWNGRADE_DETECTED",
        "explanation": "The system detected a possible attempt to compromise security. Ensure that you can contact the server that authenticated you.",
    },
    "0x80090351": {
        "name": "SEC_E_SMARTCARD_CERT_REVOKED",
        "explanation": "The smart card certificate used for authentication has been revoked. Contact your system administrator. The event log might contain additional information.",
    },
    "0x80090352": {
        "name": "SEC_E_ISSUING_CA_UNTRUSTED",
        "explanation": "An untrusted certification authority (CA) was detected while processing the smart card certificate used for authentication. Contact your system administrator.",
    },
    "0x80090353": {
        "name": "SEC_E_REVOCATION_OFFLINE_C",
        "explanation": "The revocation status of the smart card certificate used for authentication could not be determined. Contact your system administrator.",
    },
    "0x80090354": {
        "name": "SEC_E_PKINIT_CLIENT_FAILURE",
        "explanation": "The smart card certificate used for authentication was not trusted. Contact your system administrator.",
    },
    "0x80090355": {
        "name": "SEC_E_SMARTCARD_CERT_EXPIRED",
        "explanation": "The smart card certificate used for authentication has expired. Contact your system administrator.",
    },
    "0x80090356": {
        "name": "SEC_E_NO_S4U_PROT_SUPPORT",
        "explanation": "The Kerberos subsystem encountered an error. A service for user protocol requests was made against a domain controller that does not support services for users.",
    },
    "0x80090357": {
        "name": "SEC_E_CROSSREALM_DELEGATION_FAILURE",
        "explanation": "An attempt was made by this server to make a Kerberos-constrained delegation request for a target outside the server's realm. This is not supported and indicates a misconfiguration on this server's allowed-to-delegate-to list. Contact your administrator.",
    },
    "0x80090358": {
        "name": "SEC_E_REVOCATION_OFFLINE_KDC",
        "explanation": "The revocation status of the domain controller certificate used for smart card authentication could not be determined. The system event log contains additional information. Contact your system administrator.",
    },
    "0x80090359": {
        "name": "SEC_E_ISSUING_CA_UNTRUSTED_KDC",
        "explanation": "An untrusted CA was detected while processing the domain controller certificate used for authentication. The system event log contains additional information. Contact your system administrator.",
    },
    "0x8009035A": {
        "name": "SEC_E_KDC_CERT_EXPIRED",
        "explanation": "The domain controller certificate used for smart card logon has expired. Contact your system administrator with the contents of your system event log.",
    },
    "0x8009035B": {
        "name": "SEC_E_KDC_CERT_REVOKED",
        "explanation": "The domain controller certificate used for smart card logon has been revoked. Contact your system administrator with the contents of your system event log.",
    },
    "0x8009035D": {
        "name": "SEC_E_INVALID_PARAMETER",
        "explanation": "One or more of the parameters passed to the function were invalid.",
    },
    "0x8009035E": {
        "name": "SEC_E_DELEGATION_POLICY",
        "explanation": "The client policy does not allow credential delegation to the target server.",
    },
    "0x8009035F": {
        "name": "SEC_E_POLICY_NLTM_ONLY",
        "explanation": "The client policy does not allow credential delegation to the target server with NLTM only authentication.",
    },
    "0x80091001": {
        "name": "CRYPT_E_MSG_ERROR",
        "explanation": "An error occurred while performing an operation on a cryptographic message.",
    },
    "0x80091002": {"name": "CRYPT_E_UNKNOWN_ALGO", "explanation": "Unknown cryptographic algorithm."},
    "0x80091003": {"name": "CRYPT_E_OID_FORMAT", "explanation": "The object identifier is poorly formatted."},
    "0x80091004": {"name": "CRYPT_E_INVALID_MSG_TYPE", "explanation": "Invalid cryptographic message type."},
    "0x80091005": {"name": "CRYPT_E_UNEXPECTED_ENCODING", "explanation": "Unexpected cryptographic message encoding."},
    "0x80091006": {
        "name": "CRYPT_E_AUTH_ATTR_MISSING",
        "explanation": "The cryptographic message does not contain an expected authenticated attribute.",
    },
    "0x80091007": {"name": "CRYPT_E_HASH_VALUE", "explanation": "The hash value is not correct."},
    "0x80091008": {"name": "CRYPT_E_INVALID_INDEX", "explanation": "The index value is not valid."},
    "0x80091009": {
        "name": "CRYPT_E_ALREADY_DECRYPTED",
        "explanation": "The content of the cryptographic message has already been decrypted.",
    },
    "0x8009100A": {
        "name": "CRYPT_E_NOT_DECRYPTED",
        "explanation": "The content of the cryptographic message has not been decrypted yet.",
    },
    "0x8009100B": {
        "name": "CRYPT_E_RECIPIENT_NOT_FOUND",
        "explanation": "The enveloped-data message does not contain the specified recipient.",
    },
    "0x8009100C": {"name": "CRYPT_E_CONTROL_TYPE", "explanation": "Invalid control type."},
    "0x8009100D": {"name": "CRYPT_E_ISSUER_SERIALNUMBER", "explanation": "Invalid issuer or serial number."},
    "0x8009100E": {"name": "CRYPT_E_SIGNER_NOT_FOUND", "explanation": "Cannot find the original signer."},
    "0x8009100F": {
        "name": "CRYPT_E_ATTRIBUTES_MISSING",
        "explanation": "The cryptographic message does not contain all of the requested attributes.",
    },
    "0x80091010": {
        "name": "CRYPT_E_STREAM_MSG_NOT_READY",
        "explanation": "The streamed cryptographic message is not ready to return data.",
    },
    "0x80091011": {
        "name": "CRYPT_E_STREAM_INSUFFICIENT_DATA",
        "explanation": "The streamed cryptographic message requires more data to complete the decode operation.",
    },
    "0x80092001": {
        "name": "CRYPT_E_BAD_LEN",
        "explanation": "The length specified for the output data was insufficient.",
    },
    "0x80092002": {
        "name": "CRYPT_E_BAD_ENCODE",
        "explanation": "An error occurred during the encode or decode operation.",
    },
    "0x80092003": {
        "name": "CRYPT_E_FILE_ERROR",
        "explanation": "An error occurred while reading or writing to a file.",
    },
    "0x80092004": {"name": "CRYPT_E_NOT_FOUND", "explanation": "Cannot find object or property."},
    "0x80092005": {"name": "CRYPT_E_EXISTS", "explanation": "The object or property already exists."},
    "0x80092006": {"name": "CRYPT_E_NO_PROVIDER", "explanation": "No provider was specified for the store or object."},
    "0x80092007": {"name": "CRYPT_E_SELF_SIGNED", "explanation": "The specified certificate is self-signed."},
    "0x80092008": {
        "name": "CRYPT_E_DELETED_PREV",
        "explanation": "The previous certificate or certificate revocation list (CRL) context was deleted.",
    },
    "0x80092009": {"name": "CRYPT_E_NO_MATCH", "explanation": "Cannot find the requested object."},
    "0x8009200A": {
        "name": "CRYPT_E_UNEXPECTED_MSG_TYPE",
        "explanation": "The certificate does not have a property that references a private key.",
    },
    "0x8009200B": {
        "name": "CRYPT_E_NO_KEY_PROPERTY",
        "explanation": "Cannot find the certificate and private key for decryption.",
    },
    "0x8009200C": {
        "name": "CRYPT_E_NO_DECRYPT_CERT",
        "explanation": "Cannot find the certificate and private key to use for decryption.",
    },
    "0x8009200D": {
        "name": "CRYPT_E_BAD_MSG",
        "explanation": "Not a cryptographic message or the cryptographic message is not formatted correctly.",
    },
    "0x8009200E": {
        "name": "CRYPT_E_NO_SIGNER",
        "explanation": "The signed cryptographic message does not have a signer for the specified signer index.",
    },
    "0x8009200F": {
        "name": "CRYPT_E_PENDING_CLOSE",
        "explanation": "Final closure is pending until additional frees or closes.",
    },
    "0x80092010": {"name": "CRYPT_E_REVOKED", "explanation": "The certificate is revoked."},
    "0x80092011": {
        "name": "CRYPT_E_NO_REVOCATION_DLL",
        "explanation": "No DLL or exported function was found to verify revocation.",
    },
    "0x80092012": {
        "name": "CRYPT_E_NO_REVOCATION_CHECK",
        "explanation": "The revocation function was unable to check revocation for the certificate.",
    },
    "0x80092013": {
        "name": "CRYPT_E_REVOCATION_OFFLINE",
        "explanation": "The revocation function was unable to check revocation because the revocation server was offline.",
    },
    "0x80092014": {
        "name": "CRYPT_E_NOT_IN_REVOCATION_DATABASE",
        "explanation": "The certificate is not in the revocation server's database.",
    },
    "0x80092020": {
        "name": "CRYPT_E_INVALID_NUMERIC_STRING",
        "explanation": "The string contains a non-numeric character.",
    },
    "0x80092021": {
        "name": "CRYPT_E_INVALID_PRINTABLE_STRING",
        "explanation": "The string contains a nonprintable character.",
    },
    "0x80092022": {
        "name": "CRYPT_E_INVALID_IA5_STRING",
        "explanation": "The string contains a character not in the 7-bit ASCII character set.",
    },
    "0x80092023": {
        "name": "CRYPT_E_INVALID_X500_STRING",
        "explanation": "The string contains an invalid X500 name attribute key, object identifier (OID), value, or delimiter.",
    },
    "0x80092024": {
        "name": "CRYPT_E_NOT_CHAR_STRING",
        "explanation": "The dwValueType for the CERT_NAME_VALUE is not one of the character strings. Most likely it is either a CERT_RDN_ENCODED_BLOB or CERT_TDN_OCTED_STRING.",
    },
    "0x80092025": {
        "name": "CRYPT_E_FILERESIZED",
        "explanation": "The Put operation cannot continue. The file needs to be resized. However, there is already a signature present. A complete signing operation must be done.",
    },
    "0x80092026": {
        "name": "CRYPT_E_SECURITY_SETTINGS",
        "explanation": "The cryptographic operation failed due to a local security option setting.",
    },
    "0x80092027": {
        "name": "CRYPT_E_NO_VERIFY_USAGE_DLL",
        "explanation": "No DLL or exported function was found to verify subject usage.",
    },
    "0x80092028": {
        "name": "CRYPT_E_NO_VERIFY_USAGE_CHECK",
        "explanation": "The called function was unable to perform a usage check on the subject.",
    },
    "0x80092029": {
        "name": "CRYPT_E_VERIFY_USAGE_OFFLINE",
        "explanation": "The called function was unable to complete the usage check because the server was offline.",
    },
    "0x8009202A": {
        "name": "CRYPT_E_NOT_IN_CTL",
        "explanation": "The subject was not found in a certificate trust list (CTL).",
    },
    "0x8009202B": {
        "name": "CRYPT_E_NO_TRUSTED_SIGNER",
        "explanation": "None of the signers of the cryptographic message or certificate trust list is trusted.",
    },
    "0x8009202C": {
        "name": "CRYPT_E_MISSING_PUBKEY_PARA",
        "explanation": "The public key's algorithm parameters are missing.",
    },
    "0x80093000": {"name": "CRYPT_E_OSS_ERROR", "explanation": "OSS Certificate encode/decode error code base."},
    "0x80093001": {"name": "OSS_MORE_BUF", "explanation": "OSS ASN.1 Error: Output Buffer is too small."},
    "0x80093002": {
        "name": "OSS_NEGATIVE_UINTEGER",
        "explanation": "OSS ASN.1 Error: Signed integer is encoded as a unsigned integer.",
    },
    "0x80093003": {"name": "OSS_PDU_RANGE", "explanation": "OSS ASN.1 Error: Unknown ASN.1 data type."},
    "0x80093004": {
        "name": "OSS_MORE_INPUT",
        "explanation": "OSS ASN.1 Error: Output buffer is too small; the decoded data has been truncated.",
    },
    "0x80093005": {"name": "OSS_DATA_ERROR", "explanation": "OSS ASN.1 Error: Invalid data."},
    "0x80093006": {"name": "OSS_BAD_ARG", "explanation": "OSS ASN.1 Error: Invalid argument."},
    "0x80093007": {"name": "OSS_BAD_VERSION", "explanation": "OSS ASN.1 Error: Encode/Decode version mismatch."},
    "0x80093008": {"name": "OSS_OUT_MEMORY", "explanation": "OSS ASN.1 Error: Out of memory."},
    "0x80093009": {"name": "OSS_PDU_MISMATCH", "explanation": "OSS ASN.1 Error: Encode/Decode error."},
    "0x8009300A": {"name": "OSS_LIMITED", "explanation": "OSS ASN.1 Error: Internal error."},
    "0x8009300B": {"name": "OSS_BAD_PTR", "explanation": "OSS ASN.1 Error: Invalid data."},
    "0x8009300C": {"name": "OSS_BAD_TIME", "explanation": "OSS ASN.1 Error: Invalid data."},
    "0x8009300D": {
        "name": "OSS_INDEFINITE_NOT_SUPPORTED",
        "explanation": "OSS ASN.1 Error: Unsupported BER indefinite-length encoding.",
    },
    "0x8009300E": {"name": "OSS_MEM_ERROR", "explanation": "OSS ASN.1 Error: Access violation."},
    "0x8009300F": {"name": "OSS_BAD_TABLE", "explanation": "OSS ASN.1 Error: Invalid data."},
    "0x80093010": {"name": "OSS_TOO_LONG", "explanation": "OSS ASN.1 Error: Invalid data."},
    "0x80093011": {"name": "OSS_CONSTRAINT_VIOLATED", "explanation": "OSS ASN.1 Error: Invalid data."},
    "0x80093012": {"name": "OSS_FATAL_ERROR", "explanation": "OSS ASN.1 Error: Internal error."},
    "0x80093013": {
        "name": "OSS_ACCESS_SERIALIZATION_ERROR",
        "explanation": "OSS ASN.1 Error: Multithreading conflict.",
    },
    "0x80093014": {"name": "OSS_NULL_TBL", "explanation": "OSS ASN.1 Error: Invalid data."},
    "0x80093015": {"name": "OSS_NULL_FCN", "explanation": "OSS ASN.1 Error: Invalid data."},
    "0x80093016": {"name": "OSS_BAD_ENCRULES", "explanation": "OSS ASN.1 Error: Invalid data."},
    "0x80093017": {
        "name": "OSS_UNAVAIL_ENCRULES",
        "explanation": "OSS ASN.1 Error: Encode/Decode function not implemented.",
    },
    "0x80093018": {"name": "OSS_CANT_OPEN_TRACE_WINDOW", "explanation": "OSS ASN.1 Error: Trace file error."},
    "0x80093019": {"name": "OSS_UNIMPLEMENTED", "explanation": "OSS ASN.1 Error: Function not implemented."},
    "0x8009301A": {"name": "OSS_OID_DLL_NOT_LINKED", "explanation": "OSS ASN.1 Error: Program link error."},
    "0x8009301B": {"name": "OSS_CANT_OPEN_TRACE_FILE", "explanation": "OSS ASN.1 Error: Trace file error."},
    "0x8009301C": {"name": "OSS_TRACE_FILE_ALREADY_OPEN", "explanation": "OSS ASN.1 Error: Trace file error."},
    "0x8009301D": {"name": "OSS_TABLE_MISMATCH", "explanation": "OSS ASN.1 Error: Invalid data."},
    "0x8009301E": {"name": "OSS_TYPE_NOT_SUPPORTED", "explanation": "OSS ASN.1 Error: Invalid data."},
    "0x8009301F": {"name": "OSS_REAL_DLL_NOT_LINKED", "explanation": "OSS ASN.1 Error: Program link error."},
    "0x80093020": {"name": "OSS_REAL_CODE_NOT_LINKED", "explanation": "OSS ASN.1 Error: Program link error."},
    "0x80093021": {"name": "OSS_OUT_OF_RANGE", "explanation": "OSS ASN.1 Error: Program link error."},
    "0x80093022": {"name": "OSS_COPIER_DLL_NOT_LINKED", "explanation": "OSS ASN.1 Error: Program link error."},
    "0x80093023": {"name": "OSS_CONSTRAINT_DLL_NOT_LINKED", "explanation": "OSS ASN.1 Error: Program link error."},
    "0x80093024": {"name": "OSS_COMPARATOR_DLL_NOT_LINKED", "explanation": "OSS ASN.1 Error: Program link error."},
    "0x80093025": {"name": "OSS_COMPARATOR_CODE_NOT_LINKED", "explanation": "OSS ASN.1 Error: Program link error."},
    "0x80093026": {"name": "OSS_MEM_MGR_DLL_NOT_LINKED", "explanation": "OSS ASN.1 Error: Program link error."},
    "0x80093027": {"name": "OSS_PDV_DLL_NOT_LINKED", "explanation": "OSS ASN.1 Error: Program link error."},
    "0x80093028": {"name": "OSS_PDV_CODE_NOT_LINKED", "explanation": "OSS ASN.1 Error: Program link error."},
    "0x80093029": {"name": "OSS_API_DLL_NOT_LINKED", "explanation": "OSS ASN.1 Error: Program link error."},
    "0x8009302A": {"name": "OSS_BERDER_DLL_NOT_LINKED", "explanation": "OSS ASN.1 Error: Program link error."},
    "0x8009302B": {"name": "OSS_PER_DLL_NOT_LINKED", "explanation": "OSS ASN.1 Error: Program link error."},
    "0x8009302C": {"name": "OSS_OPEN_TYPE_ERROR", "explanation": "OSS ASN.1 Error: Program link error."},
    "0x8009302D": {"name": "OSS_MUTEX_NOT_CREATED", "explanation": "OSS ASN.1 Error: System resource error."},
    "0x8009302E": {"name": "OSS_CANT_CLOSE_TRACE_FILE", "explanation": "OSS ASN.1 Error: Trace file error."},
    "0x80093100": {"name": "CRYPT_E_ASN1_ERROR", "explanation": "ASN1 Certificate encode/decode error code base."},
    "0x80093101": {"name": "CRYPT_E_ASN1_INTERNAL", "explanation": "ASN1 internal encode or decode error."},
    "0x80093102": {"name": "CRYPT_E_ASN1_EOD", "explanation": "ASN1 unexpected end of data."},
    "0x80093103": {"name": "CRYPT_E_ASN1_CORRUPT", "explanation": "ASN1 corrupted data."},
    "0x80093104": {"name": "CRYPT_E_ASN1_LARGE", "explanation": "ASN1 value too large."},
    "0x80093105": {"name": "CRYPT_E_ASN1_CONSTRAINT", "explanation": "ASN1 constraint violated."},
    "0x80093106": {"name": "CRYPT_E_ASN1_MEMORY", "explanation": "ASN1 out of memory."},
    "0x80093107": {"name": "CRYPT_E_ASN1_OVERFLOW", "explanation": "ASN1 buffer overflow."},
    "0x80093108": {
        "name": "CRYPT_E_ASN1_BADPDU",
        "explanation": "ASN1 function not supported for this protocol data unit (PDU).",
    },
    "0x80093109": {"name": "CRYPT_E_ASN1_BADARGS", "explanation": "ASN1 bad arguments to function call."},
    "0x8009310A": {"name": "CRYPT_E_ASN1_BADREAL", "explanation": "ASN1 bad real value."},
    "0x8009310B": {"name": "CRYPT_E_ASN1_BADTAG", "explanation": "ASN1 bad tag value met."},
    "0x8009310C": {"name": "CRYPT_E_ASN1_CHOICE", "explanation": "ASN1 bad choice value."},
    "0x8009310D": {"name": "CRYPT_E_ASN1_RULE", "explanation": "ASN1 bad encoding rule."},
    "0x8009310E": {"name": "CRYPT_E_ASN1_UTF8", "explanation": "ASN1 bad Unicode (UTF8)."},
    "0x80093133": {"name": "CRYPT_E_ASN1_PDU_TYPE", "explanation": "ASN1 bad PDU type."},
    "0x80093134": {"name": "CRYPT_E_ASN1_NYI", "explanation": "ASN1 not yet implemented."},
    "0x80093201": {"name": "CRYPT_E_ASN1_EXTENDED", "explanation": "ASN1 skipped unknown extensions."},
    "0x80093202": {"name": "CRYPT_E_ASN1_NOEOD", "explanation": "ASN1 end of data expected."},
    "0x80094001": {
        "name": "CERTSRV_E_BAD_REQUESTSUBJECT",
        "explanation": "The request subject name is invalid or too long.",
    },
    "0x80094002": {"name": "CERTSRV_E_NO_REQUEST", "explanation": "The request does not exist."},
    "0x80094003": {
        "name": "CERTSRV_E_BAD_REQUESTSTATUS",
        "explanation": "The request's current status does not allow this operation.",
    },
    "0x80094004": {"name": "CERTSRV_E_PROPERTY_EMPTY", "explanation": "The requested property value is empty."},
    "0x80094005": {
        "name": "CERTSRV_E_INVALID_CA_CERTIFICATE",
        "explanation": "The CA's certificate contains invalid data.",
    },
    "0x80094006": {
        "name": "CERTSRV_E_SERVER_SUSPENDED",
        "explanation": "Certificate service has been suspended for a database restore operation.",
    },
    "0x80094007": {
        "name": "CERTSRV_E_ENCODING_LENGTH",
        "explanation": "The certificate contains an encoded length that is potentially incompatible with older enrollment software.",
    },
    "0x80094008": {
        "name": "CERTSRV_E_ROLECONFLICT",
        "explanation": "The operation is denied. The user has multiple roles assigned, and the CA is configured to enforce role separation.",
    },
    "0x80094009": {
        "name": "CERTSRV_E_RESTRICTEDOFFICER",
        "explanation": "The operation is denied. It can only be performed by a certificate manager that is allowed to manage certificates for the current requester.",
    },
    "0x8009400A": {
        "name": "CERTSRV_E_KEY_ARCHIVAL_NOT_CONFIGURED",
        "explanation": "Cannot archive private key. The CA is not configured for key archival.",
    },
    "0x8009400B": {
        "name": "CERTSRV_E_NO_VALID_KRA",
        "explanation": "Cannot archive private key. The CA could not verify one or more key recovery certificates.",
    },
    "0x8009400C": {
        "name": "CERTSRV_E_BAD_REQUEST_KEY_ARCHIVAL",
        "explanation": "The request is incorrectly formatted. The encrypted private key must be in an unauthenticated attribute in an outermost signature.",
    },
    "0x8009400D": {
        "name": "CERTSRV_E_NO_CAADMIN_DEFINED",
        "explanation": "At least one security principal must have the permission to manage this CA.",
    },
    "0x8009400E": {
        "name": "CERTSRV_E_BAD_RENEWAL_CERT_ATTRIBUTE",
        "explanation": "The request contains an invalid renewal certificate attribute.",
    },
    "0x8009400F": {
        "name": "CERTSRV_E_NO_DB_SESSIONS",
        "explanation": "An attempt was made to open a CA database session, but there are already too many active sessions. The server needs to be configured to allow additional sessions.",
    },
    "0x80094010": {
        "name": "CERTSRV_E_ALIGNMENT_FAULT",
        "explanation": "A memory reference caused a data alignment fault.",
    },
    "0x80094011": {
        "name": "CERTSRV_E_ENROLL_DENIED",
        "explanation": "The permissions on this CA do not allow the current user to enroll for certificates.",
    },
    "0x80094012": {
        "name": "CERTSRV_E_TEMPLATE_DENIED",
        "explanation": "The permissions on the certificate template do not allow the current user to enroll for this type of certificate.",
    },
    "0x80094013": {
        "name": "CERTSRV_E_DOWNLEVEL_DC_SSL_OR_UPGRADE",
        "explanation": "The contacted domain controller cannot support signed Lightweight Directory Access Protocol (LDAP) traffic. Update the domain controller or configure Certificate Services to use SSL for Active Directory access.",
    },
    "0x80094800": {
        "name": "CERTSRV_E_UNSUPPORTED_CERT_TYPE",
        "explanation": "The requested certificate template is not supported by this CA.",
    },
    "0x80094801": {
        "name": "CERTSRV_E_NO_CERT_TYPE",
        "explanation": "The request contains no certificate template information.",
    },
    "0x80094802": {
        "name": "CERTSRV_E_TEMPLATE_CONFLICT",
        "explanation": "The request contains conflicting template information.",
    },
    "0x80094803": {
        "name": "CERTSRV_E_SUBJECT_ALT_NAME_REQUIRED",
        "explanation": "The request is missing a required Subject Alternate name extension.",
    },
    "0x80094804": {
        "name": "CERTSRV_E_ARCHIVED_KEY_REQUIRED",
        "explanation": "The request is missing a required private key for archival by the server.",
    },
    "0x80094805": {
        "name": "CERTSRV_E_SMIME_REQUIRED",
        "explanation": "The request is missing a required SMIME capabilities extension.",
    },
    "0x80094806": {
        "name": "CERTSRV_E_BAD_RENEWAL_SUBJECT",
        "explanation": "The request was made on behalf of a subject other than the caller. The certificate template must be configured to require at least one signature to authorize the request.",
    },
    "0x80094807": {
        "name": "CERTSRV_E_BAD_TEMPLATE_VERSION",
        "explanation": "The request template version is newer than the supported template version.",
    },
    "0x80094808": {
        "name": "CERTSRV_E_TEMPLATE_POLICY_REQUIRED",
        "explanation": "The template is missing a required signature policy attribute.",
    },
    "0x80094809": {
        "name": "CERTSRV_E_SIGNATURE_POLICY_REQUIRED",
        "explanation": "The request is missing required signature policy information.",
    },
    "0x8009480A": {
        "name": "CERTSRV_E_SIGNATURE_COUNT",
        "explanation": "The request is missing one or more required signatures.",
    },
    "0x8009480B": {
        "name": "CERTSRV_E_SIGNATURE_REJECTED",
        "explanation": "One or more signatures did not include the required application or issuance policies. The request is missing one or more required valid signatures.",
    },
    "0x8009480C": {
        "name": "CERTSRV_E_ISSUANCE_POLICY_REQUIRED",
        "explanation": "The request is missing one or more required signature issuance policies.",
    },
    "0x8009480D": {
        "name": "CERTSRV_E_SUBJECT_UPN_REQUIRED",
        "explanation": "The UPN is unavailable and cannot be added to the Subject Alternate name.",
    },
    "0x8009480E": {
        "name": "CERTSRV_E_SUBJECT_DIRECTORY_GUID_REQUIRED",
        "explanation": "The Active Directory GUID is unavailable and cannot be added to the Subject Alternate name.",
    },
    "0x8009480F": {
        "name": "CERTSRV_E_SUBJECT_DNS_REQUIRED",
        "explanation": "The Domain Name System (DNS) name is unavailable and cannot be added to the Subject Alternate name.",
    },
    "0x80094810": {
        "name": "CERTSRV_E_ARCHIVED_KEY_UNEXPECTED",
        "explanation": "The request includes a private key for archival by the server, but key archival is not enabled for the specified certificate template.",
    },
    "0x80094811": {
        "name": "CERTSRV_E_KEY_LENGTH",
        "explanation": "The public key does not meet the minimum size required by the specified certificate template.",
    },
    "0x80094812": {
        "name": "CERTSRV_E_SUBJECT_EMAIL_REQUIRED",
        "explanation": "The email name is unavailable and cannot be added to the Subject or Subject Alternate name.",
    },
    "0x80094813": {
        "name": "CERTSRV_E_UNKNOWN_CERT_TYPE",
        "explanation": "One or more certificate templates to be enabled on this CA could not be found.",
    },
    "0x80094814": {
        "name": "CERTSRV_E_CERT_TYPE_OVERLAP",
        "explanation": "The certificate template renewal period is longer than the certificate validity period. The template should be reconfigured or the CA certificate renewed.",
    },
    "0x80094815": {
        "name": "CERTSRV_E_TOO_MANY_SIGNATURES",
        "explanation": "The certificate template requires too many return authorization (RA) signatures. Only one RA signature is allowed.",
    },
    "0x80094816": {
        "name": "CERTSRV_E_RENEWAL_BAD_PUBLIC_KEY",
        "explanation": "The key used in a renewal request does not match one of the certificates being renewed.",
    },
    "0x80094817": {"name": "CERTSRV_E_INVALID_EK", "explanation": "The endorsement key certificate is not valid."},
    "0x8009481A": {"name": "CERTSRV_E_KEY_ATTESTATION", "explanation": "Key attestation did not succeed."},
    "0x80095000": {"name": "XENROLL_E_KEY_NOT_EXPORTABLE", "explanation": "The key is not exportable."},
    "0x80095001": {
        "name": "XENROLL_E_CANNOT_ADD_ROOT_CERT",
        "explanation": "You cannot add the root CA certificate into your local store.",
    },
    "0x80095002": {
        "name": "XENROLL_E_RESPONSE_KA_HASH_NOT_FOUND",
        "explanation": "The key archival hash attribute was not found in the response.",
    },
    "0x80095003": {
        "name": "XENROLL_E_RESPONSE_UNEXPECTED_KA_HASH",
        "explanation": "An unexpected key archival hash attribute was found in the response.",
    },
    "0x80095004": {
        "name": "XENROLL_E_RESPONSE_KA_HASH_MISMATCH",
        "explanation": "There is a key archival hash mismatch between the request and the response.",
    },
    "0x80095005": {
        "name": "XENROLL_E_KEYSPEC_SMIME_MISMATCH",
        "explanation": "Signing certificate cannot include SMIME extension.",
    },
    "0x80096001": {
        "name": "TRUST_E_SYSTEM_ERROR",
        "explanation": "A system-level error occurred while verifying trust.",
    },
    "0x80096002": {
        "name": "TRUST_E_NO_SIGNER_CERT",
        "explanation": "The certificate for the signer of the message is invalid or not found.",
    },
    "0x80096003": {"name": "TRUST_E_COUNTER_SIGNER", "explanation": "One of the counter signatures was invalid."},
    "0x80096004": {
        "name": "TRUST_E_CERT_SIGNATURE",
        "explanation": "The signature of the certificate cannot be verified.",
    },
    "0x80096005": {
        "name": "TRUST_E_TIME_STAMP",
        "explanation": "The time-stamp signature or certificate could not be verified or is malformed.",
    },
    "0x80096010": {"name": "TRUST_E_BAD_DIGEST", "explanation": "The digital signature of the object did not verify."},
    "0x80096019": {
        "name": "TRUST_E_BASIC_CONSTRAINTS",
        "explanation": "A certificate's basic constraint extension has not been observed.",
    },
    "0x8009601E": {
        "name": "TRUST_E_FINANCIAL_CRITERIA",
        "explanation": "The certificate does not meet or contain the Authenticode financial extensions.",
    },
    "0x80097001": {
        "name": "MSSIPOTF_E_OUTOFMEMRANGE",
        "explanation": "Tried to reference a part of the file outside the proper range.",
    },
    "0x80097002": {"name": "MSSIPOTF_E_CANTGETOBJECT", "explanation": "Could not retrieve an object from the file."},
    "0x80097003": {"name": "MSSIPOTF_E_NOHEADTABLE", "explanation": "Could not find the head table in the file."},
    "0x80097004": {
        "name": "MSSIPOTF_E_BAD_MAGICNUMBER",
        "explanation": "The magic number in the head table is incorrect.",
    },
    "0x80097005": {"name": "MSSIPOTF_E_BAD_OFFSET_TABLE", "explanation": "The offset table has incorrect values."},
    "0x80097006": {
        "name": "MSSIPOTF_E_TABLE_TAGORDER",
        "explanation": "Duplicate table tags or the tags are out of alphabetical order.",
    },
    "0x80097007": {
        "name": "MSSIPOTF_E_TABLE_LONGWORD",
        "explanation": "A table does not start on a long word boundary.",
    },
    "0x80097008": {
        "name": "MSSIPOTF_E_BAD_FIRST_TABLE_PLACEMENT",
        "explanation": "First table does not appear after header information.",
    },
    "0x80097009": {"name": "MSSIPOTF_E_TABLES_OVERLAP", "explanation": "Two or more tables overlap."},
    "0x8009700A": {
        "name": "MSSIPOTF_E_TABLE_PADBYTES",
        "explanation": "Too many pad bytes between tables, or pad bytes are not 0.",
    },
    "0x8009700B": {"name": "MSSIPOTF_E_FILETOOSMALL", "explanation": "File is too small to contain the last table."},
    "0x8009700C": {"name": "MSSIPOTF_E_TABLE_CHECKSUM", "explanation": "A table checksum is incorrect."},
    "0x8009700D": {"name": "MSSIPOTF_E_FILE_CHECKSUM", "explanation": "The file checksum is incorrect."},
    "0x80097010": {
        "name": "MSSIPOTF_E_FAILED_POLICY",
        "explanation": "The signature does not have the correct attributes for the policy.",
    },
    "0x80097011": {"name": "MSSIPOTF_E_FAILED_HINTS_CHECK", "explanation": "The file did not pass the hints check."},
    "0x80097012": {"name": "MSSIPOTF_E_NOT_OPENTYPE", "explanation": "The file is not an OpenType file."},
    "0x80097013": {
        "name": "MSSIPOTF_E_FILE",
        "explanation": "Failed on a file operation (such as open, map, read, or write).",
    },
    "0x80097014": {"name": "MSSIPOTF_E_CRYPT", "explanation": "A call to a CryptoAPI function failed."},
    "0x80097015": {"name": "MSSIPOTF_E_BADVERSION", "explanation": "There is a bad version number in the file."},
    "0x80097016": {"name": "MSSIPOTF_E_DSIG_STRUCTURE", "explanation": "The structure of the DSIG table is incorrect."},
    "0x80097017": {"name": "MSSIPOTF_E_PCONST_CHECK", "explanation": "A check failed in a partially constant table."},
    "0x80097018": {"name": "MSSIPOTF_E_STRUCTURE", "explanation": "Some kind of structural error."},
    "0x80097019": {
        "name": "ERROR_CRED_REQUIRES_CONFIRMATION",
        "explanation": "The requested credential requires confirmation.",
    },
    "0x800B0001": {"name": "TRUST_E_PROVIDER_UNKNOWN", "explanation": "Unknown trust provider."},
    "0x800B0002": {
        "name": "TRUST_E_ACTION_UNKNOWN",
        "explanation": "The trust verification action specified is not supported by the specified trust provider.",
    },
    "0x800B0003": {
        "name": "TRUST_E_SUBJECT_FORM_UNKNOWN",
        "explanation": "The form specified for the subject is not one supported or known by the specified trust provider.",
    },
    "0x800B0004": {
        "name": "TRUST_E_SUBJECT_NOT_TRUSTED",
        "explanation": "The subject is not trusted for the specified action.",
    },
    "0x800B0005": {"name": "DIGSIG_E_ENCODE", "explanation": "Error due to problem in ASN.1 encoding process."},
    "0x800B0006": {"name": "DIGSIG_E_DECODE", "explanation": "Error due to problem in ASN.1 decoding process."},
    "0x800B0007": {
        "name": "DIGSIG_E_EXTENSIBILITY",
        "explanation": "Reading/writing extensions where attributes are appropriate, and vice versa.",
    },
    "0x800B0008": {"name": "DIGSIG_E_CRYPTO", "explanation": "Unspecified cryptographic failure."},
    "0x800B0009": {"name": "PERSIST_E_SIZEDEFINITE", "explanation": "The size of the data could not be determined."},
    "0x800B000A": {
        "name": "PERSIST_E_SIZEINDEFINITE",
        "explanation": "The size of the indefinite-sized data could not be determined.",
    },
    "0x800B000B": {
        "name": "PERSIST_E_NOTSELFSIZING",
        "explanation": "This object does not read and write self-sizing data.",
    },
    "0x800B0100": {"name": "TRUST_E_NOSIGNATURE", "explanation": "No signature was present in the subject."},
    "0x800B0101": {
        "name": "CERT_E_EXPIRED",
        "explanation": "A required certificate is not within its validity period when verifying against the current system clock or the time stamp in the signed file.",
    },
    "0x800B0102": {
        "name": "CERT_E_VALIDITYPERIODNESTING",
        "explanation": "The validity periods of the certification chain do not nest correctly.",
    },
    "0x800B0103": {
        "name": "CERT_E_ROLE",
        "explanation": "A certificate that can only be used as an end entity is being used as a CA or vice versa.",
    },
    "0x800B0104": {
        "name": "CERT_E_PATHLENCONST",
        "explanation": "A path length constraint in the certification chain has been violated.",
    },
    "0x800B0105": {
        "name": "CERT_E_CRITICAL",
        "explanation": 'A certificate contains an unknown extension that is marked "critical".',
    },
    "0x800B0106": {
        "name": "CERT_E_PURPOSE",
        "explanation": "A certificate is being used for a purpose other than the ones specified by its CA.",
    },
    "0x800B0107": {
        "name": "CERT_E_ISSUERCHAINING",
        "explanation": "A parent of a given certificate did not issue that child certificate.",
    },
    "0x800B0108": {
        "name": "CERT_E_MALFORMED",
        "explanation": "A certificate is missing or has an empty value for an important field, such as a subject or issuer name.",
    },
    "0x800B0109": {
        "name": "CERT_E_UNTRUSTEDROOT",
        "explanation": "A certificate chain processed, but terminated in a root certificate that is not trusted by the trust provider.",
    },
    "0x800B010A": {
        "name": "CERT_E_CHAINING",
        "explanation": "A certificate chain could not be built to a trusted root authority.",
    },
    "0x800B010B": {"name": "TRUST_E_FAIL", "explanation": "Generic trust failure."},
    "0x800B010C": {"name": "CERT_E_REVOKED", "explanation": "A certificate was explicitly revoked by its issuer."},
    "0x800B010D": {
        "name": "CERT_E_UNTRUSTEDTESTROOT",
        "explanation": "The certification path terminates with the test root that is not trusted with the current policy settings.",
    },
    "0x800B010E": {
        "name": "CERT_E_REVOCATION_FAILURE",
        "explanation": "The revocation process could not continueâ€”the certificates could not be checked.",
    },
    "0x800B010F": {
        "name": "CERT_E_CN_NO_MATCH",
        "explanation": "The certificate's CN name does not match the passed value.",
    },
    "0x800B0110": {
        "name": "CERT_E_WRONG_USAGE",
        "explanation": "The certificate is not valid for the requested usage.",
    },
    "0x800B0111": {
        "name": "TRUST_E_EXPLICIT_DISTRUST",
        "explanation": "The certificate was explicitly marked as untrusted by the user.",
    },
    "0x800B0112": {
        "name": "CERT_E_UNTRUSTEDCA",
        "explanation": "A certification chain processed correctly, but one of the CA certificates is not trusted by the policy provider.",
    },
    "0x800B0113": {"name": "CERT_E_INVALID_POLICY", "explanation": "The certificate has invalid policy."},
    "0x800B0114": {
        "name": "CERT_E_INVALID_NAME",
        "explanation": "The certificate has an invalid name. The name is not included in the permitted list or is explicitly excluded.",
    },
    "0x800D0003": {
        "name": "NS_W_SERVER_BANDWIDTH_LIMIT",
        "explanation": "The maximum filebitrate value specified is greater than the server's configured maximum bandwidth.",
    },
    "0x800D0004": {
        "name": "NS_W_FILE_BANDWIDTH_LIMIT",
        "explanation": "The maximum bandwidth value specified is less than the maximum filebitrate.",
    },
    "0x800D0060": {"name": "NS_W_UNKNOWN_EVENT", "explanation": "Unknown %1 event encountered."},
    "0x800D0199": {
        "name": "NS_I_CATATONIC_FAILURE",
        "explanation": "Disk %1 ( %2 ) on Content Server %3, will be failed because it is catatonic.",
    },
    "0x800D019A": {
        "name": "NS_I_CATATONIC_AUTO_UNFAIL",
        "explanation": "Disk %1 ( %2 ) on Content Server %3, auto online from catatonic state.",
    },
    "0x800F0000": {
        "name": "SPAPI_E_EXPECTED_SECTION_NAME",
        "explanation": "A non-empty line was encountered in the INF before the start of a section.",
    },
    "0x800F0001": {
        "name": "SPAPI_E_BAD_SECTION_NAME_LINE",
        "explanation": "A section name marker in the information file (INF) is not complete or does not exist on a line by itself.",
    },
    "0x800F0002": {
        "name": "SPAPI_E_SECTION_NAME_TOO_LONG",
        "explanation": "An INF section was encountered whose name exceeds the maximum section name length.",
    },
    "0x800F0003": {"name": "SPAPI_E_GENERAL_SYNTAX", "explanation": "The syntax of the INF is invalid."},
    "0x800F0100": {
        "name": "SPAPI_E_WRONG_INF_STYLE",
        "explanation": "The style of the INF is different than what was requested.",
    },
    "0x800F0101": {
        "name": "SPAPI_E_SECTION_NOT_FOUND",
        "explanation": "The required section was not found in the INF.",
    },
    "0x800F0102": {"name": "SPAPI_E_LINE_NOT_FOUND", "explanation": "The required line was not found in the INF."},
    "0x800F0103": {
        "name": "SPAPI_E_NO_BACKUP",
        "explanation": "The files affected by the installation of this file queue have not been backed up for uninstall.",
    },
    "0x800F0200": {
        "name": "SPAPI_E_NO_ASSOCIATED_CLASS",
        "explanation": "The INF or the device information set or element does not have an associated install class.",
    },
    "0x800F0201": {
        "name": "SPAPI_E_CLASS_MISMATCH",
        "explanation": "The INF or the device information set or element does not match the specified install class.",
    },
    "0x800F0202": {
        "name": "SPAPI_E_DUPLICATE_FOUND",
        "explanation": "An existing device was found that is a duplicate of the device being manually installed.",
    },
    "0x800F0203": {
        "name": "SPAPI_E_NO_DRIVER_SELECTED",
        "explanation": "There is no driver selected for the device information set or element.",
    },
    "0x800F0204": {
        "name": "SPAPI_E_KEY_DOES_NOT_EXIST",
        "explanation": "The requested device registry key does not exist.",
    },
    "0x800F0205": {"name": "SPAPI_E_INVALID_DEVINST_NAME", "explanation": "The device instance name is invalid."},
    "0x800F0206": {"name": "SPAPI_E_INVALID_CLASS", "explanation": "The install class is not present or is invalid."},
    "0x800F0207": {
        "name": "SPAPI_E_DEVINST_ALREADY_EXISTS",
        "explanation": "The device instance cannot be created because it already exists.",
    },
    "0x800F0208": {
        "name": "SPAPI_E_DEVINFO_NOT_REGISTERED",
        "explanation": "The operation cannot be performed on a device information element that has not been registered.",
    },
    "0x800F0209": {"name": "SPAPI_E_INVALID_REG_PROPERTY", "explanation": "The device property code is invalid."},
    "0x800F020A": {
        "name": "SPAPI_E_NO_INF",
        "explanation": "The INF from which a driver list is to be built does not exist.",
    },
    "0x800F020B": {
        "name": "SPAPI_E_NO_SUCH_DEVINST",
        "explanation": "The device instance does not exist in the hardware tree.",
    },
    "0x800F020C": {
        "name": "SPAPI_E_CANT_LOAD_CLASS_ICON",
        "explanation": "The icon representing this install class cannot be loaded.",
    },
    "0x800F020D": {
        "name": "SPAPI_E_INVALID_CLASS_INSTALLER",
        "explanation": "The class installer registry entry is invalid.",
    },
    "0x800F020E": {
        "name": "SPAPI_E_DI_DO_DEFAULT",
        "explanation": "The class installer has indicated that the default action should be performed for this installation request.",
    },
    "0x800F020F": {
        "name": "SPAPI_E_DI_NOFILECOPY",
        "explanation": "The operation does not require any files to be copied.",
    },
    "0x800F0210": {
        "name": "SPAPI_E_INVALID_HWPROFILE",
        "explanation": "The specified hardware profile does not exist.",
    },
    "0x800F0211": {
        "name": "SPAPI_E_NO_DEVICE_SELECTED",
        "explanation": "There is no device information element currently selected for this device information set.",
    },
    "0x800F0212": {
        "name": "SPAPI_E_DEVINFO_LIST_LOCKED",
        "explanation": "The operation cannot be performed because the device information set is locked.",
    },
    "0x800F0213": {
        "name": "SPAPI_E_DEVINFO_DATA_LOCKED",
        "explanation": "The operation cannot be performed because the device information element is locked.",
    },
    "0x800F0214": {
        "name": "SPAPI_E_DI_BAD_PATH",
        "explanation": "The specified path does not contain any applicable device INFs.",
    },
    "0x800F0215": {
        "name": "SPAPI_E_NO_CLASSINSTALL_PARAMS",
        "explanation": "No class installer parameters have been set for the device information set or element.",
    },
    "0x800F0216": {
        "name": "SPAPI_E_FILEQUEUE_LOCKED",
        "explanation": "The operation cannot be performed because the file queue is locked.",
    },
    "0x800F0217": {
        "name": "SPAPI_E_BAD_SERVICE_INSTALLSECT",
        "explanation": "A service installation section in this INF is invalid.",
    },
    "0x800F0218": {
        "name": "SPAPI_E_NO_CLASS_DRIVER_LIST",
        "explanation": "There is no class driver list for the device information element.",
    },
    "0x800F0219": {
        "name": "SPAPI_E_NO_ASSOCIATED_SERVICE",
        "explanation": "The installation failed because a function driver was not specified for this device instance.",
    },
    "0x800F021A": {
        "name": "SPAPI_E_NO_DEFAULT_DEVICE_INTERFACE",
        "explanation": "There is presently no default device interface designated for this interface class.",
    },
    "0x800F021B": {
        "name": "SPAPI_E_DEVICE_INTERFACE_ACTIVE",
        "explanation": "The operation cannot be performed because the device interface is currently active.",
    },
    "0x800F021C": {
        "name": "SPAPI_E_DEVICE_INTERFACE_REMOVED",
        "explanation": "The operation cannot be performed because the device interface has been removed from the system.",
    },
    "0x800F021D": {
        "name": "SPAPI_E_BAD_INTERFACE_INSTALLSECT",
        "explanation": "An interface installation section in this INF is invalid.",
    },
    "0x800F021E": {
        "name": "SPAPI_E_NO_SUCH_INTERFACE_CLASS",
        "explanation": "This interface class does not exist in the system.",
    },
    "0x800F021F": {
        "name": "SPAPI_E_INVALID_REFERENCE_STRING",
        "explanation": "The reference string supplied for this interface device is invalid.",
    },
    "0x800F0220": {
        "name": "SPAPI_E_INVALID_MACHINENAME",
        "explanation": "The specified machine name does not conform to Universal Naming Convention (UNCs).",
    },
    "0x800F0221": {
        "name": "SPAPI_E_REMOTE_COMM_FAILURE",
        "explanation": "A general remote communication error occurred.",
    },
    "0x800F0222": {
        "name": "SPAPI_E_MACHINE_UNAVAILABLE",
        "explanation": "The machine selected for remote communication is not available at this time.",
    },
    "0x800F0223": {
        "name": "SPAPI_E_NO_CONFIGMGR_SERVICES",
        "explanation": "The Plug and Play service is not available on the remote machine.",
    },
    "0x800F0224": {
        "name": "SPAPI_E_INVALID_PROPPAGE_PROVIDER",
        "explanation": "The property page provider registry entry is invalid.",
    },
    "0x800F0225": {
        "name": "SPAPI_E_NO_SUCH_DEVICE_INTERFACE",
        "explanation": "The requested device interface is not present in the system.",
    },
    "0x800F0226": {
        "name": "SPAPI_E_DI_POSTPROCESSING_REQUIRED",
        "explanation": "The device's co-installer has additional work to perform after installation is complete.",
    },
    "0x800F0227": {"name": "SPAPI_E_INVALID_COINSTALLER", "explanation": "The device's co-installer is invalid."},
    "0x800F0228": {
        "name": "SPAPI_E_NO_COMPAT_DRIVERS",
        "explanation": "There are no compatible drivers for this device.",
    },
    "0x800F0229": {
        "name": "SPAPI_E_NO_DEVICE_ICON",
        "explanation": "There is no icon that represents this device or device type.",
    },
    "0x800F022A": {
        "name": "SPAPI_E_INVALID_INF_LOGCONFIG",
        "explanation": "A logical configuration specified in this INF is invalid.",
    },
    "0x800F022B": {
        "name": "SPAPI_E_DI_DONT_INSTALL",
        "explanation": "The class installer has denied the request to install or upgrade this device.",
    },
    "0x800F022C": {
        "name": "SPAPI_E_INVALID_FILTER_DRIVER",
        "explanation": "One of the filter drivers installed for this device is invalid.",
    },
    "0x800F022D": {
        "name": "SPAPI_E_NON_WINDOWS_NT_DRIVER",
        "explanation": "The driver selected for this device does not support Windows XP operating system.",
    },
    "0x800F022E": {
        "name": "SPAPI_E_NON_WINDOWS_DRIVER",
        "explanation": "The driver selected for this device does not support Windows.",
    },
    "0x800F022F": {
        "name": "SPAPI_E_NO_CATALOG_FOR_OEM_INF",
        "explanation": "The third-party INF does not contain digital signature information.",
    },
    "0x800F0230": {
        "name": "SPAPI_E_DEVINSTALL_QUEUE_NONNATIVE",
        "explanation": "An invalid attempt was made to use a device installation file queue for verification of digital signatures relative to other platforms.",
    },
    "0x800F0231": {"name": "SPAPI_E_NOT_DISABLEABLE", "explanation": "The device cannot be disabled."},
    "0x800F0232": {
        "name": "SPAPI_E_CANT_REMOVE_DEVINST",
        "explanation": "The device could not be dynamically removed.",
    },
    "0x800F0233": {"name": "SPAPI_E_INVALID_TARGET", "explanation": "Cannot copy to specified target."},
    "0x800F0234": {"name": "SPAPI_E_DRIVER_NONNATIVE", "explanation": "Driver is not intended for this platform."},
    "0x800F0235": {"name": "SPAPI_E_IN_WOW64", "explanation": "Operation not allowed in WOW64."},
    "0x800F0236": {
        "name": "SPAPI_E_SET_SYSTEM_RESTORE_POINT",
        "explanation": "The operation involving unsigned file copying was rolled back, so that a system restore point could be set.",
    },
    "0x800F0237": {
        "name": "SPAPI_E_INCORRECTLY_COPIED_INF",
        "explanation": "An INF was copied into the Windows INF directory in an improper manner.",
    },
    "0x800F0238": {
        "name": "SPAPI_E_SCE_DISABLED",
        "explanation": "The Security Configuration Editor (SCE) APIs have been disabled on this embedded product.",
    },
    "0x800F0239": {"name": "SPAPI_E_UNKNOWN_EXCEPTION", "explanation": "An unknown exception was encountered."},
    "0x800F023A": {
        "name": "SPAPI_E_PNP_REGISTRY_ERROR",
        "explanation": "A problem was encountered when accessing the Plug and Play registry database.",
    },
    "0x800F023B": {
        "name": "SPAPI_E_REMOTE_REQUEST_UNSUPPORTED",
        "explanation": "The requested operation is not supported for a remote machine.",
    },
    "0x800F023C": {
        "name": "SPAPI_E_NOT_AN_INSTALLED_OEM_INF",
        "explanation": "The specified file is not an installed original equipment manufacturer (OEM) INF.",
    },
    "0x800F023D": {
        "name": "SPAPI_E_INF_IN_USE_BY_DEVICES",
        "explanation": "One or more devices are presently installed using the specified INF.",
    },
    "0x800F023E": {
        "name": "SPAPI_E_DI_FUNCTION_OBSOLETE",
        "explanation": "The requested device install operation is obsolete.",
    },
    "0x800F023F": {
        "name": "SPAPI_E_NO_AUTHENTICODE_CATALOG",
        "explanation": "A file could not be verified because it does not have an associated catalog signed via Authenticode.",
    },
    "0x800F0240": {
        "name": "SPAPI_E_AUTHENTICODE_DISALLOWED",
        "explanation": "Authenticode signature verification is not supported for the specified INF.",
    },
    "0x800F0241": {
        "name": "SPAPI_E_AUTHENTICODE_TRUSTED_PUBLISHER",
        "explanation": "The INF was signed with an Authenticode catalog from a trusted publisher.",
    },
    "0x800F0242": {
        "name": "SPAPI_E_AUTHENTICODE_TRUST_NOT_ESTABLISHED",
        "explanation": "The publisher of an Authenticode-signed catalog has not yet been established as trusted.",
    },
    "0x800F0243": {
        "name": "SPAPI_E_AUTHENTICODE_PUBLISHER_NOT_TRUSTED",
        "explanation": "The publisher of an Authenticode-signed catalog was not established as trusted.",
    },
    "0x800F0244": {
        "name": "SPAPI_E_SIGNATURE_OSATTRIBUTE_MISMATCH",
        "explanation": "The software was tested for compliance with Windows logo requirements on a different version of Windows and might not be compatible with this version.",
    },
    "0x800F0245": {
        "name": "SPAPI_E_ONLY_VALIDATE_VIA_AUTHENTICODE",
        "explanation": "The file can be validated only by a catalog signed via Authenticode.",
    },
    "0x800F0246": {
        "name": "SPAPI_E_DEVICE_INSTALLER_NOT_READY",
        "explanation": "One of the installers for this device cannot perform the installation at this time.",
    },
    "0x800F0247": {
        "name": "SPAPI_E_DRIVER_STORE_ADD_FAILED",
        "explanation": "A problem was encountered while attempting to add the driver to the store.",
    },
    "0x800F0248": {
        "name": "SPAPI_E_DEVICE_INSTALL_BLOCKED",
        "explanation": "The installation of this device is forbidden by system policy. Contact your system administrator.",
    },
    "0x800F0249": {
        "name": "SPAPI_E_DRIVER_INSTALL_BLOCKED",
        "explanation": "The installation of this driver is forbidden by system policy. Contact your system administrator.",
    },
    "0x800F024A": {
        "name": "SPAPI_E_WRONG_INF_TYPE",
        "explanation": "The specified INF is the wrong type for this operation.",
    },
    "0x800F024B": {
        "name": "SPAPI_E_FILE_HASH_NOT_IN_CATALOG",
        "explanation": "The hash for the file is not present in the specified catalog file. The file is likely corrupt or the victim of tampering.",
    },
    "0x800F024C": {
        "name": "SPAPI_E_DRIVER_STORE_DELETE_FAILED",
        "explanation": "A problem was encountered while attempting to delete the driver from the store.",
    },
    "0x800F0300": {
        "name": "SPAPI_E_UNRECOVERABLE_STACK_OVERFLOW",
        "explanation": "An unrecoverable stack overflow was encountered.",
    },
    "0x800F1000": {"name": "SPAPI_E_ERROR_NOT_INSTALLED", "explanation": "No installed components were detected."},
    "0x80100001": {"name": "SCARD_F_INTERNAL_ERROR", "explanation": "An internal consistency check failed."},
    "0x80100002": {"name": "SCARD_E_CANCELLED", "explanation": "The action was canceled by an SCardCancel request."},
    "0x80100003": {"name": "SCARD_E_INVALID_HANDLE", "explanation": "The supplied handle was invalid."},
    "0x80100004": {
        "name": "SCARD_E_INVALID_PARAMETER",
        "explanation": "One or more of the supplied parameters could not be properly interpreted.",
    },
    "0x80100005": {
        "name": "SCARD_E_INVALID_TARGET",
        "explanation": "Registry startup information is missing or invalid.",
    },
    "0x80100006": {"name": "SCARD_E_NO_MEMORY", "explanation": "Not enough memory available to complete this command."},
    "0x80100007": {"name": "SCARD_F_WAITED_TOO_LONG", "explanation": "An internal consistency timer has expired."},
    "0x80100008": {
        "name": "SCARD_E_INSUFFICIENT_BUFFER",
        "explanation": "The data buffer to receive returned data is too small for the returned data.",
    },
    "0x80100009": {"name": "SCARD_E_UNKNOWN_READER", "explanation": "The specified reader name is not recognized."},
    "0x8010000A": {"name": "SCARD_E_TIMEOUT", "explanation": "The user-specified time-out value has expired."},
    "0x8010000B": {
        "name": "SCARD_E_SHARING_VIOLATION",
        "explanation": "The smart card cannot be accessed because of other connections outstanding.",
    },
    "0x8010000C": {
        "name": "SCARD_E_NO_SMARTCARD",
        "explanation": "The operation requires a smart card, but no smart card is currently in the device.",
    },
    "0x8010000D": {"name": "SCARD_E_UNKNOWN_CARD", "explanation": "The specified smart card name is not recognized."},
    "0x8010000E": {
        "name": "SCARD_E_CANT_DISPOSE",
        "explanation": "The system could not dispose of the media in the requested manner.",
    },
    "0x8010000F": {
        "name": "SCARD_E_PROTO_MISMATCH",
        "explanation": "The requested protocols are incompatible with the protocol currently in use with the smart card.",
    },
    "0x80100010": {
        "name": "SCARD_E_NOT_READY",
        "explanation": "The reader or smart card is not ready to accept commands.",
    },
    "0x80100011": {
        "name": "SCARD_E_INVALID_VALUE",
        "explanation": "One or more of the supplied parameters values could not be properly interpreted.",
    },
    "0x80100012": {
        "name": "SCARD_E_SYSTEM_CANCELLED",
        "explanation": "The action was canceled by the system, presumably to log off or shut down.",
    },
    "0x80100013": {"name": "SCARD_F_COMM_ERROR", "explanation": "An internal communications error has been detected."},
    "0x80100014": {
        "name": "SCARD_F_UNKNOWN_ERROR",
        "explanation": "An internal error has been detected, but the source is unknown.",
    },
    "0x80100015": {
        "name": "SCARD_E_INVALID_ATR",
        "explanation": "An automatic terminal recognition (ATR) obtained from the registry is not a valid ATR string.",
    },
    "0x80100016": {
        "name": "SCARD_E_NOT_TRANSACTED",
        "explanation": "An attempt was made to end a nonexistent transaction.",
    },
    "0x80100017": {
        "name": "SCARD_E_READER_UNAVAILABLE",
        "explanation": "The specified reader is not currently available for use.",
    },
    "0x80100018": {
        "name": "SCARD_P_SHUTDOWN",
        "explanation": "The operation has been aborted to allow the server application to exit.",
    },
    "0x80100019": {
        "name": "SCARD_E_PCI_TOO_SMALL",
        "explanation": "The peripheral component interconnect (PCI) Receive buffer was too small.",
    },
    "0x8010001A": {
        "name": "SCARD_E_READER_UNSUPPORTED",
        "explanation": "The reader driver does not meet minimal requirements for support.",
    },
    "0x8010001B": {
        "name": "SCARD_E_DUPLICATE_READER",
        "explanation": "The reader driver did not produce a unique reader name.",
    },
    "0x8010001C": {
        "name": "SCARD_E_CARD_UNSUPPORTED",
        "explanation": "The smart card does not meet minimal requirements for support.",
    },
    "0x8010001D": {"name": "SCARD_E_NO_SERVICE", "explanation": "The smart card resource manager is not running."},
    "0x8010001E": {"name": "SCARD_E_SERVICE_STOPPED", "explanation": "The smart card resource manager has shut down."},
    "0x8010001F": {"name": "SCARD_E_UNEXPECTED", "explanation": "An unexpected card error has occurred."},
    "0x80100020": {
        "name": "SCARD_E_ICC_INSTALLATION",
        "explanation": "No primary provider can be found for the smart card.",
    },
    "0x80100021": {
        "name": "SCARD_E_ICC_CREATEORDER",
        "explanation": "The requested order of object creation is not supported.",
    },
    "0x80100022": {
        "name": "SCARD_E_UNSUPPORTED_FEATURE",
        "explanation": "This smart card does not support the requested feature.",
    },
    "0x80100023": {
        "name": "SCARD_E_DIR_NOT_FOUND",
        "explanation": "The identified directory does not exist in the smart card.",
    },
    "0x80100024": {
        "name": "SCARD_E_FILE_NOT_FOUND",
        "explanation": "The identified file does not exist in the smart card.",
    },
    "0x80100025": {
        "name": "SCARD_E_NO_DIR",
        "explanation": "The supplied path does not represent a smart card directory.",
    },
    "0x80100026": {"name": "SCARD_E_NO_FILE", "explanation": "The supplied path does not represent a smart card file."},
    "0x80100027": {"name": "SCARD_E_NO_ACCESS", "explanation": "Access is denied to this file."},
    "0x80100028": {
        "name": "SCARD_E_WRITE_TOO_MANY",
        "explanation": "The smart card does not have enough memory to store the information.",
    },
    "0x80100029": {
        "name": "SCARD_E_BAD_SEEK",
        "explanation": "There was an error trying to set the smart card file object pointer.",
    },
    "0x8010002A": {"name": "SCARD_E_INVALID_CHV", "explanation": "The supplied PIN is incorrect."},
    "0x8010002B": {
        "name": "SCARD_E_UNKNOWN_RES_MNG",
        "explanation": "An unrecognized error code was returned from a layered component.",
    },
    "0x8010002C": {"name": "SCARD_E_NO_SUCH_CERTIFICATE", "explanation": "The requested certificate does not exist."},
    "0x8010002D": {
        "name": "SCARD_E_CERTIFICATE_UNAVAILABLE",
        "explanation": "The requested certificate could not be obtained.",
    },
    "0x8010002E": {"name": "SCARD_E_NO_READERS_AVAILABLE", "explanation": "Cannot find a smart card reader."},
    "0x8010002F": {
        "name": "SCARD_E_COMM_DATA_LOST",
        "explanation": "A communications error with the smart card has been detected. Retry the operation.",
    },
    "0x80100030": {
        "name": "SCARD_E_NO_KEY_CONTAINER",
        "explanation": "The requested key container does not exist on the smart card.",
    },
    "0x80100031": {
        "name": "SCARD_E_SERVER_TOO_BUSY",
        "explanation": "The smart card resource manager is too busy to complete this operation.",
    },
    "0x80100065": {
        "name": "SCARD_W_UNSUPPORTED_CARD",
        "explanation": "The reader cannot communicate with the smart card, due to ATR configuration conflicts.",
    },
    "0x80100066": {"name": "SCARD_W_UNRESPONSIVE_CARD", "explanation": "The smart card is not responding to a reset."},
    "0x80100067": {
        "name": "SCARD_W_UNPOWERED_CARD",
        "explanation": "Power has been removed from the smart card, so that further communication is not possible.",
    },
    "0x80100068": {
        "name": "SCARD_W_RESET_CARD",
        "explanation": "The smart card has been reset, so any shared state information is invalid.",
    },
    "0x80100069": {
        "name": "SCARD_W_REMOVED_CARD",
        "explanation": "The smart card has been removed, so that further communication is not possible.",
    },
    "0x8010006A": {
        "name": "SCARD_W_SECURITY_VIOLATION",
        "explanation": "Access was denied because of a security violation.",
    },
    "0x8010006B": {
        "name": "SCARD_W_WRONG_CHV",
        "explanation": "The card cannot be accessed because the wrong PIN was presented.",
    },
    "0x8010006C": {
        "name": "SCARD_W_CHV_BLOCKED",
        "explanation": "The card cannot be accessed because the maximum number of PIN entry attempts has been reached.",
    },
    "0x8010006D": {"name": "SCARD_W_EOF", "explanation": "The end of the smart card file has been reached."},
    "0x8010006E": {"name": "SCARD_W_CANCELLED_BY_USER", "explanation": "The action was canceled by the user."},
    "0x8010006F": {"name": "SCARD_W_CARD_NOT_AUTHENTICATED", "explanation": "No PIN was presented to the smart card."},
    "0x80110401": {
        "name": "COMADMIN_E_OBJECTERRORS",
        "explanation": "Errors occurred accessing one or more objectsâ€”the ErrorInfo collection contains more detail.",
    },
    "0x80110402": {
        "name": "COMADMIN_E_OBJECTINVALID",
        "explanation": "One or more of the object's properties are missing or invalid.",
    },
    "0x80110403": {"name": "COMADMIN_E_KEYMISSING", "explanation": "The object was not found in the catalog."},
    "0x80110404": {"name": "COMADMIN_E_ALREADYINSTALLED", "explanation": "The object is already registered."},
    "0x80110407": {
        "name": "COMADMIN_E_APP_FILE_WRITEFAIL",
        "explanation": "An error occurred writing to the application file.",
    },
    "0x80110408": {
        "name": "COMADMIN_E_APP_FILE_READFAIL",
        "explanation": "An error occurred reading the application file.",
    },
    "0x80110409": {"name": "COMADMIN_E_APP_FILE_VERSION", "explanation": "Invalid version number in application file."},
    "0x8011040A": {"name": "COMADMIN_E_BADPATH", "explanation": "The file path is invalid."},
    "0x8011040B": {"name": "COMADMIN_E_APPLICATIONEXISTS", "explanation": "The application is already installed."},
    "0x8011040C": {"name": "COMADMIN_E_ROLEEXISTS", "explanation": "The role already exists."},
    "0x8011040D": {"name": "COMADMIN_E_CANTCOPYFILE", "explanation": "An error occurred copying the file."},
    "0x8011040F": {"name": "COMADMIN_E_NOUSER", "explanation": "One or more users are not valid."},
    "0x80110410": {
        "name": "COMADMIN_E_INVALIDUSERIDS",
        "explanation": "One or more users in the application file are not valid.",
    },
    "0x80110411": {"name": "COMADMIN_E_NOREGISTRYCLSID", "explanation": "The component's CLSID is missing or corrupt."},
    "0x80110412": {
        "name": "COMADMIN_E_BADREGISTRYPROGID",
        "explanation": "The component's programmatic ID is missing or corrupt.",
    },
    "0x80110413": {
        "name": "COMADMIN_E_AUTHENTICATIONLEVEL",
        "explanation": "Unable to set required authentication level for update request.",
    },
    "0x80110414": {
        "name": "COMADMIN_E_USERPASSWDNOTVALID",
        "explanation": "The identity or password set on the application is not valid.",
    },
    "0x80110418": {
        "name": "COMADMIN_E_CLSIDORIIDMISMATCH",
        "explanation": "Application file CLSIDs or instance identifiers (IIDs) do not match corresponding DLLs.",
    },
    "0x80110419": {
        "name": "COMADMIN_E_REMOTEINTERFACE",
        "explanation": "Interface information is either missing or changed.",
    },
    "0x8011041A": {
        "name": "COMADMIN_E_DLLREGISTERSERVER",
        "explanation": "DllRegisterServer failed on component install.",
    },
    "0x8011041B": {"name": "COMADMIN_E_NOSERVERSHARE", "explanation": "No server file share available."},
    "0x8011041D": {"name": "COMADMIN_E_DLLLOADFAILED", "explanation": "DLL could not be loaded."},
    "0x8011041E": {"name": "COMADMIN_E_BADREGISTRYLIBID", "explanation": "The registered TypeLib ID is not valid."},
    "0x8011041F": {"name": "COMADMIN_E_APPDIRNOTFOUND", "explanation": "Application install directory not found."},
    "0x80110423": {
        "name": "COMADMIN_E_REGISTRARFAILED",
        "explanation": "Errors occurred while in the component registrar.",
    },
    "0x80110424": {"name": "COMADMIN_E_COMPFILE_DOESNOTEXIST", "explanation": "The file does not exist."},
    "0x80110425": {"name": "COMADMIN_E_COMPFILE_LOADDLLFAIL", "explanation": "The DLL could not be loaded."},
    "0x80110426": {"name": "COMADMIN_E_COMPFILE_GETCLASSOBJ", "explanation": "GetClassObject failed in the DLL."},
    "0x80110427": {
        "name": "COMADMIN_E_COMPFILE_CLASSNOTAVAIL",
        "explanation": "The DLL does not support the components listed in the TypeLib.",
    },
    "0x80110428": {"name": "COMADMIN_E_COMPFILE_BADTLB", "explanation": "The TypeLib could not be loaded."},
    "0x80110429": {
        "name": "COMADMIN_E_COMPFILE_NOTINSTALLABLE",
        "explanation": "The file does not contain components or component information.",
    },
    "0x8011042A": {
        "name": "COMADMIN_E_NOTCHANGEABLE",
        "explanation": "Changes to this object and its subobjects have been disabled.",
    },
    "0x8011042B": {
        "name": "COMADMIN_E_NOTDELETEABLE",
        "explanation": "The delete function has been disabled for this object.",
    },
    "0x8011042C": {"name": "COMADMIN_E_SESSION", "explanation": "The server catalog version is not supported."},
    "0x8011042D": {
        "name": "COMADMIN_E_COMP_MOVE_LOCKED",
        "explanation": "The component move was disallowed because the source or destination application is either a system application or currently locked against changes.",
    },
    "0x8011042E": {
        "name": "COMADMIN_E_COMP_MOVE_BAD_DEST",
        "explanation": "The component move failed because the destination application no longer exists.",
    },
    "0x80110430": {"name": "COMADMIN_E_REGISTERTLB", "explanation": "The system was unable to register the TypeLib."},
    "0x80110433": {
        "name": "COMADMIN_E_SYSTEMAPP",
        "explanation": "This operation cannot be performed on the system application.",
    },
    "0x80110434": {
        "name": "COMADMIN_E_COMPFILE_NOREGISTRAR",
        "explanation": "The component registrar referenced in this file is not available.",
    },
    "0x80110435": {
        "name": "COMADMIN_E_COREQCOMPINSTALLED",
        "explanation": "A component in the same DLL is already installed.",
    },
    "0x80110436": {"name": "COMADMIN_E_SERVICENOTINSTALLED", "explanation": "The service is not installed."},
    "0x80110437": {
        "name": "COMADMIN_E_PROPERTYSAVEFAILED",
        "explanation": "One or more property settings are either invalid or in conflict with each other.",
    },
    "0x80110438": {
        "name": "COMADMIN_E_OBJECTEXISTS",
        "explanation": "The object you are attempting to add or rename already exists.",
    },
    "0x80110439": {"name": "COMADMIN_E_COMPONENTEXISTS", "explanation": "The component already exists."},
    "0x8011043B": {"name": "COMADMIN_E_REGFILE_CORRUPT", "explanation": "The registration file is corrupt."},
    "0x8011043C": {"name": "COMADMIN_E_PROPERTY_OVERFLOW", "explanation": "The property value is too large."},
    "0x8011043E": {"name": "COMADMIN_E_NOTINREGISTRY", "explanation": "Object was not found in registry."},
    "0x8011043F": {"name": "COMADMIN_E_OBJECTNOTPOOLABLE", "explanation": "This object cannot be pooled."},
    "0x80110446": {
        "name": "COMADMIN_E_APPLID_MATCHES_CLSID",
        "explanation": "A CLSID with the same GUID as the new application ID is already installed on this machine.",
    },
    "0x80110447": {
        "name": "COMADMIN_E_ROLE_DOES_NOT_EXIST",
        "explanation": "A role assigned to a component, interface, or method did not exist in the application.",
    },
    "0x80110448": {
        "name": "COMADMIN_E_START_APP_NEEDS_COMPONENTS",
        "explanation": "You must have components in an application to start the application.",
    },
    "0x80110449": {
        "name": "COMADMIN_E_REQUIRES_DIFFERENT_PLATFORM",
        "explanation": "This operation is not enabled on this platform.",
    },
    "0x8011044A": {
        "name": "COMADMIN_E_CAN_NOT_EXPORT_APP_PROXY",
        "explanation": "Application proxy is not exportable.",
    },
    "0x8011044B": {
        "name": "COMADMIN_E_CAN_NOT_START_APP",
        "explanation": "Failed to start application because it is either a library application or an application proxy.",
    },
    "0x8011044C": {"name": "COMADMIN_E_CAN_NOT_EXPORT_SYS_APP", "explanation": "System application is not exportable."},
    "0x8011044D": {
        "name": "COMADMIN_E_CANT_SUBSCRIBE_TO_COMPONENT",
        "explanation": "Cannot subscribe to this component (the component might have been imported).",
    },
    "0x8011044E": {
        "name": "COMADMIN_E_EVENTCLASS_CANT_BE_SUBSCRIBER",
        "explanation": "An event class cannot also be a subscriber component.",
    },
    "0x8011044F": {
        "name": "COMADMIN_E_LIB_APP_PROXY_INCOMPATIBLE",
        "explanation": "Library applications and application proxies are incompatible.",
    },
    "0x80110450": {
        "name": "COMADMIN_E_BASE_PARTITION_ONLY",
        "explanation": "This function is valid for the base partition only.",
    },
    "0x80110451": {
        "name": "COMADMIN_E_START_APP_DISABLED",
        "explanation": "You cannot start an application that has been disabled.",
    },
    "0x80110457": {
        "name": "COMADMIN_E_CAT_DUPLICATE_PARTITION_NAME",
        "explanation": "The specified partition name is already in use on this computer.",
    },
    "0x80110458": {
        "name": "COMADMIN_E_CAT_INVALID_PARTITION_NAME",
        "explanation": "The specified partition name is invalid. Check that the name contains at least one visible character.",
    },
    "0x80110459": {
        "name": "COMADMIN_E_CAT_PARTITION_IN_USE",
        "explanation": "The partition cannot be deleted because it is the default partition for one or more users.",
    },
    "0x8011045A": {
        "name": "COMADMIN_E_FILE_PARTITION_DUPLICATE_FILES",
        "explanation": "The partition cannot be exported because one or more components in the partition have the same file name.",
    },
    "0x8011045B": {
        "name": "COMADMIN_E_CAT_IMPORTED_COMPONENTS_NOT_ALLOWED",
        "explanation": "Applications that contain one or more imported components cannot be installed into a nonbase partition.",
    },
    "0x8011045C": {
        "name": "COMADMIN_E_AMBIGUOUS_APPLICATION_NAME",
        "explanation": "The application name is not unique and cannot be resolved to an application ID.",
    },
    "0x8011045D": {
        "name": "COMADMIN_E_AMBIGUOUS_PARTITION_NAME",
        "explanation": "The partition name is not unique and cannot be resolved to a partition ID.",
    },
    "0x80110472": {
        "name": "COMADMIN_E_REGDB_NOTINITIALIZED",
        "explanation": "The COM+ registry database has not been initialized.",
    },
    "0x80110473": {"name": "COMADMIN_E_REGDB_NOTOPEN", "explanation": "The COM+ registry database is not open."},
    "0x80110474": {
        "name": "COMADMIN_E_REGDB_SYSTEMERR",
        "explanation": "The COM+ registry database detected a system error.",
    },
    "0x80110475": {
        "name": "COMADMIN_E_REGDB_ALREADYRUNNING",
        "explanation": "The COM+ registry database is already running.",
    },
    "0x80110480": {
        "name": "COMADMIN_E_MIG_VERSIONNOTSUPPORTED",
        "explanation": "This version of the COM+ registry database cannot be migrated.",
    },
    "0x80110481": {
        "name": "COMADMIN_E_MIG_SCHEMANOTFOUND",
        "explanation": "The schema version to be migrated could not be found in the COM+ registry database.",
    },
    "0x80110482": {
        "name": "COMADMIN_E_CAT_BITNESSMISMATCH",
        "explanation": "There was a type mismatch between binaries.",
    },
    "0x80110483": {
        "name": "COMADMIN_E_CAT_UNACCEPTABLEBITNESS",
        "explanation": "A binary of unknown or invalid type was provided.",
    },
    "0x80110484": {
        "name": "COMADMIN_E_CAT_WRONGAPPBITNESS",
        "explanation": "There was a type mismatch between a binary and an application.",
    },
    "0x80110485": {
        "name": "COMADMIN_E_CAT_PAUSE_RESUME_NOT_SUPPORTED",
        "explanation": "The application cannot be paused or resumed.",
    },
    "0x80110486": {
        "name": "COMADMIN_E_CAT_SERVERFAULT",
        "explanation": "The COM+ catalog server threw an exception during execution.",
    },
    "0x80110600": {
        "name": "COMQC_E_APPLICATION_NOT_QUEUED",
        "explanation": 'Only COM+ applications marked "queued" can be invoked using the "queue" moniker.',
    },
    "0x80110601": {
        "name": "COMQC_E_NO_QUEUEABLE_INTERFACES",
        "explanation": 'At least one interface must be marked "queued" to create a queued component instance with the "queue" moniker.',
    },
    "0x80110602": {
        "name": "COMQC_E_QUEUING_SERVICE_NOT_AVAILABLE",
        "explanation": "Message Queuing is required for the requested operation and is not installed.",
    },
    "0x80110603": {
        "name": "COMQC_E_NO_IPERSISTSTREAM",
        "explanation": "Unable to marshal an interface that does not support IPersistStream.",
    },
    "0x80110604": {
        "name": "COMQC_E_BAD_MESSAGE",
        "explanation": "The message is improperly formatted or was damaged in transit.",
    },
    "0x80110605": {
        "name": "COMQC_E_UNAUTHENTICATED",
        "explanation": "An unauthenticated message was received by an application that accepts only authenticated messages.",
    },
    "0x80110606": {
        "name": "COMQC_E_UNTRUSTED_ENQUEUER",
        "explanation": 'The message was requeued or moved by a user not in the QC Trusted User "role".',
    },
    "0x80110701": {
        "name": "MSDTC_E_DUPLICATE_RESOURCE",
        "explanation": "Cannot create a duplicate resource of type Distributed Transaction Coordinator.",
    },
    "0x80110808": {
        "name": "COMADMIN_E_OBJECT_PARENT_MISSING",
        "explanation": "One of the objects being inserted or updated does not belong to a valid parent collection.",
    },
    "0x80110809": {
        "name": "COMADMIN_E_OBJECT_DOES_NOT_EXIST",
        "explanation": "One of the specified objects cannot be found.",
    },
    "0x8011080A": {
        "name": "COMADMIN_E_APP_NOT_RUNNING",
        "explanation": "The specified application is not currently running.",
    },
    "0x8011080B": {"name": "COMADMIN_E_INVALID_PARTITION", "explanation": "The partitions specified are not valid."},
    "0x8011080D": {
        "name": "COMADMIN_E_SVCAPP_NOT_POOLABLE_OR_RECYCLABLE",
        "explanation": "COM+ applications that run as Windows NT service cannot be pooled or recycled.",
    },
    "0x8011080E": {
        "name": "COMADMIN_E_USER_IN_SET",
        "explanation": "One or more users are already assigned to a local partition set.",
    },
    "0x8011080F": {
        "name": "COMADMIN_E_CANTRECYCLELIBRARYAPPS",
        "explanation": "Library applications cannot be recycled.",
    },
    "0x80110811": {
        "name": "COMADMIN_E_CANTRECYCLESERVICEAPPS",
        "explanation": "Applications running as Windows NT services cannot be recycled.",
    },
    "0x80110812": {
        "name": "COMADMIN_E_PROCESSALREADYRECYCLED",
        "explanation": "The process has already been recycled.",
    },
    "0x80110813": {
        "name": "COMADMIN_E_PAUSEDPROCESSMAYNOTBERECYCLED",
        "explanation": "A paused process cannot be recycled.",
    },
    "0x80110814": {
        "name": "COMADMIN_E_CANTMAKEINPROCSERVICE",
        "explanation": "Library applications cannot be Windows NT services.",
    },
    "0x80110815": {
        "name": "COMADMIN_E_PROGIDINUSEBYCLSID",
        "explanation": "The ProgID provided to the copy operation is invalid. The ProgID is in use by another registered CLSID.",
    },
    "0x80110816": {
        "name": "COMADMIN_E_DEFAULT_PARTITION_NOT_IN_SET",
        "explanation": "The partition specified as the default is not a member of the partition set.",
    },
    "0x80110817": {
        "name": "COMADMIN_E_RECYCLEDPROCESSMAYNOTBEPAUSED",
        "explanation": "A recycled process cannot be paused.",
    },
    "0x80110818": {
        "name": "COMADMIN_E_PARTITION_ACCESSDENIED",
        "explanation": "Access to the specified partition is denied.",
    },
    "0x80110819": {
        "name": "COMADMIN_E_PARTITION_MSI_ONLY",
        "explanation": "Only application files (*.msi files) can be installed into partitions.",
    },
    "0x8011081A": {
        "name": "COMADMIN_E_LEGACYCOMPS_NOT_ALLOWED_IN_1_0_FORMAT",
        "explanation": "Applications containing one or more legacy components cannot be exported to 1.0 format.",
    },
    "0x8011081B": {
        "name": "COMADMIN_E_LEGACYCOMPS_NOT_ALLOWED_IN_NONBASE_PARTITIONS",
        "explanation": "Legacy components cannot exist in nonbase partitions.",
    },
    "0x8011081C": {
        "name": "COMADMIN_E_COMP_MOVE_SOURCE",
        "explanation": "A component cannot be moved (or copied) from the System Application, an application proxy, or a nonchangeable application.",
    },
    "0x8011081D": {
        "name": "COMADMIN_E_COMP_MOVE_DEST",
        "explanation": "A component cannot be moved (or copied) to the System Application, an application proxy or a nonchangeable application.",
    },
    "0x8011081E": {
        "name": "COMADMIN_E_COMP_MOVE_PRIVATE",
        "explanation": "A private component cannot be moved (or copied) to a library application or to the base partition.",
    },
    "0x8011081F": {
        "name": "COMADMIN_E_BASEPARTITION_REQUIRED_IN_SET",
        "explanation": "The Base Application Partition exists in all partition sets and cannot be removed.",
    },
    "0x80110820": {
        "name": "COMADMIN_E_CANNOT_ALIAS_EVENTCLASS",
        "explanation": "Alas, Event Class components cannot be aliased.",
    },
    "0x80110821": {
        "name": "COMADMIN_E_PRIVATE_ACCESSDENIED",
        "explanation": "Access is denied because the component is private.",
    },
    "0x80110822": {"name": "COMADMIN_E_SAFERINVALID", "explanation": "The specified SAFER level is invalid."},
    "0x80110823": {
        "name": "COMADMIN_E_REGISTRY_ACCESSDENIED",
        "explanation": "The specified user cannot write to the system registry.",
    },
    "0x80110824": {"name": "COMADMIN_E_PARTITIONS_DISABLED", "explanation": "COM+ partitions are currently disabled."},
    "0x801F0001": {
        "name": "ERROR_FLT_NO_HANDLER_DEFINED",
        "explanation": "A handler was not defined by the filter for this operation.",
    },
    "0x801F0002": {
        "name": "ERROR_FLT_CONTEXT_ALREADY_DEFINED",
        "explanation": "A context is already defined for this object.",
    },
    "0x801F0003": {
        "name": "ERROR_FLT_INVALID_ASYNCHRONOUS_REQUEST",
        "explanation": "Asynchronous requests are not valid for this operation.",
    },
    "0x801F0004": {
        "name": "ERROR_FLT_DISALLOW_FAST_IO",
        "explanation": "Disallow the Fast IO path for this operation.",
    },
    "0x801F0005": {
        "name": "ERROR_FLT_INVALID_NAME_REQUEST",
        "explanation": "An invalid name request was made. The name requested cannot be retrieved at this time.",
    },
    "0x801F0006": {
        "name": "ERROR_FLT_NOT_SAFE_TO_POST_OPERATION",
        "explanation": "Posting this operation to a worker thread for further processing is not safe at this time because it could lead to a system deadlock.",
    },
    "0x801F0007": {
        "name": "ERROR_FLT_NOT_INITIALIZED",
        "explanation": "The Filter Manager was not initialized when a filter tried to register. Be sure that the Filter Manager is being loaded as a driver.",
    },
    "0x801F0008": {
        "name": "ERROR_FLT_FILTER_NOT_READY",
        "explanation": "The filter is not ready for attachment to volumes because it has not finished initializing (FltStartFiltering has not been called).",
    },
    "0x801F0009": {
        "name": "ERROR_FLT_POST_OPERATION_CLEANUP",
        "explanation": "The filter must clean up any operation-specific context at this time because it is being removed from the system before the operation is completed by the lower drivers.",
    },
    "0x801F000A": {
        "name": "ERROR_FLT_INTERNAL_ERROR",
        "explanation": "The Filter Manager had an internal error from which it cannot recover; therefore, the operation has been failed. This is usually the result of a filter returning an invalid value from a preoperation callback.",
    },
    "0x801F000B": {
        "name": "ERROR_FLT_DELETING_OBJECT",
        "explanation": "The object specified for this action is in the process of being deleted; therefore, the action requested cannot be completed at this time.",
    },
    "0x801F000C": {
        "name": "ERROR_FLT_MUST_BE_NONPAGED_POOL",
        "explanation": "Nonpaged pool must be used for this type of context.",
    },
    "0x801F000D": {
        "name": "ERROR_FLT_DUPLICATE_ENTRY",
        "explanation": "A duplicate handler definition has been provided for an operation.",
    },
    "0x801F000E": {"name": "ERROR_FLT_CBDQ_DISABLED", "explanation": "The callback data queue has been disabled."},
    "0x801F000F": {
        "name": "ERROR_FLT_DO_NOT_ATTACH",
        "explanation": "Do not attach the filter to the volume at this time.",
    },
    "0x801F0010": {
        "name": "ERROR_FLT_DO_NOT_DETACH",
        "explanation": "Do not detach the filter from the volume at this time.",
    },
    "0x801F0011": {
        "name": "ERROR_FLT_INSTANCE_ALTITUDE_COLLISION",
        "explanation": "An instance already exists at this altitude on the volume specified.",
    },
    "0x801F0012": {
        "name": "ERROR_FLT_INSTANCE_NAME_COLLISION",
        "explanation": "An instance already exists with this name on the volume specified.",
    },
    "0x801F0013": {
        "name": "ERROR_FLT_FILTER_NOT_FOUND",
        "explanation": "The system could not find the filter specified.",
    },
    "0x801F0014": {
        "name": "ERROR_FLT_VOLUME_NOT_FOUND",
        "explanation": "The system could not find the volume specified.",
    },
    "0x801F0015": {
        "name": "ERROR_FLT_INSTANCE_NOT_FOUND",
        "explanation": "The system could not find the instance specified.",
    },
    "0x801F0016": {
        "name": "ERROR_FLT_CONTEXT_ALLOCATION_NOT_FOUND",
        "explanation": "No registered context allocation definition was found for the given request.",
    },
    "0x801F0017": {
        "name": "ERROR_FLT_INVALID_CONTEXT_REGISTRATION",
        "explanation": "An invalid parameter was specified during context registration.",
    },
    "0x801F0018": {
        "name": "ERROR_FLT_NAME_CACHE_MISS",
        "explanation": "The name requested was not found in the Filter Manager name cache and could not be retrieved from the file system.",
    },
    "0x801F0019": {
        "name": "ERROR_FLT_NO_DEVICE_OBJECT",
        "explanation": "The requested device object does not exist for the given volume.",
    },
    "0x801F001A": {
        "name": "ERROR_FLT_VOLUME_ALREADY_MOUNTED",
        "explanation": "The specified volume is already mounted.",
    },
    "0x801F001B": {
        "name": "ERROR_FLT_ALREADY_ENLISTED",
        "explanation": "The specified Transaction Context is already enlisted in a transaction.",
    },
    "0x801F001C": {
        "name": "ERROR_FLT_CONTEXT_ALREADY_LINKED",
        "explanation": "The specified context is already attached to another object.",
    },
    "0x801F0020": {
        "name": "ERROR_FLT_NO_WAITER_FOR_REPLY",
        "explanation": "No waiter is present for the filter's reply to this message.",
    },
    "0x80260001": {
        "name": "ERROR_HUNG_DISPLAY_DRIVER_THREAD",
        "explanation": "{Display Driver Stopped Responding} The %hs display driver has stopped working normally. Save your work and reboot the system to restore full display functionality. The next time you reboot the machine a dialog will be displayed giving you a chance to report this failure to Microsoft.",
    },
    "0x80261001": {"name": "ERROR_MONITOR_NO_DESCRIPTOR", "explanation": "Monitor descriptor could not be obtained."},
    "0x80261002": {
        "name": "ERROR_MONITOR_UNKNOWN_DESCRIPTOR_FORMAT",
        "explanation": "Format of the obtained monitor descriptor is not supported by this release.",
    },
    "0x80263001": {
        "name": "DWM_E_COMPOSITIONDISABLED",
        "explanation": "{Desktop Composition is Disabled} The operation could not be completed because desktop composition is disabled.",
    },
    "0x80263002": {
        "name": "DWM_E_REMOTING_NOT_SUPPORTED",
        "explanation": "{Some Desktop Composition APIs Are Not Supported While Remoting} Some desktop composition APIs are not supported while remoting. The operation is not supported while running in a remote session.",
    },
    "0x80263003": {
        "name": "DWM_E_NO_REDIRECTION_SURFACE_AVAILABLE",
        "explanation": "{No DWM Redirection Surface is Available} The Desktop Window Manager (DWM) was unable to provide a redirection surface to complete the DirectX present.",
    },
    "0x80263004": {
        "name": "DWM_E_NOT_QUEUING_PRESENTS",
        "explanation": "{DWM Is Not Queuing Presents for the Specified Window} The window specified is not currently using queued presents.",
    },
    "0x80280000": {
        "name": "TPM_E_ERROR_MASK",
        "explanation": "This is an error mask to convert Trusted Platform Module (TPM) hardware errors to Win32 errors.",
    },
    "0x80280001": {"name": "TPM_E_AUTHFAIL", "explanation": "Authentication failed."},
    "0x80280002": {
        "name": "TPM_E_BADINDEX",
        "explanation": "The index to a Platform Configuration Register (PCR), DIR, or other register is incorrect.",
    },
    "0x80280003": {"name": "TPM_E_BAD_PARAMETER", "explanation": "One or more parameters are bad."},
    "0x80280004": {
        "name": "TPM_E_AUDITFAILURE",
        "explanation": "An operation completed successfully but the auditing of that operation failed.",
    },
    "0x80280005": {
        "name": "TPM_E_CLEAR_DISABLED",
        "explanation": "The clear disable flag is set and all clear operations now require physical access.",
    },
    "0x80280006": {"name": "TPM_E_DEACTIVATED", "explanation": "The TPM is deactivated."},
    "0x80280007": {"name": "TPM_E_DISABLED", "explanation": "The TPM is disabled."},
    "0x80280008": {"name": "TPM_E_DISABLED_CMD", "explanation": "The target command has been disabled."},
    "0x80280009": {"name": "TPM_E_FAIL", "explanation": "The operation failed."},
    "0x8028000A": {"name": "TPM_E_BAD_ORDINAL", "explanation": "The ordinal was unknown or inconsistent."},
    "0x8028000B": {"name": "TPM_E_INSTALL_DISABLED", "explanation": "The ability to install an owner is disabled."},
    "0x8028000C": {"name": "TPM_E_INVALID_KEYHANDLE", "explanation": "The key handle cannot be interpreted."},
    "0x8028000D": {"name": "TPM_E_KEYNOTFOUND", "explanation": "The key handle points to an invalid key."},
    "0x8028000E": {"name": "TPM_E_INAPPROPRIATE_ENC", "explanation": "Unacceptable encryption scheme."},
    "0x8028000F": {"name": "TPM_E_MIGRATEFAIL", "explanation": "Migration authorization failed."},
    "0x80280010": {"name": "TPM_E_INVALID_PCR_INFO", "explanation": "PCR information could not be interpreted."},
    "0x80280011": {"name": "TPM_E_NOSPACE", "explanation": "No room to load key."},
    "0x80280012": {"name": "TPM_E_NOSRK", "explanation": "There is no storage root key (SRK) set."},
    "0x80280013": {
        "name": "TPM_E_NOTSEALED_BLOB",
        "explanation": "An encrypted blob is invalid or was not created by this TPM.",
    },
    "0x80280014": {"name": "TPM_E_OWNER_SET", "explanation": "There is already an owner."},
    "0x80280015": {
        "name": "TPM_E_RESOURCES",
        "explanation": "The TPM has insufficient internal resources to perform the requested action.",
    },
    "0x80280016": {"name": "TPM_E_SHORTRANDOM", "explanation": "A random string was too short."},
    "0x80280017": {"name": "TPM_E_SIZE", "explanation": "The TPM does not have the space to perform the operation."},
    "0x80280018": {
        "name": "TPM_E_WRONGPCRVAL",
        "explanation": "The named PCR value does not match the current PCR value.",
    },
    "0x80280019": {
        "name": "TPM_E_BAD_PARAM_SIZE",
        "explanation": "The paramSize argument to the command has the incorrect value.",
    },
    "0x8028001A": {"name": "TPM_E_SHA_THREAD", "explanation": "There is no existing SHA-1 thread."},
    "0x8028001B": {
        "name": "TPM_E_SHA_ERROR",
        "explanation": "The calculation is unable to proceed because the existing SHA-1 thread has already encountered an error.",
    },
    "0x8028001C": {"name": "TPM_E_FAILEDSELFTEST", "explanation": "Self-test has failed and the TPM has shut down."},
    "0x8028001D": {
        "name": "TPM_E_AUTH2FAIL",
        "explanation": "The authorization for the second key in a two-key function failed authorization.",
    },
    "0x8028001E": {"name": "TPM_E_BADTAG", "explanation": "The tag value sent to for a command is invalid."},
    "0x8028001F": {
        "name": "TPM_E_IOERROR",
        "explanation": "An I/O error occurred transmitting information to the TPM.",
    },
    "0x80280020": {"name": "TPM_E_ENCRYPT_ERROR", "explanation": "The encryption process had a problem."},
    "0x80280021": {"name": "TPM_E_DECRYPT_ERROR", "explanation": "The decryption process did not complete."},
    "0x80280022": {"name": "TPM_E_INVALID_AUTHHANDLE", "explanation": "An invalid handle was used."},
    "0x80280023": {
        "name": "TPM_E_NO_ENDORSEMENT",
        "explanation": "The TPM does not have an endorsement key (EK) installed.",
    },
    "0x80280024": {"name": "TPM_E_INVALID_KEYUSAGE", "explanation": "The usage of a key is not allowed."},
    "0x80280025": {"name": "TPM_E_WRONG_ENTITYTYPE", "explanation": "The submitted entity type is not allowed."},
    "0x80280026": {
        "name": "TPM_E_INVALID_POSTINIT",
        "explanation": "The command was received in the wrong sequence relative to TPM_Init and a subsequent TPM_Startup.",
    },
    "0x80280027": {
        "name": "TPM_E_INAPPROPRIATE_SIG",
        "explanation": "Signed data cannot include additional DER information.",
    },
    "0x80280028": {
        "name": "TPM_E_BAD_KEY_PROPERTY",
        "explanation": "The key properties in TPM_KEY_PARMs are not supported by this TPM.",
    },
    "0x80280029": {"name": "TPM_E_BAD_MIGRATION", "explanation": "The migration properties of this key are incorrect."},
    "0x8028002A": {
        "name": "TPM_E_BAD_SCHEME",
        "explanation": "The signature or encryption scheme for this key is incorrect or not permitted in this situation.",
    },
    "0x8028002B": {
        "name": "TPM_E_BAD_DATASIZE",
        "explanation": "The size of the data (or blob) parameter is bad or inconsistent with the referenced key.",
    },
    "0x8028002C": {
        "name": "TPM_E_BAD_MODE",
        "explanation": "A mode parameter is bad, such as capArea or subCapArea for TPM_GetCapability, physicalPresence parameter for TPM_PhysicalPresence, or migrationType for TPM_CreateMigrationBlob.",
    },
    "0x8028002D": {
        "name": "TPM_E_BAD_PRESENCE",
        "explanation": "Either the physicalPresence or physicalPresenceLock bits have the wrong value.",
    },
    "0x8028002E": {
        "name": "TPM_E_BAD_VERSION",
        "explanation": "The TPM cannot perform this version of the capability.",
    },
    "0x8028002F": {
        "name": "TPM_E_NO_WRAP_TRANSPORT",
        "explanation": "The TPM does not allow for wrapped transport sessions.",
    },
    "0x80280030": {
        "name": "TPM_E_AUDITFAIL_UNSUCCESSFUL",
        "explanation": "TPM audit construction failed and the underlying command was returning a failure code also.",
    },
    "0x80280031": {
        "name": "TPM_E_AUDITFAIL_SUCCESSFUL",
        "explanation": "TPM audit construction failed and the underlying command was returning success.",
    },
    "0x80280032": {
        "name": "TPM_E_NOTRESETABLE",
        "explanation": "Attempt to reset a PCR that does not have the resettable attribute.",
    },
    "0x80280033": {
        "name": "TPM_E_NOTLOCAL",
        "explanation": "Attempt to reset a PCR register that requires locality and the locality modifier not part of command transport.",
    },
    "0x80280034": {"name": "TPM_E_BAD_TYPE", "explanation": "Make identity blob not properly typed."},
    "0x80280035": {
        "name": "TPM_E_INVALID_RESOURCE",
        "explanation": "When saving context identified resource type does not match actual resource.",
    },
    "0x80280036": {
        "name": "TPM_E_NOTFIPS",
        "explanation": "The TPM is attempting to execute a command only available when in Federal Information Processing Standards (FIPS) mode.",
    },
    "0x80280037": {
        "name": "TPM_E_INVALID_FAMILY",
        "explanation": "The command is attempting to use an invalid family ID.",
    },
    "0x80280038": {
        "name": "TPM_E_NO_NV_PERMISSION",
        "explanation": "The permission to manipulate the NV storage is not available.",
    },
    "0x80280039": {"name": "TPM_E_REQUIRES_SIGN", "explanation": "The operation requires a signed command."},
    "0x8028003A": {"name": "TPM_E_KEY_NOTSUPPORTED", "explanation": "Wrong operation to load an NV key."},
    "0x8028003B": {
        "name": "TPM_E_AUTH_CONFLICT",
        "explanation": "NV_LoadKey blob requires both owner and blob authorization.",
    },
    "0x8028003C": {"name": "TPM_E_AREA_LOCKED", "explanation": "The NV area is locked and not writable."},
    "0x8028003D": {
        "name": "TPM_E_BAD_LOCALITY",
        "explanation": "The locality is incorrect for the attempted operation.",
    },
    "0x8028003E": {"name": "TPM_E_READ_ONLY", "explanation": "The NV area is read-only and cannot be written to."},
    "0x8028003F": {"name": "TPM_E_PER_NOWRITE", "explanation": "There is no protection on the write to the NV area."},
    "0x80280040": {"name": "TPM_E_FAMILYCOUNT", "explanation": "The family count value does not match."},
    "0x80280041": {"name": "TPM_E_WRITE_LOCKED", "explanation": "The NV area has already been written to."},
    "0x80280042": {"name": "TPM_E_BAD_ATTRIBUTES", "explanation": "The NV area attributes conflict."},
    "0x80280043": {
        "name": "TPM_E_INVALID_STRUCTURE",
        "explanation": "The structure tag and version are invalid or inconsistent.",
    },
    "0x80280044": {
        "name": "TPM_E_KEY_OWNER_CONTROL",
        "explanation": "The key is under control of the TPM owner and can only be evicted by the TPM owner.",
    },
    "0x80280045": {"name": "TPM_E_BAD_COUNTER", "explanation": "The counter handle is incorrect."},
    "0x80280046": {"name": "TPM_E_NOT_FULLWRITE", "explanation": "The write is not a complete write of the area."},
    "0x80280047": {"name": "TPM_E_CONTEXT_GAP", "explanation": "The gap between saved context counts is too large."},
    "0x80280048": {
        "name": "TPM_E_MAXNVWRITES",
        "explanation": "The maximum number of NV writes without an owner has been exceeded.",
    },
    "0x80280049": {"name": "TPM_E_NOOPERATOR", "explanation": "No operator AuthData value is set."},
    "0x8028004A": {"name": "TPM_E_RESOURCEMISSING", "explanation": "The resource pointed to by context is not loaded."},
    "0x8028004B": {"name": "TPM_E_DELEGATE_LOCK", "explanation": "The delegate administration is locked."},
    "0x8028004C": {
        "name": "TPM_E_DELEGATE_FAMILY",
        "explanation": "Attempt to manage a family other then the delegated family.",
    },
    "0x8028004D": {"name": "TPM_E_DELEGATE_ADMIN", "explanation": "Delegation table management not enabled."},
    "0x8028004E": {
        "name": "TPM_E_TRANSPORT_NOTEXCLUSIVE",
        "explanation": "There was a command executed outside an exclusive transport session.",
    },
    "0x8028004F": {
        "name": "TPM_E_OWNER_CONTROL",
        "explanation": "Attempt to context save an owner evict controlled key.",
    },
    "0x80280050": {
        "name": "TPM_E_DAA_RESOURCES",
        "explanation": "The DAA command has no resources available to execute the command.",
    },
    "0x80280051": {
        "name": "TPM_E_DAA_INPUT_DATA0",
        "explanation": "The consistency check on DAA parameter inputData0 has failed.",
    },
    "0x80280052": {
        "name": "TPM_E_DAA_INPUT_DATA1",
        "explanation": "The consistency check on DAA parameter inputData1 has failed.",
    },
    "0x80280053": {
        "name": "TPM_E_DAA_ISSUER_SETTINGS",
        "explanation": "The consistency check on DAA_issuerSettings has failed.",
    },
    "0x80280054": {
        "name": "TPM_E_DAA_TPM_SETTINGS",
        "explanation": "The consistency check on DAA_tpmSpecific has failed.",
    },
    "0x80280055": {
        "name": "TPM_E_DAA_STAGE",
        "explanation": "The atomic process indicated by the submitted DAA command is not the expected process.",
    },
    "0x80280056": {
        "name": "TPM_E_DAA_ISSUER_VALIDITY",
        "explanation": "The issuer's validity check has detected an inconsistency.",
    },
    "0x80280057": {"name": "TPM_E_DAA_WRONG_W", "explanation": "The consistency check on w has failed."},
    "0x80280058": {"name": "TPM_E_BAD_HANDLE", "explanation": "The handle is incorrect."},
    "0x80280059": {"name": "TPM_E_BAD_DELEGATE", "explanation": "Delegation is not correct."},
    "0x8028005A": {"name": "TPM_E_BADCONTEXT", "explanation": "The context blob is invalid."},
    "0x8028005B": {"name": "TPM_E_TOOMANYCONTEXTS", "explanation": "Too many contexts held by the TPM."},
    "0x8028005C": {
        "name": "TPM_E_MA_TICKET_SIGNATURE",
        "explanation": "Migration authority signature validation failure.",
    },
    "0x8028005D": {"name": "TPM_E_MA_DESTINATION", "explanation": "Migration destination not authenticated."},
    "0x8028005E": {"name": "TPM_E_MA_SOURCE", "explanation": "Migration source incorrect."},
    "0x8028005F": {"name": "TPM_E_MA_AUTHORITY", "explanation": "Incorrect migration authority."},
    "0x80280061": {"name": "TPM_E_PERMANENTEK", "explanation": "Attempt to revoke the EK and the EK is not revocable."},
    "0x80280062": {"name": "TPM_E_BAD_SIGNATURE", "explanation": "Bad signature of CMK ticket."},
    "0x80280063": {
        "name": "TPM_E_NOCONTEXTSPACE",
        "explanation": "There is no room in the context list for additional contexts.",
    },
    "0x80280400": {"name": "TPM_E_COMMAND_BLOCKED", "explanation": "The command was blocked."},
    "0x80280401": {"name": "TPM_E_INVALID_HANDLE", "explanation": "The specified handle was not found."},
    "0x80280402": {
        "name": "TPM_E_DUPLICATE_VHANDLE",
        "explanation": "The TPM returned a duplicate handle and the command needs to be resubmitted.",
    },
    "0x80280403": {
        "name": "TPM_E_EMBEDDED_COMMAND_BLOCKED",
        "explanation": "The command within the transport was blocked.",
    },
    "0x80280404": {
        "name": "TPM_E_EMBEDDED_COMMAND_UNSUPPORTED",
        "explanation": "The command within the transport is not supported.",
    },
    "0x80280800": {
        "name": "TPM_E_RETRY",
        "explanation": "The TPM is too busy to respond to the command immediately, but the command could be resubmitted at a later time.",
    },
    "0x80280801": {"name": "TPM_E_NEEDS_SELFTEST", "explanation": "SelfTestFull has not been run."},
    "0x80280802": {"name": "TPM_E_DOING_SELFTEST", "explanation": "The TPM is currently executing a full self-test."},
    "0x80280803": {
        "name": "TPM_E_DEFEND_LOCK_RUNNING",
        "explanation": "The TPM is defending against dictionary attacks and is in a time-out period.",
    },
    "0x80284001": {"name": "TBS_E_INTERNAL_ERROR", "explanation": "An internal software error has been detected."},
    "0x80284002": {"name": "TBS_E_BAD_PARAMETER", "explanation": "One or more input parameters are bad."},
    "0x80284003": {"name": "TBS_E_INVALID_OUTPUT_POINTER", "explanation": "A specified output pointer is bad."},
    "0x80284004": {
        "name": "TBS_E_INVALID_CONTEXT",
        "explanation": "The specified context handle does not refer to a valid context.",
    },
    "0x80284005": {"name": "TBS_E_INSUFFICIENT_BUFFER", "explanation": "A specified output buffer is too small."},
    "0x80284006": {"name": "TBS_E_IOERROR", "explanation": "An error occurred while communicating with the TPM."},
    "0x80284007": {"name": "TBS_E_INVALID_CONTEXT_PARAM", "explanation": "One or more context parameters are invalid."},
    "0x80284008": {
        "name": "TBS_E_SERVICE_NOT_RUNNING",
        "explanation": "The TPM Base Services (TBS) is not running and could not be started.",
    },
    "0x80284009": {
        "name": "TBS_E_TOO_MANY_TBS_CONTEXTS",
        "explanation": "A new context could not be created because there are too many open contexts.",
    },
    "0x8028400A": {
        "name": "TBS_E_TOO_MANY_RESOURCES",
        "explanation": "A new virtual resource could not be created because there are too many open virtual resources.",
    },
    "0x8028400B": {
        "name": "TBS_E_SERVICE_START_PENDING",
        "explanation": "The TBS service has been started but is not yet running.",
    },
    "0x8028400C": {
        "name": "TBS_E_PPI_NOT_SUPPORTED",
        "explanation": "The physical presence interface is not supported.",
    },
    "0x8028400D": {"name": "TBS_E_COMMAND_CANCELED", "explanation": "The command was canceled."},
    "0x8028400E": {"name": "TBS_E_BUFFER_TOO_LARGE", "explanation": "The input or output buffer is too large."},
    "0x80290100": {"name": "TPMAPI_E_INVALID_STATE", "explanation": "The command buffer is not in the correct state."},
    "0x80290101": {
        "name": "TPMAPI_E_NOT_ENOUGH_DATA",
        "explanation": "The command buffer does not contain enough data to satisfy the request.",
    },
    "0x80290102": {"name": "TPMAPI_E_TOO_MUCH_DATA", "explanation": "The command buffer cannot contain any more data."},
    "0x80290103": {
        "name": "TPMAPI_E_INVALID_OUTPUT_POINTER",
        "explanation": "One or more output parameters was null or invalid.",
    },
    "0x80290104": {"name": "TPMAPI_E_INVALID_PARAMETER", "explanation": "One or more input parameters are invalid."},
    "0x80290105": {
        "name": "TPMAPI_E_OUT_OF_MEMORY",
        "explanation": "Not enough memory was available to satisfy the request.",
    },
    "0x80290106": {"name": "TPMAPI_E_BUFFER_TOO_SMALL", "explanation": "The specified buffer was too small."},
    "0x80290107": {"name": "TPMAPI_E_INTERNAL_ERROR", "explanation": "An internal error was detected."},
    "0x80290108": {
        "name": "TPMAPI_E_ACCESS_DENIED",
        "explanation": "The caller does not have the appropriate rights to perform the requested operation.",
    },
    "0x80290109": {
        "name": "TPMAPI_E_AUTHORIZATION_FAILED",
        "explanation": "The specified authorization information was invalid.",
    },
    "0x8029010A": {
        "name": "TPMAPI_E_INVALID_CONTEXT_HANDLE",
        "explanation": "The specified context handle was not valid.",
    },
    "0x8029010B": {
        "name": "TPMAPI_E_TBS_COMMUNICATION_ERROR",
        "explanation": "An error occurred while communicating with the TBS.",
    },
    "0x8029010C": {"name": "TPMAPI_E_TPM_COMMAND_ERROR", "explanation": "The TPM returned an unexpected result."},
    "0x8029010D": {
        "name": "TPMAPI_E_MESSAGE_TOO_LARGE",
        "explanation": "The message was too large for the encoding scheme.",
    },
    "0x8029010E": {
        "name": "TPMAPI_E_INVALID_ENCODING",
        "explanation": "The encoding in the binary large object (BLOB) was not recognized.",
    },
    "0x8029010F": {"name": "TPMAPI_E_INVALID_KEY_SIZE", "explanation": "The key size is not valid."},
    "0x80290110": {"name": "TPMAPI_E_ENCRYPTION_FAILED", "explanation": "The encryption operation failed."},
    "0x80290111": {"name": "TPMAPI_E_INVALID_KEY_PARAMS", "explanation": "The key parameters structure was not valid."},
    "0x80290112": {
        "name": "TPMAPI_E_INVALID_MIGRATION_AUTHORIZATION_BLOB",
        "explanation": "The requested supplied data does not appear to be a valid migration authorization BLOB.",
    },
    "0x80290113": {"name": "TPMAPI_E_INVALID_PCR_INDEX", "explanation": "The specified PCR index was invalid."},
    "0x80290114": {
        "name": "TPMAPI_E_INVALID_DELEGATE_BLOB",
        "explanation": "The data given does not appear to be a valid delegate BLOB.",
    },
    "0x80290115": {
        "name": "TPMAPI_E_INVALID_CONTEXT_PARAMS",
        "explanation": "One or more of the specified context parameters was not valid.",
    },
    "0x80290116": {
        "name": "TPMAPI_E_INVALID_KEY_BLOB",
        "explanation": "The data given does not appear to be a valid key BLOB.",
    },
    "0x80290117": {"name": "TPMAPI_E_INVALID_PCR_DATA", "explanation": "The specified PCR data was invalid."},
    "0x80290118": {
        "name": "TPMAPI_E_INVALID_OWNER_AUTH",
        "explanation": "The format of the owner authorization data was invalid.",
    },
    "0x80290200": {"name": "TBSIMP_E_BUFFER_TOO_SMALL", "explanation": "The specified buffer was too small."},
    "0x80290201": {"name": "TBSIMP_E_CLEANUP_FAILED", "explanation": "The context could not be cleaned up."},
    "0x80290202": {
        "name": "TBSIMP_E_INVALID_CONTEXT_HANDLE",
        "explanation": "The specified context handle is invalid.",
    },
    "0x80290203": {
        "name": "TBSIMP_E_INVALID_CONTEXT_PARAM",
        "explanation": "An invalid context parameter was specified.",
    },
    "0x80290204": {"name": "TBSIMP_E_TPM_ERROR", "explanation": "An error occurred while communicating with the TPM."},
    "0x80290205": {"name": "TBSIMP_E_HASH_BAD_KEY", "explanation": "No entry with the specified key was found."},
    "0x80290206": {
        "name": "TBSIMP_E_DUPLICATE_VHANDLE",
        "explanation": "The specified virtual handle matches a virtual handle already in use.",
    },
    "0x80290207": {
        "name": "TBSIMP_E_INVALID_OUTPUT_POINTER",
        "explanation": "The pointer to the returned handle location was null or invalid.",
    },
    "0x80290208": {"name": "TBSIMP_E_INVALID_PARAMETER", "explanation": "One or more parameters are invalid."},
    "0x80290209": {"name": "TBSIMP_E_RPC_INIT_FAILED", "explanation": "The RPC subsystem could not be initialized."},
    "0x8029020A": {"name": "TBSIMP_E_SCHEDULER_NOT_RUNNING", "explanation": "The TBS scheduler is not running."},
    "0x8029020B": {"name": "TBSIMP_E_COMMAND_CANCELED", "explanation": "The command was canceled."},
    "0x8029020C": {
        "name": "TBSIMP_E_OUT_OF_MEMORY",
        "explanation": "There was not enough memory to fulfill the request.",
    },
    "0x8029020D": {
        "name": "TBSIMP_E_LIST_NO_MORE_ITEMS",
        "explanation": "The specified list is empty, or the iteration has reached the end of the list.",
    },
    "0x8029020E": {"name": "TBSIMP_E_LIST_NOT_FOUND", "explanation": "The specified item was not found in the list."},
    "0x8029020F": {
        "name": "TBSIMP_E_NOT_ENOUGH_SPACE",
        "explanation": "The TPM does not have enough space to load the requested resource.",
    },
    "0x80290210": {
        "name": "TBSIMP_E_NOT_ENOUGH_TPM_CONTEXTS",
        "explanation": "There are too many TPM contexts in use.",
    },
    "0x80290211": {"name": "TBSIMP_E_COMMAND_FAILED", "explanation": "The TPM command failed."},
    "0x80290212": {
        "name": "TBSIMP_E_UNKNOWN_ORDINAL",
        "explanation": "The TBS does not recognize the specified ordinal.",
    },
    "0x80290213": {
        "name": "TBSIMP_E_RESOURCE_EXPIRED",
        "explanation": "The requested resource is no longer available.",
    },
    "0x80290214": {"name": "TBSIMP_E_INVALID_RESOURCE", "explanation": "The resource type did not match."},
    "0x80290215": {"name": "TBSIMP_E_NOTHING_TO_UNLOAD", "explanation": "No resources can be unloaded."},
    "0x80290216": {"name": "TBSIMP_E_HASH_TABLE_FULL", "explanation": "No new entries can be added to the hash table."},
    "0x80290217": {
        "name": "TBSIMP_E_TOO_MANY_TBS_CONTEXTS",
        "explanation": "A new TBS context could not be created because there are too many open contexts.",
    },
    "0x80290218": {
        "name": "TBSIMP_E_TOO_MANY_RESOURCES",
        "explanation": "A new virtual resource could not be created because there are too many open virtual resources.",
    },
    "0x80290219": {
        "name": "TBSIMP_E_PPI_NOT_SUPPORTED",
        "explanation": "The physical presence interface is not supported.",
    },
    "0x8029021A": {
        "name": "TBSIMP_E_TPM_INCOMPATIBLE",
        "explanation": "TBS is not compatible with the version of TPM found on the system.",
    },
    "0x80290300": {
        "name": "TPM_E_PPI_ACPI_FAILURE",
        "explanation": "A general error was detected when attempting to acquire the BIOS response to a physical presence command.",
    },
    "0x80290301": {
        "name": "TPM_E_PPI_USER_ABORT",
        "explanation": "The user failed to confirm the TPM operation request.",
    },
    "0x80290302": {
        "name": "TPM_E_PPI_BIOS_FAILURE",
        "explanation": "The BIOS failure prevented the successful execution of the requested TPM operation (for example, invalid TPM operation request, BIOS communication error with the TPM).",
    },
    "0x80290303": {
        "name": "TPM_E_PPI_NOT_SUPPORTED",
        "explanation": "The BIOS does not support the physical presence interface.",
    },
    "0x80300002": {"name": "PLA_E_DCS_NOT_FOUND", "explanation": "A Data Collector Set was not found."},
    "0x80300045": {
        "name": "PLA_E_TOO_MANY_FOLDERS",
        "explanation": "Unable to start Data Collector Set because there are too many folders.",
    },
    "0x80300070": {
        "name": "PLA_E_NO_MIN_DISK",
        "explanation": "Not enough free disk space to start Data Collector Set.",
    },
    "0x803000AA": {"name": "PLA_E_DCS_IN_USE", "explanation": "Data Collector Set is in use."},
    "0x803000B7": {"name": "PLA_E_DCS_ALREADY_EXISTS", "explanation": "Data Collector Set already exists."},
    "0x80300101": {"name": "PLA_E_PROPERTY_CONFLICT", "explanation": "Property value conflict."},
    "0x80300102": {
        "name": "PLA_E_DCS_SINGLETON_REQUIRED",
        "explanation": "The current configuration for this Data Collector Set requires that it contain exactly one Data Collector.",
    },
    "0x80300103": {
        "name": "PLA_E_CREDENTIALS_REQUIRED",
        "explanation": "A user account is required to commit the current Data Collector Set properties.",
    },
    "0x80300104": {"name": "PLA_E_DCS_NOT_RUNNING", "explanation": "Data Collector Set is not running."},
    "0x80300105": {
        "name": "PLA_E_CONFLICT_INCL_EXCL_API",
        "explanation": "A conflict was detected in the list of include and exclude APIs. Do not specify the same API in both the include list and the exclude list.",
    },
    "0x80300106": {
        "name": "PLA_E_NETWORK_EXE_NOT_VALID",
        "explanation": "The executable path specified refers to a network share or UNC path.",
    },
    "0x80300107": {
        "name": "PLA_E_EXE_ALREADY_CONFIGURED",
        "explanation": "The executable path specified is already configured for API tracing.",
    },
    "0x80300108": {
        "name": "PLA_E_EXE_PATH_NOT_VALID",
        "explanation": "The executable path specified does not exist. Verify that the specified path is correct.",
    },
    "0x80300109": {"name": "PLA_E_DC_ALREADY_EXISTS", "explanation": "Data Collector already exists."},
    "0x8030010A": {
        "name": "PLA_E_DCS_START_WAIT_TIMEOUT",
        "explanation": "The wait for the Data Collector Set start notification has timed out.",
    },
    "0x8030010B": {
        "name": "PLA_E_DC_START_WAIT_TIMEOUT",
        "explanation": "The wait for the Data Collector to start has timed out.",
    },
    "0x8030010C": {
        "name": "PLA_E_REPORT_WAIT_TIMEOUT",
        "explanation": "The wait for the report generation tool to finish has timed out.",
    },
    "0x8030010D": {"name": "PLA_E_NO_DUPLICATES", "explanation": "Duplicate items are not allowed."},
    "0x8030010E": {
        "name": "PLA_E_EXE_FULL_PATH_REQUIRED",
        "explanation": "When specifying the executable to trace, you must specify a full path to the executable and not just a file name.",
    },
    "0x8030010F": {"name": "PLA_E_INVALID_SESSION_NAME", "explanation": "The session name provided is invalid."},
    "0x80300110": {
        "name": "PLA_E_PLA_CHANNEL_NOT_ENABLED",
        "explanation": "The Event Log channel Microsoft-Windows-Diagnosis-PLA/Operational must be enabled to perform this operation.",
    },
    "0x80300111": {
        "name": "PLA_E_TASKSCHED_CHANNEL_NOT_ENABLED",
        "explanation": "The Event Log channel Microsoft-Windows-TaskScheduler must be enabled to perform this operation.",
    },
    "0x80310000": {"name": "FVE_E_LOCKED_VOLUME", "explanation": "The volume must be unlocked before it can be used."},
    "0x80310001": {
        "name": "FVE_E_NOT_ENCRYPTED",
        "explanation": "The volume is fully decrypted and no key is available.",
    },
    "0x80310002": {
        "name": "FVE_E_NO_TPM_BIOS",
        "explanation": "The firmware does not support using a TPM during boot.",
    },
    "0x80310003": {
        "name": "FVE_E_NO_MBR_METRIC",
        "explanation": "The firmware does not use a TPM to perform initial program load (IPL) measurement.",
    },
    "0x80310004": {
        "name": "FVE_E_NO_BOOTSECTOR_METRIC",
        "explanation": "The master boot record (MBR) is not TPM-aware.",
    },
    "0x80310005": {"name": "FVE_E_NO_BOOTMGR_METRIC", "explanation": "The BOOTMGR is not being measured by the TPM."},
    "0x80310006": {
        "name": "FVE_E_WRONG_BOOTMGR",
        "explanation": "The BOOTMGR component does not perform expected TPM measurements.",
    },
    "0x80310007": {
        "name": "FVE_E_SECURE_KEY_REQUIRED",
        "explanation": "No secure key protection mechanism has been defined.",
    },
    "0x80310008": {
        "name": "FVE_E_NOT_ACTIVATED",
        "explanation": "This volume has not been provisioned for encryption.",
    },
    "0x80310009": {
        "name": "FVE_E_ACTION_NOT_ALLOWED",
        "explanation": "Requested action was denied by the full-volume encryption (FVE) control engine.",
    },
    "0x8031000A": {
        "name": "FVE_E_AD_SCHEMA_NOT_INSTALLED",
        "explanation": "The Active Directory forest does not contain the required attributes and classes to host FVE or TPM information.",
    },
    "0x8031000B": {
        "name": "FVE_E_AD_INVALID_DATATYPE",
        "explanation": "The type of data obtained from Active Directory was not expected.",
    },
    "0x8031000C": {
        "name": "FVE_E_AD_INVALID_DATASIZE",
        "explanation": "The size of the data obtained from Active Directory was not expected.",
    },
    "0x8031000D": {
        "name": "FVE_E_AD_NO_VALUES",
        "explanation": "The attribute read from Active Directory has no (zero) values.",
    },
    "0x8031000E": {"name": "FVE_E_AD_ATTR_NOT_SET", "explanation": "The attribute was not set."},
    "0x8031000F": {"name": "FVE_E_AD_GUID_NOT_FOUND", "explanation": "The specified GUID could not be found."},
    "0x80310010": {
        "name": "FVE_E_BAD_INFORMATION",
        "explanation": "The control block for the encrypted volume is not valid.",
    },
    "0x80310011": {
        "name": "FVE_E_TOO_SMALL",
        "explanation": "Not enough free space remaining on volume to allow encryption.",
    },
    "0x80310012": {
        "name": "FVE_E_SYSTEM_VOLUME",
        "explanation": "The volume cannot be encrypted because it is required to boot the operating system.",
    },
    "0x80310013": {
        "name": "FVE_E_FAILED_WRONG_FS",
        "explanation": "The volume cannot be encrypted because the file system is not supported.",
    },
    "0x80310014": {"name": "FVE_E_FAILED_BAD_FS", "explanation": "The file system is inconsistent. Run CHKDSK."},
    "0x80310015": {"name": "FVE_E_NOT_SUPPORTED", "explanation": "This volume cannot be encrypted."},
    "0x80310016": {"name": "FVE_E_BAD_DATA", "explanation": "Data supplied is malformed."},
    "0x80310017": {"name": "FVE_E_VOLUME_NOT_BOUND", "explanation": "Volume is not bound to the system."},
    "0x80310018": {
        "name": "FVE_E_TPM_NOT_OWNED",
        "explanation": "TPM must be owned before a volume can be bound to it.",
    },
    "0x80310019": {"name": "FVE_E_NOT_DATA_VOLUME", "explanation": "The volume specified is not a data volume."},
    "0x8031001A": {
        "name": "FVE_E_AD_INSUFFICIENT_BUFFER",
        "explanation": "The buffer supplied to a function was insufficient to contain the returned data.",
    },
    "0x8031001B": {"name": "FVE_E_CONV_READ", "explanation": "A read operation failed while converting the volume."},
    "0x8031001C": {"name": "FVE_E_CONV_WRITE", "explanation": "A write operation failed while converting the volume."},
    "0x8031001D": {
        "name": "FVE_E_KEY_REQUIRED",
        "explanation": "One or more key protection mechanisms are required for this volume.",
    },
    "0x8031001E": {
        "name": "FVE_E_CLUSTERING_NOT_SUPPORTED",
        "explanation": "Cluster configurations are not supported.",
    },
    "0x8031001F": {"name": "FVE_E_VOLUME_BOUND_ALREADY", "explanation": "The volume is already bound to the system."},
    "0x80310020": {
        "name": "FVE_E_OS_NOT_PROTECTED",
        "explanation": "The boot OS volume is not being protected via FVE.",
    },
    "0x80310021": {
        "name": "FVE_E_PROTECTION_DISABLED",
        "explanation": "All protection mechanisms are effectively disabled (clear key exists).",
    },
    "0x80310022": {
        "name": "FVE_E_RECOVERY_KEY_REQUIRED",
        "explanation": "A recovery key protection mechanism is required.",
    },
    "0x80310023": {"name": "FVE_E_FOREIGN_VOLUME", "explanation": "This volume cannot be bound to a TPM."},
    "0x80310024": {
        "name": "FVE_E_OVERLAPPED_UPDATE",
        "explanation": "The control block for the encrypted volume was updated by another thread. Try again.",
    },
    "0x80310025": {
        "name": "FVE_E_TPM_SRK_AUTH_NOT_ZERO",
        "explanation": "The SRK authentication of the TPM is not zero and, therefore, is not compatible.",
    },
    "0x80310026": {
        "name": "FVE_E_FAILED_SECTOR_SIZE",
        "explanation": "The volume encryption algorithm cannot be used on this sector size.",
    },
    "0x80310027": {"name": "FVE_E_FAILED_AUTHENTICATION", "explanation": "BitLocker recovery authentication failed."},
    "0x80310028": {"name": "FVE_E_NOT_OS_VOLUME", "explanation": "The volume specified is not the boot OS volume."},
    "0x80310029": {
        "name": "FVE_E_AUTOUNLOCK_ENABLED",
        "explanation": "Auto-unlock information for data volumes is present on the boot OS volume.",
    },
    "0x8031002A": {
        "name": "FVE_E_WRONG_BOOTSECTOR",
        "explanation": "The system partition boot sector does not perform TPM measurements.",
    },
    "0x8031002B": {"name": "FVE_E_WRONG_SYSTEM_FS", "explanation": "The system partition file system must be NTFS."},
    "0x8031002C": {
        "name": "FVE_E_POLICY_PASSWORD_REQUIRED",
        "explanation": "Group policy requires a recovery password before encryption can begin.",
    },
    "0x8031002D": {
        "name": "FVE_E_CANNOT_SET_FVEK_ENCRYPTED",
        "explanation": "The volume encryption algorithm and key cannot be set on an encrypted volume.",
    },
    "0x8031002E": {
        "name": "FVE_E_CANNOT_ENCRYPT_NO_KEY",
        "explanation": "A key must be specified before encryption can begin.",
    },
    "0x80310030": {
        "name": "FVE_E_BOOTABLE_CDDVD",
        "explanation": "A bootable CD/DVD is in the system. Remove the CD/DVD and reboot the system.",
    },
    "0x80310031": {
        "name": "FVE_E_PROTECTOR_EXISTS",
        "explanation": "An instance of this key protector already exists on the volume.",
    },
    "0x80310032": {"name": "FVE_E_RELATIVE_PATH", "explanation": "The file cannot be saved to a relative path."},
    "0x80320001": {"name": "FWP_E_CALLOUT_NOT_FOUND", "explanation": "The callout does not exist."},
    "0x80320002": {"name": "FWP_E_CONDITION_NOT_FOUND", "explanation": "The filter condition does not exist."},
    "0x80320003": {"name": "FWP_E_FILTER_NOT_FOUND", "explanation": "The filter does not exist."},
    "0x80320004": {"name": "FWP_E_LAYER_NOT_FOUND", "explanation": "The layer does not exist."},
    "0x80320005": {"name": "FWP_E_PROVIDER_NOT_FOUND", "explanation": "The provider does not exist."},
    "0x80320006": {"name": "FWP_E_PROVIDER_CONTEXT_NOT_FOUND", "explanation": "The provider context does not exist."},
    "0x80320007": {"name": "FWP_E_SUBLAYER_NOT_FOUND", "explanation": "The sublayer does not exist."},
    "0x80320008": {"name": "FWP_E_NOT_FOUND", "explanation": "The object does not exist."},
    "0x80320009": {"name": "FWP_E_ALREADY_EXISTS", "explanation": "An object with that GUID or LUID already exists."},
    "0x8032000A": {
        "name": "FWP_E_IN_USE",
        "explanation": "The object is referenced by other objects and, therefore, cannot be deleted.",
    },
    "0x8032000B": {
        "name": "FWP_E_DYNAMIC_SESSION_IN_PROGRESS",
        "explanation": "The call is not allowed from within a dynamic session.",
    },
    "0x8032000C": {
        "name": "FWP_E_WRONG_SESSION",
        "explanation": "The call was made from the wrong session and, therefore, cannot be completed.",
    },
    "0x8032000D": {
        "name": "FWP_E_NO_TXN_IN_PROGRESS",
        "explanation": "The call must be made from within an explicit transaction.",
    },
    "0x8032000E": {
        "name": "FWP_E_TXN_IN_PROGRESS",
        "explanation": "The call is not allowed from within an explicit transaction.",
    },
    "0x8032000F": {"name": "FWP_E_TXN_ABORTED", "explanation": "The explicit transaction has been forcibly canceled."},
    "0x80320010": {"name": "FWP_E_SESSION_ABORTED", "explanation": "The session has been canceled."},
    "0x80320011": {
        "name": "FWP_E_INCOMPATIBLE_TXN",
        "explanation": "The call is not allowed from within a read-only transaction.",
    },
    "0x80320012": {
        "name": "FWP_E_TIMEOUT",
        "explanation": "The call timed out while waiting to acquire the transaction lock.",
    },
    "0x80320013": {
        "name": "FWP_E_NET_EVENTS_DISABLED",
        "explanation": "Collection of network diagnostic events is disabled.",
    },
    "0x80320014": {
        "name": "FWP_E_INCOMPATIBLE_LAYER",
        "explanation": "The operation is not supported by the specified layer.",
    },
    "0x80320015": {"name": "FWP_E_KM_CLIENTS_ONLY", "explanation": "The call is allowed for kernel-mode callers only."},
    "0x80320016": {
        "name": "FWP_E_LIFETIME_MISMATCH",
        "explanation": "The call tried to associate two objects with incompatible lifetimes.",
    },
    "0x80320017": {
        "name": "FWP_E_BUILTIN_OBJECT",
        "explanation": "The object is built in and, therefore, cannot be deleted.",
    },
    "0x80320018": {
        "name": "FWP_E_TOO_MANY_BOOTTIME_FILTERS",
        "explanation": "The maximum number of boot-time filters has been reached.",
    },
    "0x80320019": {
        "name": "FWP_E_NOTIFICATION_DROPPED",
        "explanation": "A notification could not be delivered because a message queue is at its maximum capacity.",
    },
    "0x8032001A": {
        "name": "FWP_E_TRAFFIC_MISMATCH",
        "explanation": "The traffic parameters do not match those for the security association context.",
    },
    "0x8032001B": {
        "name": "FWP_E_INCOMPATIBLE_SA_STATE",
        "explanation": "The call is not allowed for the current security association state.",
    },
    "0x8032001C": {"name": "FWP_E_NULL_POINTER", "explanation": "A required pointer is null."},
    "0x8032001D": {"name": "FWP_E_INVALID_ENUMERATOR", "explanation": "An enumerator is not valid."},
    "0x8032001E": {"name": "FWP_E_INVALID_FLAGS", "explanation": "The flags field contains an invalid value."},
    "0x8032001F": {"name": "FWP_E_INVALID_NET_MASK", "explanation": "A network mask is not valid."},
    "0x80320020": {"name": "FWP_E_INVALID_RANGE", "explanation": "An FWP_RANGE is not valid."},
    "0x80320021": {"name": "FWP_E_INVALID_INTERVAL", "explanation": "The time interval is not valid."},
    "0x80320022": {
        "name": "FWP_E_ZERO_LENGTH_ARRAY",
        "explanation": "An array that must contain at least one element that is zero-length.",
    },
    "0x80320023": {"name": "FWP_E_NULL_DISPLAY_NAME", "explanation": "The displayData.name field cannot be null."},
    "0x80320024": {
        "name": "FWP_E_INVALID_ACTION_TYPE",
        "explanation": "The action type is not one of the allowed action types for a filter.",
    },
    "0x80320025": {"name": "FWP_E_INVALID_WEIGHT", "explanation": "The filter weight is not valid."},
    "0x80320026": {
        "name": "FWP_E_MATCH_TYPE_MISMATCH",
        "explanation": "A filter condition contains a match type that is not compatible with the operands.",
    },
    "0x80320027": {
        "name": "FWP_E_TYPE_MISMATCH",
        "explanation": "An FWP_VALUE or FWPM_CONDITION_VALUE is of the wrong type.",
    },
    "0x80320028": {"name": "FWP_E_OUT_OF_BOUNDS", "explanation": "An integer value is outside the allowed range."},
    "0x80320029": {"name": "FWP_E_RESERVED", "explanation": "A reserved field is nonzero."},
    "0x8032002A": {
        "name": "FWP_E_DUPLICATE_CONDITION",
        "explanation": "A filter cannot contain multiple conditions operating on a single field.",
    },
    "0x8032002B": {
        "name": "FWP_E_DUPLICATE_KEYMOD",
        "explanation": "A policy cannot contain the same keying module more than once.",
    },
    "0x8032002C": {
        "name": "FWP_E_ACTION_INCOMPATIBLE_WITH_LAYER",
        "explanation": "The action type is not compatible with the layer.",
    },
    "0x8032002D": {
        "name": "FWP_E_ACTION_INCOMPATIBLE_WITH_SUBLAYER",
        "explanation": "The action type is not compatible with the sublayer.",
    },
    "0x8032002E": {
        "name": "FWP_E_CONTEXT_INCOMPATIBLE_WITH_LAYER",
        "explanation": "The raw context or the provider context is not compatible with the layer.",
    },
    "0x8032002F": {
        "name": "FWP_E_CONTEXT_INCOMPATIBLE_WITH_CALLOUT",
        "explanation": "The raw context or the provider context is not compatible with the callout.",
    },
    "0x80320030": {
        "name": "FWP_E_INCOMPATIBLE_AUTH_METHOD",
        "explanation": "The authentication method is not compatible with the policy type.",
    },
    "0x80320031": {
        "name": "FWP_E_INCOMPATIBLE_DH_GROUP",
        "explanation": "The Diffie-Hellman group is not compatible with the policy type.",
    },
    "0x80320032": {
        "name": "FWP_E_EM_NOT_SUPPORTED",
        "explanation": "An Internet Key Exchange (IKE) policy cannot contain an Extended Mode policy.",
    },
    "0x80320033": {
        "name": "FWP_E_NEVER_MATCH",
        "explanation": "The enumeration template or subscription will never match any objects.",
    },
    "0x80320034": {
        "name": "FWP_E_PROVIDER_CONTEXT_MISMATCH",
        "explanation": "The provider context is of the wrong type.",
    },
    "0x80320035": {"name": "FWP_E_INVALID_PARAMETER", "explanation": "The parameter is incorrect."},
    "0x80320036": {
        "name": "FWP_E_TOO_MANY_SUBLAYERS",
        "explanation": "The maximum number of sublayers has been reached.",
    },
    "0x80320037": {
        "name": "FWP_E_CALLOUT_NOTIFICATION_FAILED",
        "explanation": "The notification function for a callout returned an error.",
    },
    "0x80320038": {
        "name": "FWP_E_INCOMPATIBLE_AUTH_CONFIG",
        "explanation": "The IPsec authentication configuration is not compatible with the authentication type.",
    },
    "0x80320039": {
        "name": "FWP_E_INCOMPATIBLE_CIPHER_CONFIG",
        "explanation": "The IPsec cipher configuration is not compatible with the cipher type.",
    },
    "0x80340002": {
        "name": "ERROR_NDIS_INTERFACE_CLOSING",
        "explanation": "The binding to the network interface is being closed.",
    },
    "0x80340004": {"name": "ERROR_NDIS_BAD_VERSION", "explanation": "An invalid version was specified."},
    "0x80340005": {
        "name": "ERROR_NDIS_BAD_CHARACTERISTICS",
        "explanation": "An invalid characteristics table was used.",
    },
    "0x80340006": {
        "name": "ERROR_NDIS_ADAPTER_NOT_FOUND",
        "explanation": "Failed to find the network interface, or the network interface is not ready.",
    },
    "0x80340007": {"name": "ERROR_NDIS_OPEN_FAILED", "explanation": "Failed to open the network interface."},
    "0x80340008": {
        "name": "ERROR_NDIS_DEVICE_FAILED",
        "explanation": "The network interface has encountered an internal unrecoverable failure.",
    },
    "0x80340009": {
        "name": "ERROR_NDIS_MULTICAST_FULL",
        "explanation": "The multicast list on the network interface is full.",
    },
    "0x8034000A": {
        "name": "ERROR_NDIS_MULTICAST_EXISTS",
        "explanation": "An attempt was made to add a duplicate multicast address to the list.",
    },
    "0x8034000B": {
        "name": "ERROR_NDIS_MULTICAST_NOT_FOUND",
        "explanation": "At attempt was made to remove a multicast address that was never added.",
    },
    "0x8034000C": {"name": "ERROR_NDIS_REQUEST_ABORTED", "explanation": "The network interface aborted the request."},
    "0x8034000D": {
        "name": "ERROR_NDIS_RESET_IN_PROGRESS",
        "explanation": "The network interface cannot process the request because it is being reset.",
    },
    "0x8034000F": {
        "name": "ERROR_NDIS_INVALID_PACKET",
        "explanation": "An attempt was made to send an invalid packet on a network interface.",
    },
    "0x80340010": {
        "name": "ERROR_NDIS_INVALID_DEVICE_REQUEST",
        "explanation": "The specified request is not a valid operation for the target device.",
    },
    "0x80340011": {
        "name": "ERROR_NDIS_ADAPTER_NOT_READY",
        "explanation": "The network interface is not ready to complete this operation.",
    },
    "0x80340014": {
        "name": "ERROR_NDIS_INVALID_LENGTH",
        "explanation": "The length of the buffer submitted for this operation is not valid.",
    },
    "0x80340015": {"name": "ERROR_NDIS_INVALID_DATA", "explanation": "The data used for this operation is not valid."},
    "0x80340016": {
        "name": "ERROR_NDIS_BUFFER_TOO_SHORT",
        "explanation": "The length of the buffer submitted for this operation is too small.",
    },
    "0x80340017": {"name": "ERROR_NDIS_INVALID_OID", "explanation": "The network interface does not support this OID."},
    "0x80340018": {"name": "ERROR_NDIS_ADAPTER_REMOVED", "explanation": "The network interface has been removed."},
    "0x80340019": {
        "name": "ERROR_NDIS_UNSUPPORTED_MEDIA",
        "explanation": "The network interface does not support this media type.",
    },
    "0x8034001A": {
        "name": "ERROR_NDIS_GROUP_ADDRESS_IN_USE",
        "explanation": "An attempt was made to remove a token ring group address that is in use by other components.",
    },
    "0x8034001B": {
        "name": "ERROR_NDIS_FILE_NOT_FOUND",
        "explanation": "An attempt was made to map a file that cannot be found.",
    },
    "0x8034001C": {
        "name": "ERROR_NDIS_ERROR_READING_FILE",
        "explanation": "An error occurred while the NDIS tried to map the file.",
    },
    "0x8034001D": {
        "name": "ERROR_NDIS_ALREADY_MAPPED",
        "explanation": "An attempt was made to map a file that is already mapped.",
    },
    "0x8034001E": {
        "name": "ERROR_NDIS_RESOURCE_CONFLICT",
        "explanation": "An attempt to allocate a hardware resource failed because the resource is used by another component.",
    },
    "0x8034001F": {
        "name": "ERROR_NDIS_MEDIA_DISCONNECTED",
        "explanation": "The I/O operation failed because network media is disconnected or the wireless access point is out of range.",
    },
    "0x80340022": {
        "name": "ERROR_NDIS_INVALID_ADDRESS",
        "explanation": "The network address used in the request is invalid.",
    },
    "0x8034002A": {
        "name": "ERROR_NDIS_PAUSED",
        "explanation": "The offload operation on the network interface has been paused.",
    },
    "0x8034002B": {"name": "ERROR_NDIS_INTERFACE_NOT_FOUND", "explanation": "The network interface was not found."},
    "0x8034002C": {
        "name": "ERROR_NDIS_UNSUPPORTED_REVISION",
        "explanation": "The revision number specified in the structure is not supported.",
    },
    "0x8034002D": {
        "name": "ERROR_NDIS_INVALID_PORT",
        "explanation": "The specified port does not exist on this network interface.",
    },
    "0x8034002E": {
        "name": "ERROR_NDIS_INVALID_PORT_STATE",
        "explanation": "The current state of the specified port on this network interface does not support the requested operation.",
    },
    "0x803400BB": {
        "name": "ERROR_NDIS_NOT_SUPPORTED",
        "explanation": "The network interface does not support this request.",
    },
    "0x80342000": {
        "name": "ERROR_NDIS_DOT11_AUTO_CONFIG_ENABLED",
        "explanation": "The wireless local area network (LAN) interface is in auto-configuration mode and does not support the requested parameter change operation.",
    },
    "0x80342001": {
        "name": "ERROR_NDIS_DOT11_MEDIA_IN_USE",
        "explanation": "The wireless LAN interface is busy and cannot perform the requested operation.",
    },
    "0x80342002": {
        "name": "ERROR_NDIS_DOT11_POWER_STATE_INVALID",
        "explanation": "The wireless LAN interface is shutting down and does not support the requested operation.",
    },
    "0x8DEAD01B": {"name": "TRK_E_NOT_FOUND", "explanation": "A requested object was not found."},
    "0x8DEAD01C": {
        "name": "TRK_E_VOLUME_QUOTA_EXCEEDED",
        "explanation": "The server received a CREATE_VOLUME subrequest of a SYNC_VOLUMES request, but the ServerVolumeTable size limit for the RequestMachine has already been reached.",
    },
    "0x8DEAD01E": {
        "name": "TRK_SERVER_TOO_BUSY",
        "explanation": "The server is busy, and the client should retry the request at a later time.",
    },
    "0xC0090001": {
        "name": "ERROR_AUDITING_DISABLED",
        "explanation": "The specified event is currently not being audited.",
    },
    "0xC0090002": {"name": "ERROR_ALL_SIDS_FILTERED", "explanation": "The SID filtering operation removed all SIDs."},
    "0xC0090003": {
        "name": "ERROR_BIZRULES_NOT_ENABLED",
        "explanation": "Business rule scripts are disabled for the calling application.",
    },
    "0xC00D0005": {
        "name": "NS_E_NOCONNECTION",
        "explanation": "There is no connection established with the Windows Media server. The operation failed.",
    },
    "0xC00D0006": {"name": "NS_E_CANNOTCONNECT", "explanation": "Unable to establish a connection to the server."},
    "0xC00D0007": {"name": "NS_E_CANNOTDESTROYTITLE", "explanation": "Unable to destroy the title."},
    "0xC00D0008": {"name": "NS_E_CANNOTRENAMETITLE", "explanation": "Unable to rename the title."},
    "0xC00D0009": {"name": "NS_E_CANNOTOFFLINEDISK", "explanation": "Unable to offline disk."},
    "0xC00D000A": {"name": "NS_E_CANNOTONLINEDISK", "explanation": "Unable to online disk."},
    "0xC00D000B": {
        "name": "NS_E_NOREGISTEREDWALKER",
        "explanation": "There is no file parser registered for this type of file.",
    },
    "0xC00D000C": {"name": "NS_E_NOFUNNEL", "explanation": "There is no data connection established."},
    "0xC00D000D": {"name": "NS_E_NO_LOCALPLAY", "explanation": "Failed to load the local play DLL."},
    "0xC00D000E": {"name": "NS_E_NETWORK_BUSY", "explanation": "The network is busy."},
    "0xC00D000F": {"name": "NS_E_TOO_MANY_SESS", "explanation": "The server session limit was exceeded."},
    "0xC00D0010": {"name": "NS_E_ALREADY_CONNECTED", "explanation": "The network connection already exists."},
    "0xC00D0011": {"name": "NS_E_INVALID_INDEX", "explanation": "Index %1 is invalid."},
    "0xC00D0012": {
        "name": "NS_E_PROTOCOL_MISMATCH",
        "explanation": "There is no protocol or protocol version supported by both the client and the server.",
    },
    "0xC00D0013": {
        "name": "NS_E_TIMEOUT",
        "explanation": "The server, a computer set up to offer multimedia content to other computers, could not handle your request for multimedia content in a timely manner. Please try again later.",
    },
    "0xC00D0014": {"name": "NS_E_NET_WRITE", "explanation": "Error writing to the network."},
    "0xC00D0015": {"name": "NS_E_NET_READ", "explanation": "Error reading from the network."},
    "0xC00D0016": {"name": "NS_E_DISK_WRITE", "explanation": "Error writing to a disk."},
    "0xC00D0017": {"name": "NS_E_DISK_READ", "explanation": "Error reading from a disk."},
    "0xC00D0018": {"name": "NS_E_FILE_WRITE", "explanation": "Error writing to a file."},
    "0xC00D0019": {"name": "NS_E_FILE_READ", "explanation": "Error reading from a file."},
    "0xC00D001A": {"name": "NS_E_FILE_NOT_FOUND", "explanation": "The system cannot find the file specified."},
    "0xC00D001B": {"name": "NS_E_FILE_EXISTS", "explanation": "The file already exists."},
    "0xC00D001C": {
        "name": "NS_E_INVALID_NAME",
        "explanation": "The file name, directory name, or volume label syntax is incorrect.",
    },
    "0xC00D001D": {"name": "NS_E_FILE_OPEN_FAILED", "explanation": "Failed to open a file."},
    "0xC00D001E": {"name": "NS_E_FILE_ALLOCATION_FAILED", "explanation": "Unable to allocate a file."},
    "0xC00D001F": {"name": "NS_E_FILE_INIT_FAILED", "explanation": "Unable to initialize a file."},
    "0xC00D0020": {"name": "NS_E_FILE_PLAY_FAILED", "explanation": "Unable to play a file."},
    "0xC00D0021": {"name": "NS_E_SET_DISK_UID_FAILED", "explanation": "Could not set the disk UID."},
    "0xC00D0022": {"name": "NS_E_INDUCED", "explanation": "An error was induced for testing purposes."},
    "0xC00D0023": {"name": "NS_E_CCLINK_DOWN", "explanation": "Two Content Servers failed to communicate."},
    "0xC00D0024": {"name": "NS_E_INTERNAL", "explanation": "An unknown error occurred."},
    "0xC00D0025": {"name": "NS_E_BUSY", "explanation": "The requested resource is in use."},
    "0xC00D0026": {
        "name": "NS_E_UNRECOGNIZED_STREAM_TYPE",
        "explanation": "The specified protocol is not recognized. Be sure that the file name and syntax, such as slashes, are correct for the protocol.",
    },
    "0xC00D0027": {"name": "NS_E_NETWORK_SERVICE_FAILURE", "explanation": "The network service provider failed."},
    "0xC00D0028": {
        "name": "NS_E_NETWORK_RESOURCE_FAILURE",
        "explanation": "An attempt to acquire a network resource failed.",
    },
    "0xC00D0029": {"name": "NS_E_CONNECTION_FAILURE", "explanation": "The network connection has failed."},
    "0xC00D002A": {"name": "NS_E_SHUTDOWN", "explanation": "The session is being terminated locally."},
    "0xC00D002B": {"name": "NS_E_INVALID_REQUEST", "explanation": "The request is invalid in the current state."},
    "0xC00D002C": {
        "name": "NS_E_INSUFFICIENT_BANDWIDTH",
        "explanation": "There is insufficient bandwidth available to fulfill the request.",
    },
    "0xC00D002D": {"name": "NS_E_NOT_REBUILDING", "explanation": "The disk is not rebuilding."},
    "0xC00D002E": {
        "name": "NS_E_LATE_OPERATION",
        "explanation": "An operation requested for a particular time could not be carried out on schedule.",
    },
    "0xC00D002F": {"name": "NS_E_INVALID_DATA", "explanation": "Invalid or corrupt data was encountered."},
    "0xC00D0030": {
        "name": "NS_E_FILE_BANDWIDTH_LIMIT",
        "explanation": "The bandwidth required to stream a file is higher than the maximum file bandwidth allowed on the server.",
    },
    "0xC00D0031": {
        "name": "NS_E_OPEN_FILE_LIMIT",
        "explanation": "The client cannot have any more files open simultaneously.",
    },
    "0xC00D0032": {
        "name": "NS_E_BAD_CONTROL_DATA",
        "explanation": "The server received invalid data from the client on the control connection.",
    },
    "0xC00D0033": {"name": "NS_E_NO_STREAM", "explanation": "There is no stream available."},
    "0xC00D0034": {"name": "NS_E_STREAM_END", "explanation": "There is no more data in the stream."},
    "0xC00D0035": {"name": "NS_E_SERVER_NOT_FOUND", "explanation": "The specified server could not be found."},
    "0xC00D0036": {"name": "NS_E_DUPLICATE_NAME", "explanation": "The specified name is already in use."},
    "0xC00D0037": {"name": "NS_E_DUPLICATE_ADDRESS", "explanation": "The specified address is already in use."},
    "0xC00D0038": {
        "name": "NS_E_BAD_MULTICAST_ADDRESS",
        "explanation": "The specified address is not a valid multicast address.",
    },
    "0xC00D0039": {"name": "NS_E_BAD_ADAPTER_ADDRESS", "explanation": "The specified adapter address is invalid."},
    "0xC00D003A": {"name": "NS_E_BAD_DELIVERY_MODE", "explanation": "The specified delivery mode is invalid."},
    "0xC00D003B": {"name": "NS_E_INVALID_CHANNEL", "explanation": "The specified station does not exist."},
    "0xC00D003C": {"name": "NS_E_INVALID_STREAM", "explanation": "The specified stream does not exist."},
    "0xC00D003D": {"name": "NS_E_INVALID_ARCHIVE", "explanation": "The specified archive could not be opened."},
    "0xC00D003E": {"name": "NS_E_NOTITLES", "explanation": "The system cannot find any titles on the server."},
    "0xC00D003F": {"name": "NS_E_INVALID_CLIENT", "explanation": "The system cannot find the client specified."},
    "0xC00D0040": {
        "name": "NS_E_INVALID_BLACKHOLE_ADDRESS",
        "explanation": "The Blackhole Address is not initialized.",
    },
    "0xC00D0041": {
        "name": "NS_E_INCOMPATIBLE_FORMAT",
        "explanation": "The station does not support the stream format.",
    },
    "0xC00D0042": {"name": "NS_E_INVALID_KEY", "explanation": "The specified key is not valid."},
    "0xC00D0043": {"name": "NS_E_INVALID_PORT", "explanation": "The specified port is not valid."},
    "0xC00D0044": {"name": "NS_E_INVALID_TTL", "explanation": "The specified TTL is not valid."},
    "0xC00D0045": {
        "name": "NS_E_STRIDE_REFUSED",
        "explanation": "The request to fast forward or rewind could not be fulfilled.",
    },
    "0xC00D0046": {
        "name": "NS_E_MMSAUTOSERVER_CANTFINDWALKER",
        "explanation": "Unable to load the appropriate file parser.",
    },
    "0xC00D0047": {"name": "NS_E_MAX_BITRATE", "explanation": "Cannot exceed the maximum bandwidth limit."},
    "0xC00D0048": {"name": "NS_E_LOGFILEPERIOD", "explanation": "Invalid value for LogFilePeriod."},
    "0xC00D0049": {"name": "NS_E_MAX_CLIENTS", "explanation": "Cannot exceed the maximum client limit."},
    "0xC00D004A": {"name": "NS_E_LOG_FILE_SIZE", "explanation": "The maximum log file size has been reached."},
    "0xC00D004B": {"name": "NS_E_MAX_FILERATE", "explanation": "Cannot exceed the maximum file rate."},
    "0xC00D004C": {"name": "NS_E_WALKER_UNKNOWN", "explanation": "Unknown file type."},
    "0xC00D004D": {
        "name": "NS_E_WALKER_SERVER",
        "explanation": "The specified file, %1, cannot be loaded onto the specified server, %2.",
    },
    "0xC00D004E": {"name": "NS_E_WALKER_USAGE", "explanation": "There was a usage error with file parser."},
    "0xC00D0050": {"name": "NS_E_TIGER_FAIL", "explanation": "The Title Server %1 has failed."},
    "0xC00D0053": {"name": "NS_E_CUB_FAIL", "explanation": "Content Server %1 (%2) has failed."},
    "0xC00D0055": {"name": "NS_E_DISK_FAIL", "explanation": "Disk %1 ( %2 ) on Content Server %3, has failed."},
    "0xC00D0060": {
        "name": "NS_E_MAX_FUNNELS_ALERT",
        "explanation": "The NetShow data stream limit of %1 streams was reached.",
    },
    "0xC00D0061": {
        "name": "NS_E_ALLOCATE_FILE_FAIL",
        "explanation": "The NetShow Video Server was unable to allocate a %1 block file named %2.",
    },
    "0xC00D0062": {"name": "NS_E_PAGING_ERROR", "explanation": "A Content Server was unable to page a block."},
    "0xC00D0063": {
        "name": "NS_E_BAD_BLOCK0_VERSION",
        "explanation": "Disk %1 has unrecognized control block version %2.",
    },
    "0xC00D0064": {"name": "NS_E_BAD_DISK_UID", "explanation": "Disk %1 has incorrect uid %2."},
    "0xC00D0065": {
        "name": "NS_E_BAD_FSMAJOR_VERSION",
        "explanation": "Disk %1 has unsupported file system major version %2.",
    },
    "0xC00D0066": {"name": "NS_E_BAD_STAMPNUMBER", "explanation": "Disk %1 has bad stamp number in control block."},
    "0xC00D0067": {"name": "NS_E_PARTIALLY_REBUILT_DISK", "explanation": "Disk %1 is partially reconstructed."},
    "0xC00D0068": {"name": "NS_E_ENACTPLAN_GIVEUP", "explanation": "EnactPlan gives up."},
    "0xC00D006A": {"name": "MCMADM_E_REGKEY_NOT_FOUND", "explanation": "The key was not found in the registry."},
    "0xC00D006B": {
        "name": "NS_E_NO_FORMATS",
        "explanation": "The publishing point cannot be started because the server does not have the appropriate stream formats. Use the Multicast Announcement Wizard to create a new announcement for this publishing point.",
    },
    "0xC00D006C": {"name": "NS_E_NO_REFERENCES", "explanation": "No reference URLs were found in an ASX file."},
    "0xC00D006D": {"name": "NS_E_WAVE_OPEN", "explanation": "Error opening wave device, the device might be in use."},
    "0xC00D006F": {
        "name": "NS_E_CANNOTCONNECTEVENTS",
        "explanation": "Unable to establish a connection to the NetShow event monitor service.",
    },
    "0xC00D0071": {"name": "NS_E_NO_DEVICE", "explanation": "No device driver is present on the system."},
    "0xC00D0072": {"name": "NS_E_NO_SPECIFIED_DEVICE", "explanation": "No specified device driver is present."},
    "0xC00D00C8": {
        "name": "NS_E_MONITOR_GIVEUP",
        "explanation": "Netshow Events Monitor is not operational and has been disconnected.",
    },
    "0xC00D00C9": {"name": "NS_E_REMIRRORED_DISK", "explanation": "Disk %1 is remirrored."},
    "0xC00D00CA": {"name": "NS_E_INSUFFICIENT_DATA", "explanation": "Insufficient data found."},
    "0xC00D00CB": {"name": "NS_E_ASSERT", "explanation": "1 failed in file %2 line %3."},
    "0xC00D00CC": {"name": "NS_E_BAD_ADAPTER_NAME", "explanation": "The specified adapter name is invalid."},
    "0xC00D00CD": {"name": "NS_E_NOT_LICENSED", "explanation": "The application is not licensed for this feature."},
    "0xC00D00CE": {"name": "NS_E_NO_SERVER_CONTACT", "explanation": "Unable to contact the server."},
    "0xC00D00CF": {"name": "NS_E_TOO_MANY_TITLES", "explanation": "Maximum number of titles exceeded."},
    "0xC00D00D0": {"name": "NS_E_TITLE_SIZE_EXCEEDED", "explanation": "Maximum size of a title exceeded."},
    "0xC00D00D1": {"name": "NS_E_UDP_DISABLED", "explanation": "UDP protocol not enabled. Not trying %1!ls!."},
    "0xC00D00D2": {"name": "NS_E_TCP_DISABLED", "explanation": "TCP protocol not enabled. Not trying %1!ls!."},
    "0xC00D00D3": {"name": "NS_E_HTTP_DISABLED", "explanation": "HTTP protocol not enabled. Not trying %1!ls!."},
    "0xC00D00D4": {"name": "NS_E_LICENSE_EXPIRED", "explanation": "The product license has expired."},
    "0xC00D00D5": {
        "name": "NS_E_TITLE_BITRATE",
        "explanation": "Source file exceeds the per title maximum bitrate. See NetShow Theater documentation for more information.",
    },
    "0xC00D00D6": {"name": "NS_E_EMPTY_PROGRAM_NAME", "explanation": "The program name cannot be empty."},
    "0xC00D00D7": {"name": "NS_E_MISSING_CHANNEL", "explanation": "Station %1 does not exist."},
    "0xC00D00D8": {
        "name": "NS_E_NO_CHANNELS",
        "explanation": "You need to define at least one station before this operation can complete.",
    },
    "0xC00D00D9": {"name": "NS_E_INVALID_INDEX2", "explanation": "The index specified is invalid."},
    "0xC00D0190": {
        "name": "NS_E_CUB_FAIL_LINK",
        "explanation": "Content Server %1 (%2) has failed its link to Content Server %3.",
    },
    "0xC00D0192": {"name": "NS_E_BAD_CUB_UID", "explanation": "Content Server %1 (%2) has incorrect uid %3."},
    "0xC00D0195": {"name": "NS_E_GLITCH_MODE", "explanation": "Server unreliable because multiple components failed."},
    "0xC00D019B": {
        "name": "NS_E_NO_MEDIA_PROTOCOL",
        "explanation": "Content Server %1 (%2) is unable to communicate with the Media System Network Protocol.",
    },
    "0xC00D07F1": {"name": "NS_E_NOTHING_TO_DO", "explanation": "Nothing to do."},
    "0xC00D07F2": {"name": "NS_E_NO_MULTICAST", "explanation": "Not receiving data from the server."},
    "0xC00D0BB8": {"name": "NS_E_INVALID_INPUT_FORMAT", "explanation": "The input media format is invalid."},
    "0xC00D0BB9": {
        "name": "NS_E_MSAUDIO_NOT_INSTALLED",
        "explanation": "The MSAudio codec is not installed on this system.",
    },
    "0xC00D0BBA": {
        "name": "NS_E_UNEXPECTED_MSAUDIO_ERROR",
        "explanation": "An unexpected error occurred with the MSAudio codec.",
    },
    "0xC00D0BBB": {"name": "NS_E_INVALID_OUTPUT_FORMAT", "explanation": "The output media format is invalid."},
    "0xC00D0BBC": {
        "name": "NS_E_NOT_CONFIGURED",
        "explanation": "The object must be fully configured before audio samples can be processed.",
    },
    "0xC00D0BBD": {
        "name": "NS_E_PROTECTED_CONTENT",
        "explanation": "You need a license to perform the requested operation on this media file.",
    },
    "0xC00D0BBE": {
        "name": "NS_E_LICENSE_REQUIRED",
        "explanation": "You need a license to perform the requested operation on this media file.",
    },
    "0xC00D0BBF": {
        "name": "NS_E_TAMPERED_CONTENT",
        "explanation": "This media file is corrupted or invalid. Contact the content provider for a new file.",
    },
    "0xC00D0BC0": {
        "name": "NS_E_LICENSE_OUTOFDATE",
        "explanation": "The license for this media file has expired. Get a new license or contact the content provider for further assistance.",
    },
    "0xC00D0BC1": {
        "name": "NS_E_LICENSE_INCORRECT_RIGHTS",
        "explanation": "You are not allowed to open this file. Contact the content provider for further assistance.",
    },
    "0xC00D0BC2": {
        "name": "NS_E_AUDIO_CODEC_NOT_INSTALLED",
        "explanation": "The requested audio codec is not installed on this system.",
    },
    "0xC00D0BC3": {
        "name": "NS_E_AUDIO_CODEC_ERROR",
        "explanation": "An unexpected error occurred with the audio codec.",
    },
    "0xC00D0BC4": {
        "name": "NS_E_VIDEO_CODEC_NOT_INSTALLED",
        "explanation": "The requested video codec is not installed on this system.",
    },
    "0xC00D0BC5": {
        "name": "NS_E_VIDEO_CODEC_ERROR",
        "explanation": "An unexpected error occurred with the video codec.",
    },
    "0xC00D0BC6": {"name": "NS_E_INVALIDPROFILE", "explanation": "The Profile is invalid."},
    "0xC00D0BC7": {
        "name": "NS_E_INCOMPATIBLE_VERSION",
        "explanation": "A new version of the SDK is needed to play the requested content.",
    },
    "0xC00D0BCA": {"name": "NS_E_OFFLINE_MODE", "explanation": "The requested URL is not available in offline mode."},
    "0xC00D0BCB": {
        "name": "NS_E_NOT_CONNECTED",
        "explanation": "The requested URL cannot be accessed because there is no network connection.",
    },
    "0xC00D0BCC": {
        "name": "NS_E_TOO_MUCH_DATA",
        "explanation": "The encoding process was unable to keep up with the amount of supplied data.",
    },
    "0xC00D0BCD": {"name": "NS_E_UNSUPPORTED_PROPERTY", "explanation": "The given property is not supported."},
    "0xC00D0BCE": {
        "name": "NS_E_8BIT_WAVE_UNSUPPORTED",
        "explanation": "Windows Media Player cannot copy the files to the CD because they are 8-bit. Convert the files to 16-bit, 44-kHz stereo files by using Sound Recorder or another audio-processing program, and then try again.",
    },
    "0xC00D0BCF": {"name": "NS_E_NO_MORE_SAMPLES", "explanation": "There are no more samples in the current range."},
    "0xC00D0BD0": {"name": "NS_E_INVALID_SAMPLING_RATE", "explanation": "The given sampling rate is invalid."},
    "0xC00D0BD1": {
        "name": "NS_E_MAX_PACKET_SIZE_TOO_SMALL",
        "explanation": "The given maximum packet size is too small to accommodate this profile.)",
    },
    "0xC00D0BD2": {"name": "NS_E_LATE_PACKET", "explanation": "The packet arrived too late to be of use."},
    "0xC00D0BD3": {"name": "NS_E_DUPLICATE_PACKET", "explanation": "The packet is a duplicate of one received before."},
    "0xC00D0BD4": {"name": "NS_E_SDK_BUFFERTOOSMALL", "explanation": "Supplied buffer is too small."},
    "0xC00D0BD5": {
        "name": "NS_E_INVALID_NUM_PASSES",
        "explanation": "The wrong number of preprocessing passes was used for the stream's output type.",
    },
    "0xC00D0BD6": {
        "name": "NS_E_ATTRIBUTE_READ_ONLY",
        "explanation": "An attempt was made to add, modify, or delete a read only attribute.",
    },
    "0xC00D0BD7": {
        "name": "NS_E_ATTRIBUTE_NOT_ALLOWED",
        "explanation": "An attempt was made to add attribute that is not allowed for the given media type.",
    },
    "0xC00D0BD8": {"name": "NS_E_INVALID_EDL", "explanation": "The EDL provided is invalid."},
    "0xC00D0BD9": {
        "name": "NS_E_DATA_UNIT_EXTENSION_TOO_LARGE",
        "explanation": "The Data Unit Extension data was too large to be used.",
    },
    "0xC00D0BDA": {"name": "NS_E_CODEC_DMO_ERROR", "explanation": "An unexpected error occurred with a DMO codec."},
    "0xC00D0BDC": {
        "name": "NS_E_FEATURE_DISABLED_BY_GROUP_POLICY",
        "explanation": "This feature has been disabled by group policy.",
    },
    "0xC00D0BDD": {"name": "NS_E_FEATURE_DISABLED_IN_SKU", "explanation": "This feature is disabled in this SKU."},
    "0xC00D0FA0": {
        "name": "NS_E_NO_CD",
        "explanation": "There is no CD in the CD drive. Insert a CD, and then try again.",
    },
    "0xC00D0FA1": {
        "name": "NS_E_CANT_READ_DIGITAL",
        "explanation": "Windows Media Player could not use digital playback to play the CD. To switch to analog playback, on the Tools menu, click Options, and then click the Devices tab. Double-click the CD drive, and then in the Playback area, click Analog. For additional assistance, click Web Help.",
    },
    "0xC00D0FA2": {
        "name": "NS_E_DEVICE_DISCONNECTED",
        "explanation": "Windows Media Player no longer detects a connected portable device. Reconnect your portable device, and then try synchronizing the file again.",
    },
    "0xC00D0FA3": {
        "name": "NS_E_DEVICE_NOT_SUPPORT_FORMAT",
        "explanation": "Windows Media Player cannot play the file. The portable device does not support the specified file type.",
    },
    "0xC00D0FA4": {
        "name": "NS_E_SLOW_READ_DIGITAL",
        "explanation": "Windows Media Player could not use digital playback to play the CD. The Player has automatically switched the CD drive to analog playback. To switch back to digital CD playback, use the Devices tab. For additional assistance, click Web Help.",
    },
    "0xC00D0FA5": {"name": "NS_E_MIXER_INVALID_LINE", "explanation": "An invalid line error occurred in the mixer."},
    "0xC00D0FA6": {
        "name": "NS_E_MIXER_INVALID_CONTROL",
        "explanation": "An invalid control error occurred in the mixer.",
    },
    "0xC00D0FA7": {"name": "NS_E_MIXER_INVALID_VALUE", "explanation": "An invalid value error occurred in the mixer."},
    "0xC00D0FA8": {
        "name": "NS_E_MIXER_UNKNOWN_MMRESULT",
        "explanation": "An unrecognized MMRESULT occurred in the mixer.",
    },
    "0xC00D0FA9": {"name": "NS_E_USER_STOP", "explanation": "User has stopped the operation."},
    "0xC00D0FAA": {
        "name": "NS_E_MP3_FORMAT_NOT_FOUND",
        "explanation": "Windows Media Player cannot rip the track because a compatible MP3 encoder is not installed on your computer. Install a compatible MP3 encoder or choose a different format to rip to (such as Windows Media Audio).",
    },
    "0xC00D0FAB": {
        "name": "NS_E_CD_READ_ERROR_NO_CORRECTION",
        "explanation": "Windows Media Player cannot read the CD. The disc might be dirty or damaged. Turn on error correction, and then try again.",
    },
    "0xC00D0FAC": {
        "name": "NS_E_CD_READ_ERROR",
        "explanation": "Windows Media Player cannot read the CD. The disc might be dirty or damaged or the CD drive might be malfunctioning.",
    },
    "0xC00D0FAD": {
        "name": "NS_E_CD_SLOW_COPY",
        "explanation": "For best performance, do not play CD tracks while ripping them.",
    },
    "0xC00D0FAE": {
        "name": "NS_E_CD_COPYTO_CD",
        "explanation": "It is not possible to directly burn tracks from one CD to another CD. You must first rip the tracks from the CD to your computer, and then burn the files to a blank CD.",
    },
    "0xC00D0FAF": {"name": "NS_E_MIXER_NODRIVER", "explanation": "Could not open a sound mixer driver."},
    "0xC00D0FB0": {
        "name": "NS_E_REDBOOK_ENABLED_WHILE_COPYING",
        "explanation": "Windows Media Player cannot rip tracks from the CD correctly because the CD drive settings in Device Manager do not match the CD drive settings in the Player.",
    },
    "0xC00D0FB1": {"name": "NS_E_CD_REFRESH", "explanation": "Windows Media Player is busy reading the CD."},
    "0xC00D0FB2": {
        "name": "NS_E_CD_DRIVER_PROBLEM",
        "explanation": "Windows Media Player could not use digital playback to play the CD. The Player has automatically switched the CD drive to analog playback. To switch back to digital CD playback, use the Devices tab. For additional assistance, click Web Help.",
    },
    "0xC00D0FB3": {
        "name": "NS_E_WONT_DO_DIGITAL",
        "explanation": "Windows Media Player could not use digital playback to play the CD. The Player has automatically switched the CD drive to analog playback. To switch back to digital CD playback, use the Devices tab. For additional assistance, click Web Help.",
    },
    "0xC00D0FB4": {
        "name": "NS_E_WMPXML_NOERROR",
        "explanation": "A call was made to GetParseError on the XML parser but there was no error to retrieve.",
    },
    "0xC00D0FB5": {"name": "NS_E_WMPXML_ENDOFDATA", "explanation": "The XML Parser ran out of data while parsing."},
    "0xC00D0FB6": {
        "name": "NS_E_WMPXML_PARSEERROR",
        "explanation": "A generic parse error occurred in the XML parser but no information is available.",
    },
    "0xC00D0FB7": {
        "name": "NS_E_WMPXML_ATTRIBUTENOTFOUND",
        "explanation": "A call get GetNamedAttribute or GetNamedAttributeIndex on the XML parser resulted in the index not being found.",
    },
    "0xC00D0FB8": {
        "name": "NS_E_WMPXML_PINOTFOUND",
        "explanation": "A call was made go GetNamedPI on the XML parser, but the requested Processing Instruction was not found.",
    },
    "0xC00D0FB9": {
        "name": "NS_E_WMPXML_EMPTYDOC",
        "explanation": "Persist was called on the XML parser, but the parser has no data to persist.",
    },
    "0xC00D0FBA": {
        "name": "NS_E_WMP_PATH_ALREADY_IN_LIBRARY",
        "explanation": "This file path is already in the library.",
    },
    "0xC00D0FBE": {
        "name": "NS_E_WMP_FILESCANALREADYSTARTED",
        "explanation": "Windows Media Player is already searching for files to add to your library. Wait for the current process to finish before attempting to search again.",
    },
    "0xC00D0FBF": {
        "name": "NS_E_WMP_HME_INVALIDOBJECTID",
        "explanation": "Windows Media Player is unable to find the media you are looking for.",
    },
    "0xC00D0FC0": {
        "name": "NS_E_WMP_MF_CODE_EXPIRED",
        "explanation": "A component of Windows Media Player is out-of-date. If you are running a pre-release version of Windows, try upgrading to a more recent version.",
    },
    "0xC00D0FC1": {
        "name": "NS_E_WMP_HME_NOTSEARCHABLEFORITEMS",
        "explanation": "This container does not support search on items.",
    },
    "0xC00D0FC7": {
        "name": "NS_E_WMP_ADDTOLIBRARY_FAILED",
        "explanation": "Windows Media Player encountered a problem while adding one or more files to the library. For additional assistance, click Web Help.",
    },
    "0xC00D0FC8": {
        "name": "NS_E_WMP_WINDOWSAPIFAILURE",
        "explanation": "A Windows API call failed but no error information was available.",
    },
    "0xC00D0FC9": {
        "name": "NS_E_WMP_RECORDING_NOT_ALLOWED",
        "explanation": "This file does not have burn rights. If you obtained this file from an online store, go to the online store to get burn rights.",
    },
    "0xC00D0FCA": {
        "name": "NS_E_DEVICE_NOT_READY",
        "explanation": "Windows Media Player no longer detects a connected portable device. Reconnect your portable device, and then try to sync the file again.",
    },
    "0xC00D0FCB": {
        "name": "NS_E_DAMAGED_FILE",
        "explanation": "Windows Media Player cannot play the file because it is corrupted.",
    },
    "0xC00D0FCC": {
        "name": "NS_E_MPDB_GENERIC",
        "explanation": "Windows Media Player encountered an error while attempting to access information in the library. Try restarting the Player.",
    },
    "0xC00D0FCD": {
        "name": "NS_E_FILE_FAILED_CHECKS",
        "explanation": 'The file cannot be added to the library because it is smaller than the "Skip files smaller than" setting. To add the file, change the setting on the Library tab. For additional assistance, click Web Help.',
    },
    "0xC00D0FCE": {
        "name": "NS_E_MEDIA_LIBRARY_FAILED",
        "explanation": "Windows Media Player cannot create the library. You must be logged on as an administrator or a member of the Administrators group to install the Player. For more information, contact your system administrator.",
    },
    "0xC00D0FCF": {
        "name": "NS_E_SHARING_VIOLATION",
        "explanation": "The file is already in use. Close other programs that might be using the file, or stop playing the file, and then try again.",
    },
    "0xC00D0FD0": {
        "name": "NS_E_NO_ERROR_STRING_FOUND",
        "explanation": "Windows Media Player has encountered an unknown error.",
    },
    "0xC00D0FD1": {
        "name": "NS_E_WMPOCX_NO_REMOTE_CORE",
        "explanation": "The Windows Media Player ActiveX control cannot connect to remote media services, but will continue with local media services.",
    },
    "0xC00D0FD2": {
        "name": "NS_E_WMPOCX_NO_ACTIVE_CORE",
        "explanation": "The requested method or property is not available because the Windows Media Player ActiveX control has not been properly activated.",
    },
    "0xC00D0FD3": {
        "name": "NS_E_WMPOCX_NOT_RUNNING_REMOTELY",
        "explanation": "The Windows Media Player ActiveX control is not running in remote mode.",
    },
    "0xC00D0FD4": {
        "name": "NS_E_WMPOCX_NO_REMOTE_WINDOW",
        "explanation": "An error occurred while trying to get the remote Windows Media Player window.",
    },
    "0xC00D0FD5": {
        "name": "NS_E_WMPOCX_ERRORMANAGERNOTAVAILABLE",
        "explanation": "Windows Media Player has encountered an unknown error.",
    },
    "0xC00D0FD6": {
        "name": "NS_E_PLUGIN_NOTSHUTDOWN",
        "explanation": "Windows Media Player was not closed properly. A damaged or incompatible plug-in might have caused the problem to occur. As a precaution, all optional plug-ins have been disabled.",
    },
    "0xC00D0FD7": {
        "name": "NS_E_WMP_CANNOT_FIND_FOLDER",
        "explanation": "Windows Media Player cannot find the specified path. Verify that the path is typed correctly. If it is, the path does not exist in the specified location, or the computer where the path is located is not available.",
    },
    "0xC00D0FD8": {
        "name": "NS_E_WMP_STREAMING_RECORDING_NOT_ALLOWED",
        "explanation": "Windows Media Player cannot save a file that is being streamed.",
    },
    "0xC00D0FD9": {
        "name": "NS_E_WMP_PLUGINDLL_NOTFOUND",
        "explanation": "Windows Media Player cannot find the selected plug-in. The Player will try to remove it from the menu. To use this plug-in, install it again.",
    },
    "0xC00D0FDA": {"name": "NS_E_NEED_TO_ASK_USER", "explanation": "Action requires input from the user."},
    "0xC00D0FDB": {
        "name": "NS_E_WMPOCX_PLAYER_NOT_DOCKED",
        "explanation": "The Windows Media Player ActiveX control must be in a docked state for this action to be performed.",
    },
    "0xC00D0FDC": {
        "name": "NS_E_WMP_EXTERNAL_NOTREADY",
        "explanation": "The Windows Media Player external object is not ready.",
    },
    "0xC00D0FDD": {
        "name": "NS_E_WMP_MLS_STALE_DATA",
        "explanation": "Windows Media Player cannot perform the requested action. Your computer's time and date might not be set correctly.",
    },
    "0xC00D0FDE": {
        "name": "NS_E_WMP_UI_SUBCONTROLSNOTSUPPORTED",
        "explanation": "The control (%s) does not support creation of sub-controls, yet (%d) sub-controls have been specified.",
    },
    "0xC00D0FDF": {
        "name": "NS_E_WMP_UI_VERSIONMISMATCH",
        "explanation": "Version mismatch: (%.1f required, %.1f found).",
    },
    "0xC00D0FE0": {
        "name": "NS_E_WMP_UI_NOTATHEMEFILE",
        "explanation": "The layout manager was given valid XML that wasn't a theme file.",
    },
    "0xC00D0FE1": {
        "name": "NS_E_WMP_UI_SUBELEMENTNOTFOUND",
        "explanation": "The %s subelement could not be found on the %s object.",
    },
    "0xC00D0FE2": {
        "name": "NS_E_WMP_UI_VERSIONPARSE",
        "explanation": "An error occurred parsing the version tag. Valid version tags are of the form: <?wmp version='1.0'?>.",
    },
    "0xC00D0FE3": {
        "name": "NS_E_WMP_UI_VIEWIDNOTFOUND",
        "explanation": "The view specified in for the 'currentViewID' property (%s) was not found in this theme file.",
    },
    "0xC00D0FE4": {"name": "NS_E_WMP_UI_PASSTHROUGH", "explanation": "This error used internally for hit testing."},
    "0xC00D0FE5": {
        "name": "NS_E_WMP_UI_OBJECTNOTFOUND",
        "explanation": "Attributes were specified for the %s object, but the object was not available to send them to.",
    },
    "0xC00D0FE6": {
        "name": "NS_E_WMP_UI_SECONDHANDLER",
        "explanation": "The %s event already has a handler, the second handler was ignored.",
    },
    "0xC00D0FE7": {"name": "NS_E_WMP_UI_NOSKININZIP", "explanation": "No .wms file found in skin archive."},
    "0xC00D0FEA": {
        "name": "NS_E_WMP_URLDOWNLOADFAILED",
        "explanation": "Windows Media Player encountered a problem while downloading the file. For additional assistance, click Web Help.",
    },
    "0xC00D0FEB": {
        "name": "NS_E_WMPOCX_UNABLE_TO_LOAD_SKIN",
        "explanation": "The Windows Media Player ActiveX control cannot load the requested uiMode and cannot roll back to the existing uiMode.",
    },
    "0xC00D0FEC": {
        "name": "NS_E_WMP_INVALID_SKIN",
        "explanation": "Windows Media Player encountered a problem with the skin file. The skin file might not be valid.",
    },
    "0xC00D0FED": {
        "name": "NS_E_WMP_SENDMAILFAILED",
        "explanation": "Windows Media Player cannot send the link because your email program is not responding. Verify that your email program is configured properly, and then try again. For more information about email, see Windows Help.",
    },
    "0xC00D0FEE": {
        "name": "NS_E_WMP_LOCKEDINSKINMODE",
        "explanation": "Windows Media Player cannot switch to full mode because your computer administrator has locked this skin.",
    },
    "0xC00D0FEF": {
        "name": "NS_E_WMP_FAILED_TO_SAVE_FILE",
        "explanation": "Windows Media Player encountered a problem while saving the file. For additional assistance, click Web Help.",
    },
    "0xC00D0FF0": {
        "name": "NS_E_WMP_SAVEAS_READONLY",
        "explanation": "Windows Media Player cannot overwrite a read-only file. Try using a different file name.",
    },
    "0xC00D0FF1": {
        "name": "NS_E_WMP_FAILED_TO_SAVE_PLAYLIST",
        "explanation": "Windows Media Player encountered a problem while creating or saving the playlist. For additional assistance, click Web Help.",
    },
    "0xC00D0FF2": {
        "name": "NS_E_WMP_FAILED_TO_OPEN_WMD",
        "explanation": "Windows Media Player cannot open the Windows Media Download file. The file might be damaged.",
    },
    "0xC00D0FF3": {
        "name": "NS_E_WMP_CANT_PLAY_PROTECTED",
        "explanation": "The file cannot be added to the library because it is a protected DVR-MS file. This content cannot be played back by Windows Media Player.",
    },
    "0xC00D0FF4": {
        "name": "NS_E_SHARING_STATE_OUT_OF_SYNC",
        "explanation": "Media sharing has been turned off because a required Windows setting or component has changed. For additional assistance, click Web Help.",
    },
    "0xC00D0FFA": {
        "name": "NS_E_WMPOCX_REMOTE_PLAYER_ALREADY_RUNNING",
        "explanation": "Exclusive Services launch failed because the Windows Media Player is already running.",
    },
    "0xC00D1004": {
        "name": "NS_E_WMP_RBC_JPGMAPPINGIMAGE",
        "explanation": "JPG Images are not recommended for use as a mappingImage.",
    },
    "0xC00D1005": {
        "name": "NS_E_WMP_JPGTRANSPARENCY",
        "explanation": "JPG Images are not recommended when using a transparencyColor.",
    },
    "0xC00D1009": {
        "name": "NS_E_WMP_INVALID_MAX_VAL",
        "explanation": "The Max property cannot be less than Min property.",
    },
    "0xC00D100A": {
        "name": "NS_E_WMP_INVALID_MIN_VAL",
        "explanation": "The Min property cannot be greater than Max property.",
    },
    "0xC00D100E": {
        "name": "NS_E_WMP_CS_JPGPOSITIONIMAGE",
        "explanation": "JPG Images are not recommended for use as a positionImage.",
    },
    "0xC00D100F": {
        "name": "NS_E_WMP_CS_NOTEVENLYDIVISIBLE",
        "explanation": "The (%s) image's size is not evenly divisible by the positionImage's size.",
    },
    "0xC00D1018": {
        "name": "NS_E_WMPZIP_NOTAZIPFILE",
        "explanation": "The ZIP reader opened a file and its signature did not match that of the ZIP files.",
    },
    "0xC00D1019": {
        "name": "NS_E_WMPZIP_CORRUPT",
        "explanation": "The ZIP reader has detected that the file is corrupted.",
    },
    "0xC00D101A": {
        "name": "NS_E_WMPZIP_FILENOTFOUND",
        "explanation": "GetFileStream, SaveToFile, or SaveTemp file was called on the ZIP reader with a file name that was not found in the ZIP file.",
    },
    "0xC00D1022": {"name": "NS_E_WMP_IMAGE_FILETYPE_UNSUPPORTED", "explanation": "Image type not supported."},
    "0xC00D1023": {"name": "NS_E_WMP_IMAGE_INVALID_FORMAT", "explanation": "Image file might be corrupt."},
    "0xC00D1024": {
        "name": "NS_E_WMP_GIF_UNEXPECTED_ENDOFFILE",
        "explanation": "Unexpected end of file. GIF file might be corrupt.",
    },
    "0xC00D1025": {"name": "NS_E_WMP_GIF_INVALID_FORMAT", "explanation": "Invalid GIF file."},
    "0xC00D1026": {
        "name": "NS_E_WMP_GIF_BAD_VERSION_NUMBER",
        "explanation": "Invalid GIF version. Only 87a or 89a supported.",
    },
    "0xC00D1027": {"name": "NS_E_WMP_GIF_NO_IMAGE_IN_FILE", "explanation": "No images found in GIF file."},
    "0xC00D1028": {"name": "NS_E_WMP_PNG_INVALIDFORMAT", "explanation": "Invalid PNG image file format."},
    "0xC00D1029": {"name": "NS_E_WMP_PNG_UNSUPPORTED_BITDEPTH", "explanation": "PNG bitdepth not supported."},
    "0xC00D102A": {
        "name": "NS_E_WMP_PNG_UNSUPPORTED_COMPRESSION",
        "explanation": "Compression format defined in PNG file not supported,",
    },
    "0xC00D102B": {
        "name": "NS_E_WMP_PNG_UNSUPPORTED_FILTER",
        "explanation": "Filter method defined in PNG file not supported.",
    },
    "0xC00D102C": {
        "name": "NS_E_WMP_PNG_UNSUPPORTED_INTERLACE",
        "explanation": "Interlace method defined in PNG file not supported.",
    },
    "0xC00D102D": {"name": "NS_E_WMP_PNG_UNSUPPORTED_BAD_CRC", "explanation": "Bad CRC in PNG file."},
    "0xC00D102E": {"name": "NS_E_WMP_BMP_INVALID_BITMASK", "explanation": "Invalid bitmask in BMP file."},
    "0xC00D102F": {"name": "NS_E_WMP_BMP_TOPDOWN_DIB_UNSUPPORTED", "explanation": "Topdown DIB not supported."},
    "0xC00D1030": {"name": "NS_E_WMP_BMP_BITMAP_NOT_CREATED", "explanation": "Bitmap could not be created."},
    "0xC00D1031": {
        "name": "NS_E_WMP_BMP_COMPRESSION_UNSUPPORTED",
        "explanation": "Compression format defined in BMP not supported.",
    },
    "0xC00D1032": {"name": "NS_E_WMP_BMP_INVALID_FORMAT", "explanation": "Invalid Bitmap format."},
    "0xC00D1033": {
        "name": "NS_E_WMP_JPG_JERR_ARITHCODING_NOTIMPL",
        "explanation": "JPEG Arithmetic coding not supported.",
    },
    "0xC00D1034": {"name": "NS_E_WMP_JPG_INVALID_FORMAT", "explanation": "Invalid JPEG format."},
    "0xC00D1035": {"name": "NS_E_WMP_JPG_BAD_DCTSIZE", "explanation": "Invalid JPEG format."},
    "0xC00D1036": {
        "name": "NS_E_WMP_JPG_BAD_VERSION_NUMBER",
        "explanation": "Internal version error. Unexpected JPEG library version.",
    },
    "0xC00D1037": {
        "name": "NS_E_WMP_JPG_BAD_PRECISION",
        "explanation": "Internal JPEG Library error. Unsupported JPEG data precision.",
    },
    "0xC00D1038": {"name": "NS_E_WMP_JPG_CCIR601_NOTIMPL", "explanation": "JPEG CCIR601 not supported."},
    "0xC00D1039": {"name": "NS_E_WMP_JPG_NO_IMAGE_IN_FILE", "explanation": "No image found in JPEG file."},
    "0xC00D103A": {"name": "NS_E_WMP_JPG_READ_ERROR", "explanation": "Could not read JPEG file."},
    "0xC00D103B": {
        "name": "NS_E_WMP_JPG_FRACT_SAMPLE_NOTIMPL",
        "explanation": "JPEG Fractional sampling not supported.",
    },
    "0xC00D103C": {
        "name": "NS_E_WMP_JPG_IMAGE_TOO_BIG",
        "explanation": "JPEG image too large. Maximum image size supported is 65500 X 65500.",
    },
    "0xC00D103D": {
        "name": "NS_E_WMP_JPG_UNEXPECTED_ENDOFFILE",
        "explanation": "Unexpected end of file reached in JPEG file.",
    },
    "0xC00D103E": {"name": "NS_E_WMP_JPG_SOF_UNSUPPORTED", "explanation": "Unsupported JPEG SOF marker found."},
    "0xC00D103F": {"name": "NS_E_WMP_JPG_UNKNOWN_MARKER", "explanation": "Unknown JPEG marker found."},
    "0xC00D1044": {
        "name": "NS_E_WMP_FAILED_TO_OPEN_IMAGE",
        "explanation": "Windows Media Player cannot display the picture file. The player either does not support the picture type or the picture is corrupted.",
    },
    "0xC00D1049": {
        "name": "NS_E_WMP_DAI_SONGTOOSHORT",
        "explanation": "Windows Media Player cannot compute a Digital Audio Id for the song. It is too short.",
    },
    "0xC00D104A": {
        "name": "NS_E_WMG_RATEUNAVAILABLE",
        "explanation": "Windows Media Player cannot play the file at the requested speed.",
    },
    "0xC00D104B": {
        "name": "NS_E_WMG_PLUGINUNAVAILABLE",
        "explanation": "The rendering or digital signal processing plug-in cannot be instantiated.",
    },
    "0xC00D104C": {"name": "NS_E_WMG_CANNOTQUEUE", "explanation": "The file cannot be queued for seamless playback."},
    "0xC00D104D": {
        "name": "NS_E_WMG_PREROLLLICENSEACQUISITIONNOTALLOWED",
        "explanation": "Windows Media Player cannot download media usage rights for a file in the playlist.",
    },
    "0xC00D104E": {
        "name": "NS_E_WMG_UNEXPECTEDPREROLLSTATUS",
        "explanation": "Windows Media Player encountered an error while trying to queue a file.",
    },
    "0xC00D1051": {
        "name": "NS_E_WMG_INVALID_COPP_CERTIFICATE",
        "explanation": "Windows Media Player cannot play the protected file. The Player cannot verify that the connection to your video card is secure. Try installing an updated device driver for your video card.",
    },
    "0xC00D1052": {
        "name": "NS_E_WMG_COPP_SECURITY_INVALID",
        "explanation": "Windows Media Player cannot play the protected file. The Player detected that the connection to your hardware might not be secure.",
    },
    "0xC00D1053": {
        "name": "NS_E_WMG_COPP_UNSUPPORTED",
        "explanation": "Windows Media Player output link protection is unsupported on this system.",
    },
    "0xC00D1054": {"name": "NS_E_WMG_INVALIDSTATE", "explanation": "Operation attempted in an invalid graph state."},
    "0xC00D1055": {
        "name": "NS_E_WMG_SINKALREADYEXISTS",
        "explanation": "A renderer cannot be inserted in a stream while one already exists.",
    },
    "0xC00D1056": {
        "name": "NS_E_WMG_NOSDKINTERFACE",
        "explanation": "The Windows Media SDK interface needed to complete the operation does not exist at this time.",
    },
    "0xC00D1057": {
        "name": "NS_E_WMG_NOTALLOUTPUTSRENDERED",
        "explanation": "Windows Media Player cannot play a portion of the file because it requires a codec that either could not be downloaded or that is not supported by the Player.",
    },
    "0xC00D1058": {
        "name": "NS_E_WMG_FILETRANSFERNOTALLOWED",
        "explanation": "File transfer streams are not allowed in the standalone Player.",
    },
    "0xC00D1059": {
        "name": "NS_E_WMR_UNSUPPORTEDSTREAM",
        "explanation": "Windows Media Player cannot play the file. The Player does not support the format you are trying to play.",
    },
    "0xC00D105A": {
        "name": "NS_E_WMR_PINNOTFOUND",
        "explanation": "An operation was attempted on a pin that does not exist in the DirectShow filter graph.",
    },
    "0xC00D105B": {
        "name": "NS_E_WMR_WAITINGONFORMATSWITCH",
        "explanation": "Specified operation cannot be completed while waiting for a media format change from the SDK.",
    },
    "0xC00D105C": {
        "name": "NS_E_WMR_NOSOURCEFILTER",
        "explanation": "Specified operation cannot be completed because the source filter does not exist.",
    },
    "0xC00D105D": {"name": "NS_E_WMR_PINTYPENOMATCH", "explanation": "The specified type does not match this pin."},
    "0xC00D105E": {
        "name": "NS_E_WMR_NOCALLBACKAVAILABLE",
        "explanation": "The WMR Source Filter does not have a callback available.",
    },
    "0xC00D1062": {
        "name": "NS_E_WMR_SAMPLEPROPERTYNOTSET",
        "explanation": "The specified property has not been set on this sample.",
    },
    "0xC00D1063": {
        "name": "NS_E_WMR_CANNOT_RENDER_BINARY_STREAM",
        "explanation": "A plug-in is required to correctly play the file. To determine if the plug-in is available to download, click Web Help.",
    },
    "0xC00D1064": {
        "name": "NS_E_WMG_LICENSE_TAMPERED",
        "explanation": "Windows Media Player cannot play the file because your media usage rights are corrupted. If you previously backed up your media usage rights, try restoring them.",
    },
    "0xC00D1065": {
        "name": "NS_E_WMR_WILLNOT_RENDER_BINARY_STREAM",
        "explanation": "Windows Media Player cannot play protected files that contain binary streams.",
    },
    "0xC00D1068": {
        "name": "NS_E_WMX_UNRECOGNIZED_PLAYLIST_FORMAT",
        "explanation": "Windows Media Player cannot play the playlist because it is not valid.",
    },
    "0xC00D1069": {
        "name": "NS_E_ASX_INVALIDFORMAT",
        "explanation": "Windows Media Player cannot play the playlist because it is not valid.",
    },
    "0xC00D106A": {
        "name": "NS_E_ASX_INVALIDVERSION",
        "explanation": "A later version of Windows Media Player might be required to play this playlist.",
    },
    "0xC00D106B": {
        "name": "NS_E_ASX_INVALID_REPEAT_BLOCK",
        "explanation": "The format of a REPEAT loop within the current playlist file is not valid.",
    },
    "0xC00D106C": {
        "name": "NS_E_ASX_NOTHING_TO_WRITE",
        "explanation": "Windows Media Player cannot save the playlist because it does not contain any items.",
    },
    "0xC00D106D": {
        "name": "NS_E_URLLIST_INVALIDFORMAT",
        "explanation": "Windows Media Player cannot play the playlist because it is not valid.",
    },
    "0xC00D106E": {
        "name": "NS_E_WMX_ATTRIBUTE_DOES_NOT_EXIST",
        "explanation": "The specified attribute does not exist.",
    },
    "0xC00D106F": {
        "name": "NS_E_WMX_ATTRIBUTE_ALREADY_EXISTS",
        "explanation": "The specified attribute already exists.",
    },
    "0xC00D1070": {
        "name": "NS_E_WMX_ATTRIBUTE_UNRETRIEVABLE",
        "explanation": "Cannot retrieve the specified attribute.",
    },
    "0xC00D1071": {
        "name": "NS_E_WMX_ITEM_DOES_NOT_EXIST",
        "explanation": "The specified item does not exist in the current playlist.",
    },
    "0xC00D1072": {
        "name": "NS_E_WMX_ITEM_TYPE_ILLEGAL",
        "explanation": "Items of the specified type cannot be created within the current playlist.",
    },
    "0xC00D1073": {
        "name": "NS_E_WMX_ITEM_UNSETTABLE",
        "explanation": "The specified item cannot be set in the current playlist.",
    },
    "0xC00D1074": {
        "name": "NS_E_WMX_PLAYLIST_EMPTY",
        "explanation": "Windows Media Player cannot perform the requested action because the playlist does not contain any items.",
    },
    "0xC00D1075": {
        "name": "NS_E_MLS_SMARTPLAYLIST_FILTER_NOT_REGISTERED",
        "explanation": "The specified auto playlist contains a filter type that is either not valid or is not installed on this computer.",
    },
    "0xC00D1076": {
        "name": "NS_E_WMX_INVALID_FORMAT_OVER_NESTING",
        "explanation": "Windows Media Player cannot play the file because the associated playlist contains too many nested playlists.",
    },
    "0xC00D107C": {
        "name": "NS_E_WMPCORE_NOSOURCEURLSTRING",
        "explanation": "Windows Media Player cannot find the file. Verify that the path is typed correctly. If it is, the file might not exist in the specified location, or the computer where the file is stored might not be available.",
    },
    "0xC00D107D": {
        "name": "NS_E_WMPCORE_COCREATEFAILEDFORGITOBJECT",
        "explanation": "Failed to create the Global Interface Table.",
    },
    "0xC00D107E": {
        "name": "NS_E_WMPCORE_FAILEDTOGETMARSHALLEDEVENTHANDLERINTERFACE",
        "explanation": "Failed to get the marshaled graph event handler interface.",
    },
    "0xC00D107F": {"name": "NS_E_WMPCORE_BUFFERTOOSMALL", "explanation": "Buffer is too small for copying media type."},
    "0xC00D1080": {
        "name": "NS_E_WMPCORE_UNAVAILABLE",
        "explanation": "The current state of the Player does not allow this operation.",
    },
    "0xC00D1081": {
        "name": "NS_E_WMPCORE_INVALIDPLAYLISTMODE",
        "explanation": "The playlist manager does not understand the current play mode (for example, shuffle or normal).",
    },
    "0xC00D1086": {
        "name": "NS_E_WMPCORE_ITEMNOTINPLAYLIST",
        "explanation": "Windows Media Player cannot play the file because it is not in the current playlist.",
    },
    "0xC00D1087": {
        "name": "NS_E_WMPCORE_PLAYLISTEMPTY",
        "explanation": "There are no items in the playlist. Add items to the playlist, and then try again.",
    },
    "0xC00D1088": {
        "name": "NS_E_WMPCORE_NOBROWSER",
        "explanation": "The web page cannot be displayed because no web browser is installed on your computer.",
    },
    "0xC00D1089": {
        "name": "NS_E_WMPCORE_UNRECOGNIZED_MEDIA_URL",
        "explanation": "Windows Media Player cannot find the specified file. Verify the path is typed correctly. If it is, the file does not exist in the specified location, or the computer where the file is stored is not available.",
    },
    "0xC00D108A": {
        "name": "NS_E_WMPCORE_GRAPH_NOT_IN_LIST",
        "explanation": "Graph with the specified URL was not found in the prerolled graph list.",
    },
    "0xC00D108B": {
        "name": "NS_E_WMPCORE_PLAYLIST_EMPTY_OR_SINGLE_MEDIA",
        "explanation": "Windows Media Player cannot perform the requested operation because there is only one item in the playlist.",
    },
    "0xC00D108C": {
        "name": "NS_E_WMPCORE_ERRORSINKNOTREGISTERED",
        "explanation": "An error sink was never registered for the calling object.",
    },
    "0xC00D108D": {
        "name": "NS_E_WMPCORE_ERRORMANAGERNOTAVAILABLE",
        "explanation": "The error manager is not available to respond to errors.",
    },
    "0xC00D108E": {"name": "NS_E_WMPCORE_WEBHELPFAILED", "explanation": "The Web Help URL cannot be opened."},
    "0xC00D108F": {
        "name": "NS_E_WMPCORE_MEDIA_ERROR_RESUME_FAILED",
        "explanation": "Could not resume playing next item in playlist.",
    },
    "0xC00D1090": {
        "name": "NS_E_WMPCORE_NO_REF_IN_ENTRY",
        "explanation": "Windows Media Player cannot play the file because the associated playlist does not contain any items or the playlist is not valid.",
    },
    "0xC00D1091": {
        "name": "NS_E_WMPCORE_WMX_LIST_ATTRIBUTE_NAME_EMPTY",
        "explanation": "An empty string for playlist attribute name was found.",
    },
    "0xC00D1092": {
        "name": "NS_E_WMPCORE_WMX_LIST_ATTRIBUTE_NAME_ILLEGAL",
        "explanation": "A playlist attribute name that is not valid was found.",
    },
    "0xC00D1093": {
        "name": "NS_E_WMPCORE_WMX_LIST_ATTRIBUTE_VALUE_EMPTY",
        "explanation": "An empty string for a playlist attribute value was found.",
    },
    "0xC00D1094": {
        "name": "NS_E_WMPCORE_WMX_LIST_ATTRIBUTE_VALUE_ILLEGAL",
        "explanation": "An illegal value for a playlist attribute was found.",
    },
    "0xC00D1095": {
        "name": "NS_E_WMPCORE_WMX_LIST_ITEM_ATTRIBUTE_NAME_EMPTY",
        "explanation": "An empty string for a playlist item attribute name was found.",
    },
    "0xC00D1096": {
        "name": "NS_E_WMPCORE_WMX_LIST_ITEM_ATTRIBUTE_NAME_ILLEGAL",
        "explanation": "An illegal value for a playlist item attribute name was found.",
    },
    "0xC00D1097": {
        "name": "NS_E_WMPCORE_WMX_LIST_ITEM_ATTRIBUTE_VALUE_EMPTY",
        "explanation": "An illegal value for a playlist item attribute was found.",
    },
    "0xC00D1098": {"name": "NS_E_WMPCORE_LIST_ENTRY_NO_REF", "explanation": "The playlist does not contain any items."},
    "0xC00D1099": {
        "name": "NS_E_WMPCORE_MISNAMED_FILE",
        "explanation": "Windows Media Player cannot play the file. The file is either corrupted or the Player does not support the format you are trying to play.",
    },
    "0xC00D109A": {
        "name": "NS_E_WMPCORE_CODEC_NOT_TRUSTED",
        "explanation": "The codec downloaded for this file does not appear to be properly signed, so it cannot be installed.",
    },
    "0xC00D109B": {
        "name": "NS_E_WMPCORE_CODEC_NOT_FOUND",
        "explanation": "Windows Media Player cannot play the file. One or more codecs required to play the file could not be found.",
    },
    "0xC00D109C": {
        "name": "NS_E_WMPCORE_CODEC_DOWNLOAD_NOT_ALLOWED",
        "explanation": 'Windows Media Player cannot play the file because a required codec is not installed on your computer. To try downloading the codec, turn on the "Download codecs automatically" option.',
    },
    "0xC00D109D": {
        "name": "NS_E_WMPCORE_ERROR_DOWNLOADING_PLAYLIST",
        "explanation": "Windows Media Player encountered a problem while downloading the playlist. For additional assistance, click Web Help.",
    },
    "0xC00D109E": {"name": "NS_E_WMPCORE_FAILED_TO_BUILD_PLAYLIST", "explanation": "Failed to build the playlist."},
    "0xC00D109F": {
        "name": "NS_E_WMPCORE_PLAYLIST_ITEM_ALTERNATE_NONE",
        "explanation": "Playlist has no alternates to switch into.",
    },
    "0xC00D10A0": {
        "name": "NS_E_WMPCORE_PLAYLIST_ITEM_ALTERNATE_EXHAUSTED",
        "explanation": "No more playlist alternates available to switch to.",
    },
    "0xC00D10A1": {
        "name": "NS_E_WMPCORE_PLAYLIST_ITEM_ALTERNATE_NAME_NOT_FOUND",
        "explanation": "Could not find the name of the alternate playlist to switch into.",
    },
    "0xC00D10A2": {
        "name": "NS_E_WMPCORE_PLAYLIST_ITEM_ALTERNATE_MORPH_FAILED",
        "explanation": "Failed to switch to an alternate for this media.",
    },
    "0xC00D10A3": {
        "name": "NS_E_WMPCORE_PLAYLIST_ITEM_ALTERNATE_INIT_FAILED",
        "explanation": "Failed to initialize an alternate for the media.",
    },
    "0xC00D10A4": {
        "name": "NS_E_WMPCORE_MEDIA_ALTERNATE_REF_EMPTY",
        "explanation": "No URL specified for the roll over Refs in the playlist file.",
    },
    "0xC00D10A5": {
        "name": "NS_E_WMPCORE_PLAYLIST_NO_EVENT_NAME",
        "explanation": "Encountered a playlist with no name.",
    },
    "0xC00D10A6": {
        "name": "NS_E_WMPCORE_PLAYLIST_EVENT_ATTRIBUTE_ABSENT",
        "explanation": "A required attribute in the event block of the playlist was not found.",
    },
    "0xC00D10A7": {
        "name": "NS_E_WMPCORE_PLAYLIST_EVENT_EMPTY",
        "explanation": "No items were found in the event block of the playlist.",
    },
    "0xC00D10A8": {
        "name": "NS_E_WMPCORE_PLAYLIST_STACK_EMPTY",
        "explanation": "No playlist was found while returning from a nested playlist.",
    },
    "0xC00D10A9": {
        "name": "NS_E_WMPCORE_CURRENT_MEDIA_NOT_ACTIVE",
        "explanation": "The media item is not active currently.",
    },
    "0xC00D10AB": {
        "name": "NS_E_WMPCORE_USER_CANCEL",
        "explanation": "Windows Media Player cannot perform the requested action because you chose to cancel it.",
    },
    "0xC00D10AC": {
        "name": "NS_E_WMPCORE_PLAYLIST_REPEAT_EMPTY",
        "explanation": "Windows Media Player encountered a problem with the playlist. The format of the playlist is not valid.",
    },
    "0xC00D10AD": {
        "name": "NS_E_WMPCORE_PLAYLIST_REPEAT_START_MEDIA_NONE",
        "explanation": "Media object corresponding to start of a playlist repeat block was not found.",
    },
    "0xC00D10AE": {
        "name": "NS_E_WMPCORE_PLAYLIST_REPEAT_END_MEDIA_NONE",
        "explanation": "Media object corresponding to the end of a playlist repeat block was not found.",
    },
    "0xC00D10AF": {
        "name": "NS_E_WMPCORE_INVALID_PLAYLIST_URL",
        "explanation": "The playlist URL supplied to the playlist manager is not valid.",
    },
    "0xC00D10B0": {
        "name": "NS_E_WMPCORE_MISMATCHED_RUNTIME",
        "explanation": "Windows Media Player cannot play the file because it is corrupted.",
    },
    "0xC00D10B1": {
        "name": "NS_E_WMPCORE_PLAYLIST_IMPORT_FAILED_NO_ITEMS",
        "explanation": "Windows Media Player cannot add the playlist to the library because the playlist does not contain any items.",
    },
    "0xC00D10B2": {
        "name": "NS_E_WMPCORE_VIDEO_TRANSFORM_FILTER_INSERTION",
        "explanation": "An error has occurred that could prevent the changing of the video contrast on this media.",
    },
    "0xC00D10B3": {
        "name": "NS_E_WMPCORE_MEDIA_UNAVAILABLE",
        "explanation": "Windows Media Player cannot play the file. If the file is located on the Internet, connect to the Internet. If the file is located on a removable storage card, insert the storage card.",
    },
    "0xC00D10B4": {
        "name": "NS_E_WMPCORE_WMX_ENTRYREF_NO_REF",
        "explanation": "The playlist contains an ENTRYREF for which no href was parsed. Check the syntax of playlist file.",
    },
    "0xC00D10B5": {
        "name": "NS_E_WMPCORE_NO_PLAYABLE_MEDIA_IN_PLAYLIST",
        "explanation": "Windows Media Player cannot play any items in the playlist. To find information about the problem, click the Now Playing tab, and then click the icon next to each file in the List pane.",
    },
    "0xC00D10B6": {
        "name": "NS_E_WMPCORE_PLAYLIST_EMPTY_NESTED_PLAYLIST_SKIPPED_ITEMS",
        "explanation": "Windows Media Player cannot play some or all of the items in the playlist because the playlist is nested.",
    },
    "0xC00D10B7": {
        "name": "NS_E_WMPCORE_BUSY",
        "explanation": "Windows Media Player cannot play the file at this time. Try again later.",
    },
    "0xC00D10B8": {
        "name": "NS_E_WMPCORE_MEDIA_CHILD_PLAYLIST_UNAVAILABLE",
        "explanation": "There is no child playlist available for this media item at this time.",
    },
    "0xC00D10B9": {
        "name": "NS_E_WMPCORE_MEDIA_NO_CHILD_PLAYLIST",
        "explanation": "There is no child playlist for this media item.",
    },
    "0xC00D10BA": {
        "name": "NS_E_WMPCORE_FILE_NOT_FOUND",
        "explanation": "Windows Media Player cannot find the file. The link from the item in the library to its associated digital media file might be broken. To fix the problem, try repairing the link or removing the item from the library.",
    },
    "0xC00D10BB": {"name": "NS_E_WMPCORE_TEMP_FILE_NOT_FOUND", "explanation": "The temporary file was not found."},
    "0xC00D10BC": {
        "name": "NS_E_WMDM_REVOKED",
        "explanation": "Windows Media Player cannot sync the file because the device needs to be updated.",
    },
    "0xC00D10BD": {
        "name": "NS_E_DDRAW_GENERIC",
        "explanation": "Windows Media Player cannot play the video because there is a problem with your video card.",
    },
    "0xC00D10BE": {
        "name": "NS_E_DISPLAY_MODE_CHANGE_FAILED",
        "explanation": "Windows Media Player failed to change the screen mode for full-screen video playback.",
    },
    "0xC00D10BF": {
        "name": "NS_E_PLAYLIST_CONTAINS_ERRORS",
        "explanation": "Windows Media Player cannot play one or more files. For additional information, right-click an item that cannot be played, and then click Error Details.",
    },
    "0xC00D10C0": {
        "name": "NS_E_CHANGING_PROXY_NAME",
        "explanation": "Cannot change the proxy name if the proxy setting is not set to custom.",
    },
    "0xC00D10C1": {
        "name": "NS_E_CHANGING_PROXY_PORT",
        "explanation": "Cannot change the proxy port if the proxy setting is not set to custom.",
    },
    "0xC00D10C2": {
        "name": "NS_E_CHANGING_PROXY_EXCEPTIONLIST",
        "explanation": "Cannot change the proxy exception list if the proxy setting is not set to custom.",
    },
    "0xC00D10C3": {
        "name": "NS_E_CHANGING_PROXYBYPASS",
        "explanation": "Cannot change the proxy bypass flag if the proxy setting is not set to custom.",
    },
    "0xC00D10C4": {
        "name": "NS_E_CHANGING_PROXY_PROTOCOL_NOT_FOUND",
        "explanation": "Cannot find the specified protocol.",
    },
    "0xC00D10C5": {
        "name": "NS_E_GRAPH_NOAUDIOLANGUAGE",
        "explanation": "Cannot change the language settings. Either the graph has no audio or the audio only supports one language.",
    },
    "0xC00D10C6": {
        "name": "NS_E_GRAPH_NOAUDIOLANGUAGESELECTED",
        "explanation": "The graph has no audio language selected.",
    },
    "0xC00D10C7": {"name": "NS_E_CORECD_NOTAMEDIACD", "explanation": "This is not a media CD."},
    "0xC00D10C8": {
        "name": "NS_E_WMPCORE_MEDIA_URL_TOO_LONG",
        "explanation": "Windows Media Player cannot play the file because the URL is too long.",
    },
    "0xC00D10C9": {
        "name": "NS_E_WMPFLASH_CANT_FIND_COM_SERVER",
        "explanation": "To play the selected item, you must install the Macromedia Flash Player. To download the Macromedia Flash Player, go to the Adobe website.",
    },
    "0xC00D10CA": {
        "name": "NS_E_WMPFLASH_INCOMPATIBLEVERSION",
        "explanation": "To play the selected item, you must install a later version of the Macromedia Flash Player. To download the Macromedia Flash Player, go to the Adobe website.",
    },
    "0xC00D10CB": {
        "name": "NS_E_WMPOCXGRAPH_IE_DISALLOWS_ACTIVEX_CONTROLS",
        "explanation": "Windows Media Player cannot play the file because your Internet security settings prohibit the use of ActiveX controls.",
    },
    "0xC00D10CC": {
        "name": "NS_E_NEED_CORE_REFERENCE",
        "explanation": "The use of this method requires an existing reference to the Player object.",
    },
    "0xC00D10CD": {
        "name": "NS_E_MEDIACD_READ_ERROR",
        "explanation": "Windows Media Player cannot play the CD. The disc might be dirty or damaged.",
    },
    "0xC00D10CE": {
        "name": "NS_E_IE_DISALLOWS_ACTIVEX_CONTROLS",
        "explanation": "Windows Media Player cannot play the file because your Internet security settings prohibit the use of ActiveX controls.",
    },
    "0xC00D10CF": {
        "name": "NS_E_FLASH_PLAYBACK_NOT_ALLOWED",
        "explanation": "Flash playback has been turned off in Windows Media Player.",
    },
    "0xC00D10D0": {
        "name": "NS_E_UNABLE_TO_CREATE_RIP_LOCATION",
        "explanation": "Windows Media Player cannot rip the CD because a valid rip location cannot be created.",
    },
    "0xC00D10D1": {
        "name": "NS_E_WMPCORE_SOME_CODECS_MISSING",
        "explanation": "Windows Media Player cannot play the file because a required codec is not installed on your computer.",
    },
    "0xC00D10D2": {
        "name": "NS_E_WMP_RIP_FAILED",
        "explanation": "Windows Media Player cannot rip one or more tracks from the CD.",
    },
    "0xC00D10D3": {
        "name": "NS_E_WMP_FAILED_TO_RIP_TRACK",
        "explanation": "Windows Media Player encountered a problem while ripping the track from the CD. For additional assistance, click Web Help.",
    },
    "0xC00D10D4": {
        "name": "NS_E_WMP_ERASE_FAILED",
        "explanation": "Windows Media Player encountered a problem while erasing the disc. For additional assistance, click Web Help.",
    },
    "0xC00D10D5": {
        "name": "NS_E_WMP_FORMAT_FAILED",
        "explanation": "Windows Media Player encountered a problem while formatting the device. For additional assistance, click Web Help.",
    },
    "0xC00D10D6": {
        "name": "NS_E_WMP_CANNOT_BURN_NON_LOCAL_FILE",
        "explanation": "This file cannot be burned to a CD because it is not located on your computer.",
    },
    "0xC00D10D7": {
        "name": "NS_E_WMP_FILE_TYPE_CANNOT_BURN_TO_AUDIO_CD",
        "explanation": "It is not possible to burn this file type to an audio CD. Windows Media Player can burn the following file types to an audio CD: WMA, MP3, or WAV.",
    },
    "0xC00D10D8": {
        "name": "NS_E_WMP_FILE_DOES_NOT_FIT_ON_CD",
        "explanation": "This file is too large to fit on a disc.",
    },
    "0xC00D10D9": {
        "name": "NS_E_WMP_FILE_NO_DURATION",
        "explanation": "It is not possible to determine if this file can fit on a disc because Windows Media Player cannot detect the length of the file. Playing the file before burning might enable the Player to detect the file length.",
    },
    "0xC00D10DA": {
        "name": "NS_E_PDA_FAILED_TO_BURN",
        "explanation": "Windows Media Player encountered a problem while burning the file to the disc. For additional assistance, click Web Help.",
    },
    "0xC00D10DC": {
        "name": "NS_E_FAILED_DOWNLOAD_ABORT_BURN",
        "explanation": "Windows Media Player cannot burn the audio CD because some items in the list that you chose to buy could not be downloaded from the online store.",
    },
    "0xC00D10DD": {
        "name": "NS_E_WMPCORE_DEVICE_DRIVERS_MISSING",
        "explanation": "Windows Media Player cannot play the file. Try using Windows Update or Device Manager to update the device drivers for your audio and video cards. For information about using Windows Update or Device Manager, see Windows Help.",
    },
    "0xC00D1126": {
        "name": "NS_E_WMPIM_USEROFFLINE",
        "explanation": "Windows Media Player has detected that you are not connected to the Internet. Connect to the Internet, and then try again.",
    },
    "0xC00D1127": {
        "name": "NS_E_WMPIM_USERCANCELED",
        "explanation": "The attempt to connect to the Internet was canceled.",
    },
    "0xC00D1128": {"name": "NS_E_WMPIM_DIALUPFAILED", "explanation": "The attempt to connect to the Internet failed."},
    "0xC00D1129": {
        "name": "NS_E_WINSOCK_ERROR_STRING",
        "explanation": "Windows Media Player has encountered an unknown network error.",
    },
    "0xC00D1130": {
        "name": "NS_E_WMPBR_NOLISTENER",
        "explanation": "No window is currently listening to Backup and Restore events.",
    },
    "0xC00D1131": {
        "name": "NS_E_WMPBR_BACKUPCANCEL",
        "explanation": "Your media usage rights were not backed up because the backup was canceled.",
    },
    "0xC00D1132": {
        "name": "NS_E_WMPBR_RESTORECANCEL",
        "explanation": "Your media usage rights were not restored because the restoration was canceled.",
    },
    "0xC00D1133": {
        "name": "NS_E_WMPBR_ERRORWITHURL",
        "explanation": "An error occurred while backing up or restoring your media usage rights. A required web page cannot be displayed.",
    },
    "0xC00D1134": {
        "name": "NS_E_WMPBR_NAMECOLLISION",
        "explanation": "Your media usage rights were not backed up because the backup was canceled.",
    },
    "0xC00D1137": {
        "name": "NS_E_WMPBR_DRIVE_INVALID",
        "explanation": "Windows Media Player cannot restore your media usage rights from the specified location. Choose another location, and then try again.",
    },
    "0xC00D1138": {
        "name": "NS_E_WMPBR_BACKUPRESTOREFAILED",
        "explanation": "Windows Media Player cannot backup or restore your media usage rights.",
    },
    "0xC00D1158": {
        "name": "NS_E_WMP_CONVERT_FILE_FAILED",
        "explanation": "Windows Media Player cannot add the file to the library.",
    },
    "0xC00D1159": {
        "name": "NS_E_WMP_CONVERT_NO_RIGHTS_ERRORURL",
        "explanation": "Windows Media Player cannot add the file to the library because the content provider prohibits it. For assistance, contact the company that provided the file.",
    },
    "0xC00D115A": {
        "name": "NS_E_WMP_CONVERT_NO_RIGHTS_NOERRORURL",
        "explanation": "Windows Media Player cannot add the file to the library because the content provider prohibits it. For assistance, contact the company that provided the file.",
    },
    "0xC00D115B": {
        "name": "NS_E_WMP_CONVERT_FILE_CORRUPT",
        "explanation": "Windows Media Player cannot add the file to the library. The file might not be valid.",
    },
    "0xC00D115C": {
        "name": "NS_E_WMP_CONVERT_PLUGIN_UNAVAILABLE_ERRORURL",
        "explanation": "Windows Media Player cannot add the file to the library. The plug-in required to add the file is not installed properly. For assistance, click Web Help to display the website of the company that provided the file.",
    },
    "0xC00D115D": {
        "name": "NS_E_WMP_CONVERT_PLUGIN_UNAVAILABLE_NOERRORURL",
        "explanation": "Windows Media Player cannot add the file to the library. The plug-in required to add the file is not installed properly. For assistance, contact the company that provided the file.",
    },
    "0xC00D115E": {
        "name": "NS_E_WMP_CONVERT_PLUGIN_UNKNOWN_FILE_OWNER",
        "explanation": "Windows Media Player cannot add the file to the library. The plug-in required to add the file is not installed properly. For assistance, contact the company that provided the file.",
    },
    "0xC00D1160": {
        "name": "NS_E_DVD_DISC_COPY_PROTECT_OUTPUT_NS",
        "explanation": "Windows Media Player cannot play this DVD. Try installing an updated driver for your video card or obtaining a newer video card.",
    },
    "0xC00D1161": {
        "name": "NS_E_DVD_DISC_COPY_PROTECT_OUTPUT_FAILED",
        "explanation": "This DVD's resolution exceeds the maximum allowed by your component video outputs. Try reducing your screen resolution to 640 x 480, or turn off analog component outputs and use a VGA connection to your monitor.",
    },
    "0xC00D1162": {
        "name": "NS_E_DVD_NO_SUBPICTURE_STREAM",
        "explanation": "Windows Media Player cannot display subtitles or highlights in DVD menus. Reinstall the DVD decoder or contact the DVD drive manufacturer to obtain an updated decoder.",
    },
    "0xC00D1163": {
        "name": "NS_E_DVD_COPY_PROTECT",
        "explanation": "Windows Media Player cannot play this DVD because there is a problem with digital copy protection between your DVD drive, decoder, and video card. Try installing an updated driver for your video card.",
    },
    "0xC00D1164": {
        "name": "NS_E_DVD_AUTHORING_PROBLEM",
        "explanation": "Windows Media Player cannot play the DVD. The disc was created in a manner that the Player does not support.",
    },
    "0xC00D1165": {
        "name": "NS_E_DVD_INVALID_DISC_REGION",
        "explanation": "Windows Media Player cannot play the DVD because the disc prohibits playback in your region of the world. You must obtain a disc that is intended for your geographic region.",
    },
    "0xC00D1166": {
        "name": "NS_E_DVD_COMPATIBLE_VIDEO_CARD",
        "explanation": "Windows Media Player cannot play the DVD because your video card does not support DVD playback.",
    },
    "0xC00D1167": {
        "name": "NS_E_DVD_MACROVISION",
        "explanation": "Windows Media Player cannot play this DVD because it is not possible to turn on analog copy protection on the output display. Try installing an updated driver for your video card.",
    },
    "0xC00D1168": {
        "name": "NS_E_DVD_SYSTEM_DECODER_REGION",
        "explanation": "Windows Media Player cannot play the DVD because the region assigned to your DVD drive does not match the region assigned to your DVD decoder.",
    },
    "0xC00D1169": {
        "name": "NS_E_DVD_DISC_DECODER_REGION",
        "explanation": "Windows Media Player cannot play the DVD because the disc prohibits playback in your region of the world. You must obtain a disc that is intended for your geographic region.",
    },
    "0xC00D116A": {
        "name": "NS_E_DVD_NO_VIDEO_STREAM",
        "explanation": "Windows Media Player cannot play DVD video. You might need to adjust your Windows display settings. Open display settings in Control Panel, and then try lowering your screen resolution and color quality settings.",
    },
    "0xC00D116B": {
        "name": "NS_E_DVD_NO_AUDIO_STREAM",
        "explanation": "Windows Media Player cannot play DVD audio. Verify that your sound card is set up correctly, and then try again.",
    },
    "0xC00D116C": {
        "name": "NS_E_DVD_GRAPH_BUILDING",
        "explanation": "Windows Media Player cannot play DVD video. Close any open files and quit any other programs, and then try again. If the problem persists, restart your computer.",
    },
    "0xC00D116D": {
        "name": "NS_E_DVD_NO_DECODER",
        "explanation": "Windows Media Player cannot play the DVD because a compatible DVD decoder is not installed on your computer.",
    },
    "0xC00D116E": {
        "name": "NS_E_DVD_PARENTAL",
        "explanation": "Windows Media Player cannot play the scene because it has a parental rating higher than the rating that you are authorized to view.",
    },
    "0xC00D116F": {
        "name": "NS_E_DVD_CANNOT_JUMP",
        "explanation": "Windows Media Player cannot skip to the requested location on the DVD.",
    },
    "0xC00D1170": {
        "name": "NS_E_DVD_DEVICE_CONTENTION",
        "explanation": "Windows Media Player cannot play the DVD because it is currently in use by another program. Quit the other program that is using the DVD, and then try again.",
    },
    "0xC00D1171": {
        "name": "NS_E_DVD_NO_VIDEO_MEMORY",
        "explanation": "Windows Media Player cannot play DVD video. You might need to adjust your Windows display settings. Open display settings in Control Panel, and then try lowering your screen resolution and color quality settings.",
    },
    "0xC00D1172": {
        "name": "NS_E_DVD_CANNOT_COPY_PROTECTED",
        "explanation": "Windows Media Player cannot rip the DVD because it is copy protected.",
    },
    "0xC00D1173": {
        "name": "NS_E_DVD_REQUIRED_PROPERTY_NOT_SET",
        "explanation": "One of more of the required properties has not been set.",
    },
    "0xC00D1174": {
        "name": "NS_E_DVD_INVALID_TITLE_CHAPTER",
        "explanation": "The specified title and/or chapter number does not exist on this DVD.",
    },
    "0xC00D1176": {
        "name": "NS_E_NO_CD_BURNER",
        "explanation": "Windows Media Player cannot burn the files because the Player cannot find a burner. If the burner is connected properly, try using Windows Update to install the latest device driver.",
    },
    "0xC00D1177": {
        "name": "NS_E_DEVICE_IS_NOT_READY",
        "explanation": "Windows Media Player does not detect storage media in the selected device. Insert storage media into the device, and then try again.",
    },
    "0xC00D1178": {
        "name": "NS_E_PDA_UNSUPPORTED_FORMAT",
        "explanation": "Windows Media Player cannot sync this file. The Player might not support the file type.",
    },
    "0xC00D1179": {
        "name": "NS_E_NO_PDA",
        "explanation": "Windows Media Player does not detect a portable device. Connect your portable device, and then try again.",
    },
    "0xC00D117A": {
        "name": "NS_E_PDA_UNSPECIFIED_ERROR",
        "explanation": "Windows Media Player encountered an error while communicating with the device. The storage card on the device might be full, the device might be turned off, or the device might not allow playlists or folders to be created on it.",
    },
    "0xC00D117B": {
        "name": "NS_E_MEMSTORAGE_BAD_DATA",
        "explanation": "Windows Media Player encountered an error while burning a CD.",
    },
    "0xC00D117C": {
        "name": "NS_E_PDA_FAIL_SELECT_DEVICE",
        "explanation": "Windows Media Player encountered an error while communicating with a portable device or CD drive.",
    },
    "0xC00D117D": {
        "name": "NS_E_PDA_FAIL_READ_WAVE_FILE",
        "explanation": "Windows Media Player cannot open the WAV file.",
    },
    "0xC00D117E": {
        "name": "NS_E_IMAPI_LOSSOFSTREAMING",
        "explanation": "Windows Media Player failed to burn all the files to the CD. Select a slower recording speed, and then try again.",
    },
    "0xC00D117F": {
        "name": "NS_E_PDA_DEVICE_FULL",
        "explanation": "There is not enough storage space on the portable device to complete this operation. Delete some unneeded files on the portable device, and then try again.",
    },
    "0xC00D1180": {
        "name": "NS_E_FAIL_LAUNCH_ROXIO_PLUGIN",
        "explanation": "Windows Media Player cannot burn the files. Verify that your burner is connected properly, and then try again. If the problem persists, reinstall the Player.",
    },
    "0xC00D1181": {
        "name": "NS_E_PDA_DEVICE_FULL_IN_SESSION",
        "explanation": "Windows Media Player did not sync some files to the device because there is not enough storage space on the device.",
    },
    "0xC00D1182": {
        "name": "NS_E_IMAPI_MEDIUM_INVALIDTYPE",
        "explanation": "The disc in the burner is not valid. Insert a blank disc into the burner, and then try again.",
    },
    "0xC00D1183": {
        "name": "NS_E_PDA_MANUALDEVICE",
        "explanation": "Windows Media Player cannot perform the requested action because the device does not support sync.",
    },
    "0xC00D1184": {
        "name": "NS_E_PDA_PARTNERSHIPNOTEXIST",
        "explanation": "To perform the requested action, you must first set up sync with the device.",
    },
    "0xC00D1185": {
        "name": "NS_E_PDA_CANNOT_CREATE_ADDITIONAL_SYNC_RELATIONSHIP",
        "explanation": "You have already created sync partnerships with 16 devices. To create a new sync partnership, you must first end an existing partnership.",
    },
    "0xC00D1186": {
        "name": "NS_E_PDA_NO_TRANSCODE_OF_DRM",
        "explanation": "Windows Media Player cannot sync the file because protected files cannot be converted to the required quality level or file format.",
    },
    "0xC00D1187": {
        "name": "NS_E_PDA_TRANSCODECACHEFULL",
        "explanation": "The folder that stores converted files is full. Either empty the folder or increase its size, and then try again.",
    },
    "0xC00D1188": {
        "name": "NS_E_PDA_TOO_MANY_FILE_COLLISIONS",
        "explanation": "There are too many files with the same name in the folder on the device. Change the file name or sync to a different folder.",
    },
    "0xC00D1189": {
        "name": "NS_E_PDA_CANNOT_TRANSCODE",
        "explanation": "Windows Media Player cannot convert the file to the format required by the device.",
    },
    "0xC00D118A": {
        "name": "NS_E_PDA_TOO_MANY_FILES_IN_DIRECTORY",
        "explanation": "You have reached the maximum number of files your device allows in a folder. If your device supports playback from subfolders, try creating subfolders on the device and storing some files in them.",
    },
    "0xC00D118B": {
        "name": "NS_E_PROCESSINGSHOWSYNCWIZARD",
        "explanation": "Windows Media Player is already trying to start the Device Setup Wizard.",
    },
    "0xC00D118C": {
        "name": "NS_E_PDA_TRANSCODE_NOT_PERMITTED",
        "explanation": "Windows Media Player cannot convert this file format. If an updated version of the codec used to compress this file is available, install it and then try to sync the file again.",
    },
    "0xC00D118D": {
        "name": "NS_E_PDA_INITIALIZINGDEVICES",
        "explanation": "Windows Media Player is busy setting up devices. Try again later.",
    },
    "0xC00D118E": {
        "name": "NS_E_PDA_OBSOLETE_SP",
        "explanation": "Your device is using an outdated driver that is no longer supported by Windows Media Player. For additional assistance, click Web Help.",
    },
    "0xC00D118F": {
        "name": "NS_E_PDA_TITLE_COLLISION",
        "explanation": "Windows Media Player cannot sync the file because a file with the same name already exists on the device. Change the file name or try to sync the file to a different folder.",
    },
    "0xC00D1190": {
        "name": "NS_E_PDA_DEVICESUPPORTDISABLED",
        "explanation": "Automatic and manual sync have been turned off temporarily. To sync to a device, restart Windows Media Player.",
    },
    "0xC00D1191": {
        "name": "NS_E_PDA_NO_LONGER_AVAILABLE",
        "explanation": "This device is not available. Connect the device to the computer, and then try again.",
    },
    "0xC00D1192": {
        "name": "NS_E_PDA_ENCODER_NOT_RESPONDING",
        "explanation": "Windows Media Player cannot sync the file because an error occurred while converting the file to another quality level or format. If the problem persists, remove the file from the list of files to sync.",
    },
    "0xC00D1193": {
        "name": "NS_E_PDA_CANNOT_SYNC_FROM_LOCATION",
        "explanation": "Windows Media Player cannot sync the file to your device. The file might be stored in a location that is not supported. Copy the file from its current location to your hard disk, add it to your library, and then try to sync the file again.",
    },
    "0xC00D1194": {
        "name": "NS_E_WMP_PROTOCOL_PROBLEM",
        "explanation": "Windows Media Player cannot open the specified URL. Verify that the Player is configured to use all available protocols, and then try again.",
    },
    "0xC00D1195": {
        "name": "NS_E_WMP_NO_DISK_SPACE",
        "explanation": "Windows Media Player cannot perform the requested action because there is not enough storage space on your computer. Delete some unneeded files on your hard disk, and then try again.",
    },
    "0xC00D1196": {
        "name": "NS_E_WMP_LOGON_FAILURE",
        "explanation": "The server denied access to the file. Verify that you are using the correct user name and password.",
    },
    "0xC00D1197": {
        "name": "NS_E_WMP_CANNOT_FIND_FILE",
        "explanation": "Windows Media Player cannot find the file. If you are trying to play, burn, or sync an item that is in your library, the item might point to a file that has been moved, renamed, or deleted.",
    },
    "0xC00D1198": {
        "name": "NS_E_WMP_SERVER_INACCESSIBLE",
        "explanation": "Windows Media Player cannot connect to the server. The server name might not be correct, the server might not be available, or your proxy settings might not be correct.",
    },
    "0xC00D1199": {
        "name": "NS_E_WMP_UNSUPPORTED_FORMAT",
        "explanation": "Windows Media Player cannot play the file. The Player might not support the file type or might not support the codec that was used to compress the file.",
    },
    "0xC00D119A": {
        "name": "NS_E_WMP_DSHOW_UNSUPPORTED_FORMAT",
        "explanation": "Windows Media Player cannot play the file. The Player might not support the file type or a required codec might not be installed on your computer.",
    },
    "0xC00D119B": {
        "name": "NS_E_WMP_PLAYLIST_EXISTS",
        "explanation": "Windows Media Player cannot create the playlist because the name already exists. Type a different playlist name.",
    },
    "0xC00D119C": {
        "name": "NS_E_WMP_NONMEDIA_FILES",
        "explanation": "Windows Media Player cannot delete the playlist because it contains items that are not digital media files. Any digital media files in the playlist were deleted.",
    },
    "0xC00D119D": {
        "name": "NS_E_WMP_INVALID_ASX",
        "explanation": "The playlist cannot be opened because it is stored in a shared folder on another computer. If possible, move the playlist to the playlists folder on your computer.",
    },
    "0xC00D119E": {
        "name": "NS_E_WMP_ALREADY_IN_USE",
        "explanation": "Windows Media Player is already in use. Stop playing any items, close all Player dialog boxes, and then try again.",
    },
    "0xC00D119F": {
        "name": "NS_E_WMP_IMAPI_FAILURE",
        "explanation": "Windows Media Player encountered an error while burning. Verify that the burner is connected properly and that the disc is clean and not damaged.",
    },
    "0xC00D11A0": {
        "name": "NS_E_WMP_WMDM_FAILURE",
        "explanation": "Windows Media Player has encountered an unknown error with your portable device. Reconnect your portable device, and then try again.",
    },
    "0xC00D11A1": {
        "name": "NS_E_WMP_CODEC_NEEDED_WITH_4CC",
        "explanation": "A codec is required to play this file. To determine if this codec is available to download from the web, click Web Help.",
    },
    "0xC00D11A2": {
        "name": "NS_E_WMP_CODEC_NEEDED_WITH_FORMATTAG",
        "explanation": "An audio codec is needed to play this file. To determine if this codec is available to download from the web, click Web Help.",
    },
    "0xC00D11A3": {
        "name": "NS_E_WMP_MSSAP_NOT_AVAILABLE",
        "explanation": "To play the file, you must install the latest Windows service pack. To install the service pack from the Windows Update website, click Web Help.",
    },
    "0xC00D11A4": {
        "name": "NS_E_WMP_WMDM_INTERFACEDEAD",
        "explanation": "Windows Media Player no longer detects a portable device. Reconnect your portable device, and then try again.",
    },
    "0xC00D11A5": {
        "name": "NS_E_WMP_WMDM_NOTCERTIFIED",
        "explanation": "Windows Media Player cannot sync the file because the portable device does not support protected files.",
    },
    "0xC00D11A6": {
        "name": "NS_E_WMP_WMDM_LICENSE_NOTEXIST",
        "explanation": "This file does not have sync rights. If you obtained this file from an online store, go to the online store to get sync rights.",
    },
    "0xC00D11A7": {
        "name": "NS_E_WMP_WMDM_LICENSE_EXPIRED",
        "explanation": "Windows Media Player cannot sync the file because the sync rights have expired. Go to the content provider's online store to get new sync rights.",
    },
    "0xC00D11A8": {
        "name": "NS_E_WMP_WMDM_BUSY",
        "explanation": "The portable device is already in use. Wait until the current task finishes or quit other programs that might be using the portable device, and then try again.",
    },
    "0xC00D11A9": {
        "name": "NS_E_WMP_WMDM_NORIGHTS",
        "explanation": "Windows Media Player cannot sync the file because the content provider or device prohibits it. You might be able to resolve this problem by going to the content provider's online store to get sync rights.",
    },
    "0xC00D11AA": {
        "name": "NS_E_WMP_WMDM_INCORRECT_RIGHTS",
        "explanation": "The content provider has not granted you the right to sync this file. Go to the content provider's online store to get sync rights.",
    },
    "0xC00D11AB": {
        "name": "NS_E_WMP_IMAPI_GENERIC",
        "explanation": "Windows Media Player cannot burn the files to the CD. Verify that the disc is clean and not damaged. If necessary, select a slower recording speed or try a different brand of blank discs.",
    },
    "0xC00D11AD": {
        "name": "NS_E_WMP_IMAPI_DEVICE_NOTPRESENT",
        "explanation": "Windows Media Player cannot burn the files. Verify that the burner is connected properly, and then try again.",
    },
    "0xC00D11AE": {
        "name": "NS_E_WMP_IMAPI_DEVICE_BUSY",
        "explanation": "Windows Media Player cannot burn the files. Verify that the burner is connected properly and that the disc is clean and not damaged. If the burner is already in use, wait until the current task finishes or quit other programs that might be using the burner.",
    },
    "0xC00D11AF": {
        "name": "NS_E_WMP_IMAPI_LOSS_OF_STREAMING",
        "explanation": "Windows Media Player cannot burn the files to the CD.",
    },
    "0xC00D11B0": {
        "name": "NS_E_WMP_SERVER_UNAVAILABLE",
        "explanation": "Windows Media Player cannot play the file. The server might not be available or there might be a problem with your network or firewall settings.",
    },
    "0xC00D11B1": {
        "name": "NS_E_WMP_FILE_OPEN_FAILED",
        "explanation": "Windows Media Player encountered a problem while playing the file. For additional assistance, click Web Help.",
    },
    "0xC00D11B2": {
        "name": "NS_E_WMP_VERIFY_ONLINE",
        "explanation": "Windows Media Player must connect to the Internet to verify the file's media usage rights. Connect to the Internet, and then try again.",
    },
    "0xC00D11B3": {
        "name": "NS_E_WMP_SERVER_NOT_RESPONDING",
        "explanation": "Windows Media Player cannot play the file because a network error occurred. The server might not be available. Verify that you are connected to the network and that your proxy settings are correct.",
    },
    "0xC00D11B4": {
        "name": "NS_E_WMP_DRM_CORRUPT_BACKUP",
        "explanation": "Windows Media Player cannot restore your media usage rights because it could not find any backed up rights on your computer.",
    },
    "0xC00D11B5": {
        "name": "NS_E_WMP_DRM_LICENSE_SERVER_UNAVAILABLE",
        "explanation": "Windows Media Player cannot download media usage rights because the server is not available (for example, the server might be busy or not online).",
    },
    "0xC00D11B6": {
        "name": "NS_E_WMP_NETWORK_FIREWALL",
        "explanation": 'Windows Media Player cannot play the file. A network firewall might be preventing the Player from opening the file by using the UDP transport protocol. If you typed a URL in the Open URL dialog box, try using a different transport protocol (for example, "http:").',
    },
    "0xC00D11B7": {
        "name": "NS_E_WMP_NO_REMOVABLE_MEDIA",
        "explanation": "Insert the removable media, and then try again.",
    },
    "0xC00D11B8": {
        "name": "NS_E_WMP_PROXY_CONNECT_TIMEOUT",
        "explanation": "Windows Media Player cannot play the file because the proxy server is not responding. The proxy server might be temporarily unavailable or your Player proxy settings might not be valid.",
    },
    "0xC00D11B9": {
        "name": "NS_E_WMP_NEED_UPGRADE",
        "explanation": "To play the file, you might need to install a later version of Windows Media Player. On the Help menu, click Check for Updates, and then follow the instructions. For additional assistance, click Web Help.",
    },
    "0xC00D11BA": {
        "name": "NS_E_WMP_AUDIO_HW_PROBLEM",
        "explanation": "Windows Media Player cannot play the file because there is a problem with your sound device. There might not be a sound device installed on your computer, it might be in use by another program, or it might not be functioning properly.",
    },
    "0xC00D11BB": {
        "name": "NS_E_WMP_INVALID_PROTOCOL",
        "explanation": 'Windows Media Player cannot play the file because the specified protocol is not supported. If you typed a URL in the Open URL dialog box, try using a different transport protocol (for example, "http:" or "rtsp:").',
    },
    "0xC00D11BC": {
        "name": "NS_E_WMP_INVALID_LIBRARY_ADD",
        "explanation": "Windows Media Player cannot add the file to the library because the file format is not supported.",
    },
    "0xC00D11BD": {
        "name": "NS_E_WMP_MMS_NOT_SUPPORTED",
        "explanation": 'Windows Media Player cannot play the file because the specified protocol is not supported. If you typed a URL in the Open URL dialog box, try using a different transport protocol (for example, "mms:").',
    },
    "0xC00D11BE": {
        "name": "NS_E_WMP_NO_PROTOCOLS_SELECTED",
        "explanation": "Windows Media Player cannot play the file because there are no streaming protocols selected. Select one or more protocols, and then try again.",
    },
    "0xC00D11BF": {
        "name": "NS_E_WMP_GOFULLSCREEN_FAILED",
        "explanation": "Windows Media Player cannot switch to Full Screen. You might need to adjust your Windows display settings. Open display settings in Control Panel, and then try setting Hardware acceleration to Full.",
    },
    "0xC00D11C0": {
        "name": "NS_E_WMP_NETWORK_ERROR",
        "explanation": "Windows Media Player cannot play the file because a network error occurred. The server might not be available (for example, the server is busy or not online) or you might not be connected to the network.",
    },
    "0xC00D11C1": {
        "name": "NS_E_WMP_CONNECT_TIMEOUT",
        "explanation": "Windows Media Player cannot play the file because the server is not responding. Verify that you are connected to the network, and then try again later.",
    },
    "0xC00D11C2": {
        "name": "NS_E_WMP_MULTICAST_DISABLED",
        "explanation": "Windows Media Player cannot play the file because the multicast protocol is not enabled. On the Tools menu, click Options, click the Network tab, and then select the Multicast check box. For additional assistance, click Web Help.",
    },
    "0xC00D11C3": {
        "name": "NS_E_WMP_SERVER_DNS_TIMEOUT",
        "explanation": "Windows Media Player cannot play the file because a network problem occurred. Verify that you are connected to the network, and then try again later.",
    },
    "0xC00D11C4": {
        "name": "NS_E_WMP_PROXY_NOT_FOUND",
        "explanation": "Windows Media Player cannot play the file because the network proxy server cannot be found. Verify that your proxy settings are correct, and then try again.",
    },
    "0xC00D11C5": {
        "name": "NS_E_WMP_TAMPERED_CONTENT",
        "explanation": "Windows Media Player cannot play the file because it is corrupted.",
    },
    "0xC00D11C6": {
        "name": "NS_E_WMP_OUTOFMEMORY",
        "explanation": "Your computer is running low on memory. Quit other programs, and then try again.",
    },
    "0xC00D11C7": {
        "name": "NS_E_WMP_AUDIO_CODEC_NOT_INSTALLED",
        "explanation": "Windows Media Player cannot play, burn, rip, or sync the file because a required audio codec is not installed on your computer.",
    },
    "0xC00D11C8": {
        "name": "NS_E_WMP_VIDEO_CODEC_NOT_INSTALLED",
        "explanation": "Windows Media Player cannot play the file because the required video codec is not installed on your computer.",
    },
    "0xC00D11C9": {
        "name": "NS_E_WMP_IMAPI_DEVICE_INVALIDTYPE",
        "explanation": "Windows Media Player cannot burn the files. If the burner is busy, wait for the current task to finish. If necessary, verify that the burner is connected properly and that you have installed the latest device driver.",
    },
    "0xC00D11CA": {
        "name": "NS_E_WMP_DRM_DRIVER_AUTH_FAILURE",
        "explanation": "Windows Media Player cannot play the protected file because there is a problem with your sound device. Try installing a new device driver or use a different sound device.",
    },
    "0xC00D11CB": {
        "name": "NS_E_WMP_NETWORK_RESOURCE_FAILURE",
        "explanation": "Windows Media Player encountered a network error. Restart the Player.",
    },
    "0xC00D11CC": {
        "name": "NS_E_WMP_UPGRADE_APPLICATION",
        "explanation": "Windows Media Player is not installed properly. Reinstall the Player.",
    },
    "0xC00D11CD": {
        "name": "NS_E_WMP_UNKNOWN_ERROR",
        "explanation": "Windows Media Player encountered an unknown error. For additional assistance, click Web Help.",
    },
    "0xC00D11CE": {
        "name": "NS_E_WMP_INVALID_KEY",
        "explanation": "Windows Media Player cannot play the file because the required codec is not valid.",
    },
    "0xC00D11CF": {
        "name": "NS_E_WMP_CD_ANOTHER_USER",
        "explanation": "The CD drive is in use by another user. Wait for the task to complete, and then try again.",
    },
    "0xC00D11D0": {
        "name": "NS_E_WMP_DRM_NEEDS_AUTHORIZATION",
        "explanation": "Windows Media Player cannot play, sync, or burn the protected file because a problem occurred with the Windows Media Digital Rights Management (DRM) system. You might need to connect to the Internet to update your DRM components. For additional assistance, click Web Help.",
    },
    "0xC00D11D1": {
        "name": "NS_E_WMP_BAD_DRIVER",
        "explanation": "Windows Media Player cannot play the file because there might be a problem with your sound or video device. Try installing an updated device driver.",
    },
    "0xC00D11D2": {
        "name": "NS_E_WMP_ACCESS_DENIED",
        "explanation": "Windows Media Player cannot access the file. The file might be in use, you might not have access to the computer where the file is stored, or your proxy settings might not be correct.",
    },
    "0xC00D11D3": {
        "name": "NS_E_WMP_LICENSE_RESTRICTS",
        "explanation": "The content provider prohibits this action. Go to the content provider's online store to get new media usage rights.",
    },
    "0xC00D11D4": {
        "name": "NS_E_WMP_INVALID_REQUEST",
        "explanation": "Windows Media Player cannot perform the requested action at this time.",
    },
    "0xC00D11D5": {
        "name": "NS_E_WMP_CD_STASH_NO_SPACE",
        "explanation": "Windows Media Player cannot burn the files because there is not enough free disk space to store the temporary files. Delete some unneeded files on your hard disk, and then try again.",
    },
    "0xC00D11D6": {
        "name": "NS_E_WMP_DRM_NEW_HARDWARE",
        "explanation": "Your media usage rights have become corrupted or are no longer valid. This might happen if you have replaced hardware components in your computer.",
    },
    "0xC00D11D7": {
        "name": "NS_E_WMP_DRM_INVALID_SIG",
        "explanation": "The required Windows Media Digital Rights Management (DRM) component cannot be validated. You might be able resolve the problem by reinstalling the Player.",
    },
    "0xC00D11D8": {
        "name": "NS_E_WMP_DRM_CANNOT_RESTORE",
        "explanation": "You have exceeded your restore limit for the day. Try restoring your media usage rights tomorrow.",
    },
    "0xC00D11D9": {
        "name": "NS_E_WMP_BURN_DISC_OVERFLOW",
        "explanation": "Some files might not fit on the CD. The required space cannot be calculated accurately because some files might be missing duration information. To ensure the calculation is accurate, play the files that are missing duration information.",
    },
    "0xC00D11DA": {
        "name": "NS_E_WMP_DRM_GENERIC_LICENSE_FAILURE",
        "explanation": "Windows Media Player cannot verify the file's media usage rights. If you obtained this file from an online store, go to the online store to get the necessary rights.",
    },
    "0xC00D11DB": {
        "name": "NS_E_WMP_DRM_NO_SECURE_CLOCK",
        "explanation": "It is not possible to sync because this device's internal clock is not set correctly. To set the clock, select the option to set the device clock on the Privacy tab of the Options dialog box, connect to the Internet, and then sync the device again. For additional assistance, click Web Help.",
    },
    "0xC00D11DC": {
        "name": "NS_E_WMP_DRM_NO_RIGHTS",
        "explanation": "Windows Media Player cannot play, burn, rip, or sync the protected file because you do not have the appropriate rights.",
    },
    "0xC00D11DD": {
        "name": "NS_E_WMP_DRM_INDIV_FAILED",
        "explanation": "Windows Media Player encountered an error during upgrade.",
    },
    "0xC00D11DE": {
        "name": "NS_E_WMP_SERVER_NONEWCONNECTIONS",
        "explanation": "Windows Media Player cannot connect to the server because it is not accepting any new connections. This could be because it has reached its maximum connection limit. Please try again later.",
    },
    "0xC00D11DF": {
        "name": "NS_E_WMP_MULTIPLE_ERROR_IN_PLAYLIST",
        "explanation": "A number of queued files cannot be played. To find information about the problem, click the Now Playing tab, and then click the icon next to each file in the List pane.",
    },
    "0xC00D11E0": {
        "name": "NS_E_WMP_IMAPI2_ERASE_FAIL",
        "explanation": "Windows Media Player encountered an error while erasing the rewritable CD or DVD. Verify that the CD or DVD burner is connected properly and that the disc is clean and not damaged.",
    },
    "0xC00D11E1": {
        "name": "NS_E_WMP_IMAPI2_ERASE_DEVICE_BUSY",
        "explanation": "Windows Media Player cannot erase the rewritable CD or DVD. Verify that the CD or DVD burner is connected properly and that the disc is clean and not damaged. If the burner is already in use, wait until the current task finishes or quit other programs that might be using the burner.",
    },
    "0xC00D11E2": {
        "name": "NS_E_WMP_DRM_COMPONENT_FAILURE",
        "explanation": "A Windows Media Digital Rights Management (DRM) component encountered a problem. If you are trying to use a file that you obtained from an online store, try going to the online store and getting the appropriate usage rights.",
    },
    "0xC00D11E3": {
        "name": "NS_E_WMP_DRM_NO_DEVICE_CERT",
        "explanation": "It is not possible to obtain device's certificate. Please contact the device manufacturer for a firmware update or for other steps to resolve this problem.",
    },
    "0xC00D11E4": {
        "name": "NS_E_WMP_SERVER_SECURITY_ERROR",
        "explanation": "Windows Media Player encountered an error when connecting to the server. The security information from the server could not be validated.",
    },
    "0xC00D11E5": {
        "name": "NS_E_WMP_AUDIO_DEVICE_LOST",
        "explanation": "An audio device was disconnected or reconfigured. Verify that the audio device is connected, and then try to play the item again.",
    },
    "0xC00D11E6": {
        "name": "NS_E_WMP_IMAPI_MEDIA_INCOMPATIBLE",
        "explanation": "Windows Media Player could not complete burning because the disc is not compatible with your drive. Try inserting a different kind of recordable media or use a disc that supports a write speed that is compatible with your drive.",
    },
    "0xC00D11EE": {
        "name": "NS_E_SYNCWIZ_DEVICE_FULL",
        "explanation": "Windows Media Player cannot save the sync settings because your device is full. Delete some unneeded files on your device and then try again.",
    },
    "0xC00D11EF": {
        "name": "NS_E_SYNCWIZ_CANNOT_CHANGE_SETTINGS",
        "explanation": "It is not possible to change sync settings at this time. Try again later.",
    },
    "0xC00D11F0": {
        "name": "NS_E_TRANSCODE_DELETECACHEERROR",
        "explanation": "Windows Media Player cannot delete these files currently. If the Player is synchronizing, wait until it is complete and then try again.",
    },
    "0xC00D11F8": {
        "name": "NS_E_CD_NO_BUFFERS_READ",
        "explanation": "Windows Media Player could not use digital mode to read the CD. The Player has automatically switched the CD drive to analog mode. To switch back to digital mode, use the Devices tab. For additional assistance, click Web Help.",
    },
    "0xC00D11F9": {"name": "NS_E_CD_EMPTY_TRACK_QUEUE", "explanation": "No CD track was specified for playback."},
    "0xC00D11FA": {"name": "NS_E_CD_NO_READER", "explanation": "The CD filter was not able to create the CD reader."},
    "0xC00D11FB": {"name": "NS_E_CD_ISRC_INVALID", "explanation": "Invalid ISRC code."},
    "0xC00D11FC": {"name": "NS_E_CD_MEDIA_CATALOG_NUMBER_INVALID", "explanation": "Invalid Media Catalog Number."},
    "0xC00D11FD": {
        "name": "NS_E_SLOW_READ_DIGITAL_WITH_ERRORCORRECTION",
        "explanation": "Windows Media Player cannot play audio CDs correctly because the CD drive is slow and error correction is turned on. To increase performance, turn off playback error correction for this drive.",
    },
    "0xC00D11FE": {
        "name": "NS_E_CD_SPEEDDETECT_NOT_ENOUGH_READS",
        "explanation": "Windows Media Player cannot estimate the CD drive's playback speed because the CD track is too short.",
    },
    "0xC00D11FF": {
        "name": "NS_E_CD_QUEUEING_DISABLED",
        "explanation": "Cannot queue the CD track because queuing is not enabled.",
    },
    "0xC00D1202": {
        "name": "NS_E_WMP_DRM_ACQUIRING_LICENSE",
        "explanation": "Windows Media Player cannot download additional media usage rights until the current download is complete.",
    },
    "0xC00D1203": {
        "name": "NS_E_WMP_DRM_LICENSE_EXPIRED",
        "explanation": "The media usage rights for this file have expired or are no longer valid. If you obtained the file from an online store, sign in to the store, and then try again.",
    },
    "0xC00D1204": {
        "name": "NS_E_WMP_DRM_LICENSE_NOTACQUIRED",
        "explanation": "Windows Media Player cannot download the media usage rights for the file. If you obtained the file from an online store, sign in to the store, and then try again.",
    },
    "0xC00D1205": {
        "name": "NS_E_WMP_DRM_LICENSE_NOTENABLED",
        "explanation": "The media usage rights for this file are not yet valid. To see when they will become valid, right-click the file in the library, click Properties, and then click the Media Usage Rights tab.",
    },
    "0xC00D1206": {
        "name": "NS_E_WMP_DRM_LICENSE_UNUSABLE",
        "explanation": "The media usage rights for this file are not valid. If you obtained this file from an online store, contact the store for assistance.",
    },
    "0xC00D1207": {
        "name": "NS_E_WMP_DRM_LICENSE_CONTENT_REVOKED",
        "explanation": "The content provider has revoked the media usage rights for this file. If you obtained this file from an online store, ask the store if a new version of the file is available.",
    },
    "0xC00D1208": {
        "name": "NS_E_WMP_DRM_LICENSE_NOSAP",
        "explanation": "The media usage rights for this file require a feature that is not supported in your current version of Windows Media Player or your current version of Windows. Try installing the latest version of the Player. If you obtained this file from an online store, contact the store for further assistance.",
    },
    "0xC00D1209": {
        "name": "NS_E_WMP_DRM_UNABLE_TO_ACQUIRE_LICENSE",
        "explanation": "Windows Media Player cannot download media usage rights at this time. Try again later.",
    },
    "0xC00D120A": {
        "name": "NS_E_WMP_LICENSE_REQUIRED",
        "explanation": "Windows Media Player cannot play, burn, or sync the file because the media usage rights are missing. If you obtained the file from an online store, sign in to the store, and then try again.",
    },
    "0xC00D120B": {
        "name": "NS_E_WMP_PROTECTED_CONTENT",
        "explanation": "Windows Media Player cannot play, burn, or sync the file because the media usage rights are missing. If you obtained the file from an online store, sign in to the store, and then try again.",
    },
    "0xC00D122A": {
        "name": "NS_E_WMP_POLICY_VALUE_NOT_CONFIGURED",
        "explanation": "Windows Media Player cannot read a policy. This can occur when the policy does not exist in the registry or when the registry cannot be read.",
    },
    "0xC00D1234": {
        "name": "NS_E_PDA_CANNOT_SYNC_FROM_INTERNET",
        "explanation": "Windows Media Player cannot sync content streamed directly from the Internet. If possible, download the file to your computer, and then try to sync the file.",
    },
    "0xC00D1235": {
        "name": "NS_E_PDA_CANNOT_SYNC_INVALID_PLAYLIST",
        "explanation": "This playlist is not valid or is corrupted. Create a new playlist using Windows Media Player, then sync the new playlist instead.",
    },
    "0xC00D1236": {
        "name": "NS_E_PDA_FAILED_TO_SYNCHRONIZE_FILE",
        "explanation": "Windows Media Player encountered a problem while synchronizing the file to the device. For additional assistance, click Web Help.",
    },
    "0xC00D1237": {
        "name": "NS_E_PDA_SYNC_FAILED",
        "explanation": "Windows Media Player encountered an error while synchronizing to the device.",
    },
    "0xC00D1238": {
        "name": "NS_E_PDA_DELETE_FAILED",
        "explanation": "Windows Media Player cannot delete a file from the device.",
    },
    "0xC00D1239": {
        "name": "NS_E_PDA_FAILED_TO_RETRIEVE_FILE",
        "explanation": "Windows Media Player cannot copy a file from the device to your library.",
    },
    "0xC00D123A": {
        "name": "NS_E_PDA_DEVICE_NOT_RESPONDING",
        "explanation": "Windows Media Player cannot communicate with the device because the device is not responding. Try reconnecting the device, resetting the device, or contacting the device manufacturer for updated firmware.",
    },
    "0xC00D123B": {
        "name": "NS_E_PDA_FAILED_TO_TRANSCODE_PHOTO",
        "explanation": "Windows Media Player cannot sync the picture to the device because a problem occurred while converting the file to another quality level or format. The original file might be damaged or corrupted.",
    },
    "0xC00D123C": {
        "name": "NS_E_PDA_FAILED_TO_ENCRYPT_TRANSCODED_FILE",
        "explanation": "Windows Media Player cannot convert the file. The file might have been encrypted by the Encrypted File System (EFS). Try decrypting the file first and then synchronizing it. For information about how to decrypt a file, see Windows Help and Support.",
    },
    "0xC00D123D": {
        "name": "NS_E_PDA_CANNOT_TRANSCODE_TO_AUDIO",
        "explanation": "Your device requires that this file be converted in order to play on the device. However, the device either does not support playing audio, or Windows Media Player cannot convert the file to an audio format that is supported by the device.",
    },
    "0xC00D123E": {
        "name": "NS_E_PDA_CANNOT_TRANSCODE_TO_VIDEO",
        "explanation": "Your device requires that this file be converted in order to play on the device. However, the device either does not support playing video, or Windows Media Player cannot convert the file to a video format that is supported by the device.",
    },
    "0xC00D123F": {
        "name": "NS_E_PDA_CANNOT_TRANSCODE_TO_IMAGE",
        "explanation": "Your device requires that this file be converted in order to play on the device. However, the device either does not support displaying pictures, or Windows Media Player cannot convert the file to a picture format that is supported by the device.",
    },
    "0xC00D1240": {
        "name": "NS_E_PDA_RETRIEVED_FILE_FILENAME_TOO_LONG",
        "explanation": "Windows Media Player cannot sync the file to your computer because the file name is too long. Try renaming the file on the device.",
    },
    "0xC00D1241": {
        "name": "NS_E_PDA_CEWMDM_DRM_ERROR",
        "explanation": "Windows Media Player cannot sync the file because the device is not responding. This typically occurs when there is a problem with the device firmware. For additional assistance, click Web Help.",
    },
    "0xC00D1242": {"name": "NS_E_INCOMPLETE_PLAYLIST", "explanation": "Incomplete playlist."},
    "0xC00D1243": {
        "name": "NS_E_PDA_SYNC_RUNNING",
        "explanation": "It is not possible to perform the requested action because sync is in progress. You can either stop sync or wait for it to complete, and then try again.",
    },
    "0xC00D1244": {
        "name": "NS_E_PDA_SYNC_LOGIN_ERROR",
        "explanation": "Windows Media Player cannot sync the subscription content because you are not signed in to the online store that provided it. Sign in to the online store, and then try again.",
    },
    "0xC00D1245": {
        "name": "NS_E_PDA_TRANSCODE_CODEC_NOT_FOUND",
        "explanation": "Windows Media Player cannot convert the file to the format required by the device. One or more codecs required to convert the file could not be found.",
    },
    "0xC00D1246": {
        "name": "NS_E_CANNOT_SYNC_DRM_TO_NON_JANUS_DEVICE",
        "explanation": "It is not possible to sync subscription files to this device.",
    },
    "0xC00D1247": {
        "name": "NS_E_CANNOT_SYNC_PREVIOUS_SYNC_RUNNING",
        "explanation": "Your device is operating slowly or is not responding. Until the device responds, it is not possible to sync again. To return the device to normal operation, try disconnecting it from the computer or resetting it.",
    },
    "0xC00D125C": {
        "name": "NS_E_WMP_HWND_NOTFOUND",
        "explanation": "The Windows Media Player download manager cannot function properly because the Player main window cannot be found. Try restarting the Player.",
    },
    "0xC00D125D": {
        "name": "NS_E_BKGDOWNLOAD_WRONG_NO_FILES",
        "explanation": "Windows Media Player encountered a download that has the wrong number of files. This might occur if another program is trying to create jobs with the same signature as the Player.",
    },
    "0xC00D125E": {
        "name": "NS_E_BKGDOWNLOAD_COMPLETECANCELLEDJOB",
        "explanation": "Windows Media Player tried to complete a download that was already canceled. The file will not be available.",
    },
    "0xC00D125F": {
        "name": "NS_E_BKGDOWNLOAD_CANCELCOMPLETEDJOB",
        "explanation": "Windows Media Player tried to cancel a download that was already completed. The file will not be removed.",
    },
    "0xC00D1260": {
        "name": "NS_E_BKGDOWNLOAD_NOJOBPOINTER",
        "explanation": "Windows Media Player is trying to access a download that is not valid.",
    },
    "0xC00D1261": {
        "name": "NS_E_BKGDOWNLOAD_INVALIDJOBSIGNATURE",
        "explanation": "This download was not created by Windows Media Player.",
    },
    "0xC00D1262": {
        "name": "NS_E_BKGDOWNLOAD_FAILED_TO_CREATE_TEMPFILE",
        "explanation": "The Windows Media Player download manager cannot create a temporary file name. This might occur if the path is not valid or if the disk is full.",
    },
    "0xC00D1263": {
        "name": "NS_E_BKGDOWNLOAD_PLUGIN_FAILEDINITIALIZE",
        "explanation": "The Windows Media Player download manager plug-in cannot start. This might occur if the system is out of resources.",
    },
    "0xC00D1264": {
        "name": "NS_E_BKGDOWNLOAD_PLUGIN_FAILEDTOMOVEFILE",
        "explanation": "The Windows Media Player download manager cannot move the file.",
    },
    "0xC00D1265": {
        "name": "NS_E_BKGDOWNLOAD_CALLFUNCFAILED",
        "explanation": "The Windows Media Player download manager cannot perform a task because the system has no resources to allocate.",
    },
    "0xC00D1266": {
        "name": "NS_E_BKGDOWNLOAD_CALLFUNCTIMEOUT",
        "explanation": "The Windows Media Player download manager cannot perform a task because the task took too long to run.",
    },
    "0xC00D1267": {
        "name": "NS_E_BKGDOWNLOAD_CALLFUNCENDED",
        "explanation": "The Windows Media Player download manager cannot perform a task because the Player is terminating the service. The task will be recovered when the Player restarts.",
    },
    "0xC00D1268": {
        "name": "NS_E_BKGDOWNLOAD_WMDUNPACKFAILED",
        "explanation": "The Windows Media Player download manager cannot expand a WMD file. The file will be deleted and the operation will not be completed successfully.",
    },
    "0xC00D1269": {
        "name": "NS_E_BKGDOWNLOAD_FAILEDINITIALIZE",
        "explanation": "The Windows Media Player download manager cannot start. This might occur if the system is out of resources.",
    },
    "0xC00D126A": {
        "name": "NS_E_INTERFACE_NOT_REGISTERED_IN_GIT",
        "explanation": "Windows Media Player cannot access a required functionality. This might occur if the wrong system files or Player DLLs are loaded.",
    },
    "0xC00D126B": {
        "name": "NS_E_BKGDOWNLOAD_INVALID_FILE_NAME",
        "explanation": "Windows Media Player cannot get the file name of the requested download. The requested download will be canceled.",
    },
    "0xC00D128E": {
        "name": "NS_E_IMAGE_DOWNLOAD_FAILED",
        "explanation": "Windows Media Player encountered an error while downloading an image.",
    },
    "0xC00D12C0": {
        "name": "NS_E_WMP_UDRM_NOUSERLIST",
        "explanation": "Windows Media Player cannot update your media usage rights because the Player cannot verify the list of activated users of this computer.",
    },
    "0xC00D12C1": {
        "name": "NS_E_WMP_DRM_NOT_ACQUIRING",
        "explanation": "Windows Media Player is trying to acquire media usage rights for a file that is no longer being used. Rights acquisition will stop.",
    },
    "0xC00D12F2": {"name": "NS_E_WMP_BSTR_TOO_LONG", "explanation": "The parameter is not valid."},
    "0xC00D12FC": {
        "name": "NS_E_WMP_AUTOPLAY_INVALID_STATE",
        "explanation": "The state is not valid for this request.",
    },
    "0xC00D1306": {
        "name": "NS_E_WMP_COMPONENT_REVOKED",
        "explanation": "Windows Media Player cannot play this file until you complete the software component upgrade. After the component has been upgraded, try to play the file again.",
    },
    "0xC00D1324": {"name": "NS_E_CURL_NOTSAFE", "explanation": "The URL is not safe for the operation specified."},
    "0xC00D1325": {
        "name": "NS_E_CURL_INVALIDCHAR",
        "explanation": "The URL contains one or more characters that are not valid.",
    },
    "0xC00D1326": {
        "name": "NS_E_CURL_INVALIDHOSTNAME",
        "explanation": "The URL contains a host name that is not valid.",
    },
    "0xC00D1327": {"name": "NS_E_CURL_INVALIDPATH", "explanation": "The URL contains a path that is not valid."},
    "0xC00D1328": {"name": "NS_E_CURL_INVALIDSCHEME", "explanation": "The URL contains a scheme that is not valid."},
    "0xC00D1329": {"name": "NS_E_CURL_INVALIDURL", "explanation": "The URL is not valid."},
    "0xC00D132B": {
        "name": "NS_E_CURL_CANTWALK",
        "explanation": "Windows Media Player cannot play the file. If you clicked a link on a web page, the link might not be valid.",
    },
    "0xC00D132C": {"name": "NS_E_CURL_INVALIDPORT", "explanation": "The URL port is not valid."},
    "0xC00D132D": {"name": "NS_E_CURLHELPER_NOTADIRECTORY", "explanation": "The URL is not a directory."},
    "0xC00D132E": {"name": "NS_E_CURLHELPER_NOTAFILE", "explanation": "The URL is not a file."},
    "0xC00D132F": {
        "name": "NS_E_CURL_CANTDECODE",
        "explanation": "The URL contains characters that cannot be decoded. The URL might be truncated or incomplete.",
    },
    "0xC00D1330": {"name": "NS_E_CURLHELPER_NOTRELATIVE", "explanation": "The specified URL is not a relative URL."},
    "0xC00D1331": {
        "name": "NS_E_CURL_INVALIDBUFFERSIZE",
        "explanation": "The buffer is smaller than the size specified.",
    },
    "0xC00D1356": {
        "name": "NS_E_SUBSCRIPTIONSERVICE_PLAYBACK_DISALLOWED",
        "explanation": "The content provider has not granted you the right to play this file. Go to the content provider's online store to get play rights.",
    },
    "0xC00D1357": {
        "name": "NS_E_CANNOT_BUY_OR_DOWNLOAD_FROM_MULTIPLE_SERVICES",
        "explanation": "Windows Media Player cannot purchase or download content from multiple online stores.",
    },
    "0xC00D1358": {
        "name": "NS_E_CANNOT_BUY_OR_DOWNLOAD_CONTENT",
        "explanation": "The file cannot be purchased or downloaded. The file might not be available from the online store.",
    },
    "0xC00D135A": {
        "name": "NS_E_NOT_CONTENT_PARTNER_TRACK",
        "explanation": "The provider of this file cannot be identified.",
    },
    "0xC00D135B": {
        "name": "NS_E_TRACK_DOWNLOAD_REQUIRES_ALBUM_PURCHASE",
        "explanation": "The file is only available for download when you buy the entire album.",
    },
    "0xC00D135C": {
        "name": "NS_E_TRACK_DOWNLOAD_REQUIRES_PURCHASE",
        "explanation": "You must buy the file before you can download it.",
    },
    "0xC00D135D": {
        "name": "NS_E_TRACK_PURCHASE_MAXIMUM_EXCEEDED",
        "explanation": "You have exceeded the maximum number of files that can be purchased in a single transaction.",
    },
    "0xC00D135F": {
        "name": "NS_E_SUBSCRIPTIONSERVICE_LOGIN_FAILED",
        "explanation": "Windows Media Player cannot sign in to the online store. Verify that you are using the correct user name and password. If the problem persists, the store might be temporarily unavailable.",
    },
    "0xC00D1360": {
        "name": "NS_E_SUBSCRIPTIONSERVICE_DOWNLOAD_TIMEOUT",
        "explanation": "Windows Media Player cannot download this item because the server is not responding. The server might be temporarily unavailable or the Internet connection might be lost.",
    },
    "0xC00D1362": {
        "name": "NS_E_CONTENT_PARTNER_STILL_INITIALIZING",
        "explanation": "Content Partner still initializing.",
    },
    "0xC00D1363": {
        "name": "NS_E_OPEN_CONTAINING_FOLDER_FAILED",
        "explanation": "The folder could not be opened. The folder might have been moved or deleted.",
    },
    "0xC00D136A": {
        "name": "NS_E_ADVANCEDEDIT_TOO_MANY_PICTURES",
        "explanation": "Windows Media Player could not add all of the images to the file because the images exceeded the 7 megabyte (MB) limit.",
    },
    "0xC00D1388": {"name": "NS_E_REDIRECT", "explanation": "The client redirected to another server."},
    "0xC00D1389": {
        "name": "NS_E_STALE_PRESENTATION",
        "explanation": "The streaming media description is no longer current.",
    },
    "0xC00D138A": {
        "name": "NS_E_NAMESPACE_WRONG_PERSIST",
        "explanation": "It is not possible to create a persistent namespace node under a transient parent node.",
    },
    "0xC00D138B": {
        "name": "NS_E_NAMESPACE_WRONG_TYPE",
        "explanation": "It is not possible to store a value in a namespace node that has a different value type.",
    },
    "0xC00D138C": {
        "name": "NS_E_NAMESPACE_NODE_CONFLICT",
        "explanation": "It is not possible to remove the root namespace node.",
    },
    "0xC00D138D": {
        "name": "NS_E_NAMESPACE_NODE_NOT_FOUND",
        "explanation": "The specified namespace node could not be found.",
    },
    "0xC00D138E": {
        "name": "NS_E_NAMESPACE_BUFFER_TOO_SMALL",
        "explanation": "The buffer supplied to hold namespace node string is too small.",
    },
    "0xC00D138F": {
        "name": "NS_E_NAMESPACE_TOO_MANY_CALLBACKS",
        "explanation": "The callback list on a namespace node is at the maximum size.",
    },
    "0xC00D1390": {
        "name": "NS_E_NAMESPACE_DUPLICATE_CALLBACK",
        "explanation": "It is not possible to register an already-registered callback on a namespace node.",
    },
    "0xC00D1391": {
        "name": "NS_E_NAMESPACE_CALLBACK_NOT_FOUND",
        "explanation": "Cannot find the callback in the namespace when attempting to remove the callback.",
    },
    "0xC00D1392": {
        "name": "NS_E_NAMESPACE_NAME_TOO_LONG",
        "explanation": "The namespace node name exceeds the allowed maximum length.",
    },
    "0xC00D1393": {
        "name": "NS_E_NAMESPACE_DUPLICATE_NAME",
        "explanation": "Cannot create a namespace node that already exists.",
    },
    "0xC00D1394": {
        "name": "NS_E_NAMESPACE_EMPTY_NAME",
        "explanation": "The namespace node name cannot be a null string.",
    },
    "0xC00D1395": {
        "name": "NS_E_NAMESPACE_INDEX_TOO_LARGE",
        "explanation": "Finding a child namespace node by index failed because the index exceeded the number of children.",
    },
    "0xC00D1396": {"name": "NS_E_NAMESPACE_BAD_NAME", "explanation": "The namespace node name is invalid."},
    "0xC00D1397": {
        "name": "NS_E_NAMESPACE_WRONG_SECURITY",
        "explanation": "It is not possible to store a value in a namespace node that has a different security type.",
    },
    "0xC00D13EC": {
        "name": "NS_E_CACHE_ARCHIVE_CONFLICT",
        "explanation": "The archive request conflicts with other requests in progress.",
    },
    "0xC00D13ED": {
        "name": "NS_E_CACHE_ORIGIN_SERVER_NOT_FOUND",
        "explanation": "The specified origin server cannot be found.",
    },
    "0xC00D13EE": {
        "name": "NS_E_CACHE_ORIGIN_SERVER_TIMEOUT",
        "explanation": "The specified origin server is not responding.",
    },
    "0xC00D13EF": {
        "name": "NS_E_CACHE_NOT_BROADCAST",
        "explanation": "The internal code for HTTP status code 412 Precondition Failed due to not broadcast type.",
    },
    "0xC00D13F0": {
        "name": "NS_E_CACHE_CANNOT_BE_CACHED",
        "explanation": "The internal code for HTTP status code 403 Forbidden due to not cacheable.",
    },
    "0xC00D13F1": {
        "name": "NS_E_CACHE_NOT_MODIFIED",
        "explanation": "The internal code for HTTP status code 304 Not Modified.",
    },
    "0xC00D1450": {
        "name": "NS_E_CANNOT_REMOVE_PUBLISHING_POINT",
        "explanation": "It is not possible to remove a cache or proxy publishing point.",
    },
    "0xC00D1451": {
        "name": "NS_E_CANNOT_REMOVE_PLUGIN",
        "explanation": "It is not possible to remove the last instance of a type of plug-in.",
    },
    "0xC00D1452": {
        "name": "NS_E_WRONG_PUBLISHING_POINT_TYPE",
        "explanation": "Cache and proxy publishing points do not support this property or method.",
    },
    "0xC00D1453": {
        "name": "NS_E_UNSUPPORTED_LOAD_TYPE",
        "explanation": "The plug-in does not support the specified load type.",
    },
    "0xC00D1454": {
        "name": "NS_E_INVALID_PLUGIN_LOAD_TYPE_CONFIGURATION",
        "explanation": "The plug-in does not support any load types. The plug-in must support at least one load type.",
    },
    "0xC00D1455": {
        "name": "NS_E_INVALID_PUBLISHING_POINT_NAME",
        "explanation": "The publishing point name is invalid.",
    },
    "0xC00D1456": {
        "name": "NS_E_TOO_MANY_MULTICAST_SINKS",
        "explanation": "Only one multicast data writer plug-in can be enabled for a publishing point.",
    },
    "0xC00D1457": {
        "name": "NS_E_PUBLISHING_POINT_INVALID_REQUEST_WHILE_STARTED",
        "explanation": "The requested operation cannot be completed while the publishing point is started.",
    },
    "0xC00D1458": {
        "name": "NS_E_MULTICAST_PLUGIN_NOT_ENABLED",
        "explanation": "A multicast data writer plug-in must be enabled in order for this operation to be completed.",
    },
    "0xC00D1459": {
        "name": "NS_E_INVALID_OPERATING_SYSTEM_VERSION",
        "explanation": "This feature requires Windows Server 2003, Enterprise Edition.",
    },
    "0xC00D145A": {
        "name": "NS_E_PUBLISHING_POINT_REMOVED",
        "explanation": "The requested operation cannot be completed because the specified publishing point has been removed.",
    },
    "0xC00D145B": {
        "name": "NS_E_INVALID_PUSH_PUBLISHING_POINT_START_REQUEST",
        "explanation": "Push publishing points are started when the encoder starts pushing the stream. This publishing point cannot be started by the server administrator.",
    },
    "0xC00D145C": {"name": "NS_E_UNSUPPORTED_LANGUAGE", "explanation": "The specified language is not supported."},
    "0xC00D145D": {
        "name": "NS_E_WRONG_OS_VERSION",
        "explanation": "Windows Media Services will only run on Windows Server 2003, Standard Edition and Windows Server 2003, Enterprise Edition.",
    },
    "0xC00D145E": {
        "name": "NS_E_PUBLISHING_POINT_STOPPED",
        "explanation": "The operation cannot be completed because the publishing point has been stopped.",
    },
    "0xC00D14B4": {
        "name": "NS_E_PLAYLIST_ENTRY_ALREADY_PLAYING",
        "explanation": "The playlist entry is already playing.",
    },
    "0xC00D14B5": {
        "name": "NS_E_EMPTY_PLAYLIST",
        "explanation": "The playlist or directory you are requesting does not contain content.",
    },
    "0xC00D14B6": {
        "name": "NS_E_PLAYLIST_PARSE_FAILURE",
        "explanation": "The server was unable to parse the requested playlist file.",
    },
    "0xC00D14B7": {
        "name": "NS_E_PLAYLIST_UNSUPPORTED_ENTRY",
        "explanation": "The requested operation is not supported for this type of playlist entry.",
    },
    "0xC00D14B8": {
        "name": "NS_E_PLAYLIST_ENTRY_NOT_IN_PLAYLIST",
        "explanation": "Cannot jump to a playlist entry that is not inserted in the playlist.",
    },
    "0xC00D14B9": {"name": "NS_E_PLAYLIST_ENTRY_SEEK", "explanation": "Cannot seek to the desired playlist entry."},
    "0xC00D14BA": {"name": "NS_E_PLAYLIST_RECURSIVE_PLAYLISTS", "explanation": "Cannot play recursive playlist."},
    "0xC00D14BB": {
        "name": "NS_E_PLAYLIST_TOO_MANY_NESTED_PLAYLISTS",
        "explanation": "The number of nested playlists exceeded the limit the server can handle.",
    },
    "0xC00D14BC": {
        "name": "NS_E_PLAYLIST_SHUTDOWN",
        "explanation": "Cannot execute the requested operation because the playlist has been shut down by the Media Server.",
    },
    "0xC00D14BD": {"name": "NS_E_PLAYLIST_END_RECEDING", "explanation": "The playlist has ended while receding."},
    "0xC00D1518": {
        "name": "NS_E_DATAPATH_NO_SINK",
        "explanation": "The data path does not have an associated data writer plug-in.",
    },
    "0xC00D151A": {"name": "NS_E_INVALID_PUSH_TEMPLATE", "explanation": "The specified push template is invalid."},
    "0xC00D151B": {
        "name": "NS_E_INVALID_PUSH_PUBLISHING_POINT",
        "explanation": "The specified push publishing point is invalid.",
    },
    "0xC00D151C": {
        "name": "NS_E_CRITICAL_ERROR",
        "explanation": "The requested operation cannot be performed because the server or publishing point is in a critical error state.",
    },
    "0xC00D151D": {
        "name": "NS_E_NO_NEW_CONNECTIONS",
        "explanation": "The content cannot be played because the server is not currently accepting connections. Try connecting at a later time.",
    },
    "0xC00D151E": {
        "name": "NS_E_WSX_INVALID_VERSION",
        "explanation": "The version of this playlist is not supported by the server.",
    },
    "0xC00D151F": {
        "name": "NS_E_HEADER_MISMATCH",
        "explanation": "The command does not apply to the current media header user by a server component.",
    },
    "0xC00D1520": {
        "name": "NS_E_PUSH_DUPLICATE_PUBLISHING_POINT_NAME",
        "explanation": "The specified publishing point name is already in use.",
    },
    "0xC00D157C": {
        "name": "NS_E_NO_SCRIPT_ENGINE",
        "explanation": "There is no script engine available for this file.",
    },
    "0xC00D157D": {
        "name": "NS_E_PLUGIN_ERROR_REPORTED",
        "explanation": "The plug-in has reported an error. See the Troubleshooting tab or the NT Application Event Log for details.",
    },
    "0xC00D157E": {
        "name": "NS_E_SOURCE_PLUGIN_NOT_FOUND",
        "explanation": "No enabled data source plug-in is available to access the requested content.",
    },
    "0xC00D157F": {
        "name": "NS_E_PLAYLIST_PLUGIN_NOT_FOUND",
        "explanation": "No enabled playlist parser plug-in is available to access the requested content.",
    },
    "0xC00D1580": {
        "name": "NS_E_DATA_SOURCE_ENUMERATION_NOT_SUPPORTED",
        "explanation": "The data source plug-in does not support enumeration.",
    },
    "0xC00D1581": {
        "name": "NS_E_MEDIA_PARSER_INVALID_FORMAT",
        "explanation": "The server cannot stream the selected file because it is either damaged or corrupt. Select a different file.",
    },
    "0xC00D1582": {
        "name": "NS_E_SCRIPT_DEBUGGER_NOT_INSTALLED",
        "explanation": "The plug-in cannot be enabled because a compatible script debugger is not installed on this system. Install a script debugger, or disable the script debugger option on the general tab of the plug-in's properties page and try again.",
    },
    "0xC00D1583": {
        "name": "NS_E_FEATURE_REQUIRES_ENTERPRISE_SERVER",
        "explanation": "The plug-in cannot be loaded because it requires Windows Server 2003, Enterprise Edition.",
    },
    "0xC00D1584": {
        "name": "NS_E_WIZARD_RUNNING",
        "explanation": "Another wizard is currently running. Please close the other wizard or wait until it finishes before attempting to run this wizard again.",
    },
    "0xC00D1585": {
        "name": "NS_E_INVALID_LOG_URL",
        "explanation": 'Invalid log URL. Multicast logging URL must look like "http://servername/isapibackend.dll".',
    },
    "0xC00D1586": {
        "name": "NS_E_INVALID_MTU_RANGE",
        "explanation": "Invalid MTU specified. The valid range for maximum packet size is between 36 and 65507 bytes.",
    },
    "0xC00D1587": {"name": "NS_E_INVALID_PLAY_STATISTICS", "explanation": "Invalid play statistics for logging."},
    "0xC00D1588": {"name": "NS_E_LOG_NEED_TO_BE_SKIPPED", "explanation": "The log needs to be skipped."},
    "0xC00D1589": {
        "name": "NS_E_HTTP_TEXT_DATACONTAINER_SIZE_LIMIT_EXCEEDED",
        "explanation": "The size of the data exceeded the limit the WMS HTTP Download Data Source plugin can handle.",
    },
    "0xC00D158A": {
        "name": "NS_E_PORT_IN_USE",
        "explanation": "One usage of each socket address (protocol/network address/port) is permitted. Verify that other services or applications are not attempting to use the same port and then try to enable the plug-in again.",
    },
    "0xC00D158B": {
        "name": "NS_E_PORT_IN_USE_HTTP",
        "explanation": "One usage of each socket address (protocol/network address/port) is permitted. Verify that other services (such as IIS) or applications are not attempting to use the same port and then try to enable the plug-in again.",
    },
    "0xC00D158C": {
        "name": "NS_E_HTTP_TEXT_DATACONTAINER_INVALID_SERVER_RESPONSE",
        "explanation": "The WMS HTTP Download Data Source plugin was unable to receive the remote server's response.",
    },
    "0xC00D158D": {"name": "NS_E_ARCHIVE_REACH_QUOTA", "explanation": "The archive plug-in has reached its quota."},
    "0xC00D158E": {
        "name": "NS_E_ARCHIVE_ABORT_DUE_TO_BCAST",
        "explanation": "The archive plug-in aborted because the source was from broadcast.",
    },
    "0xC00D158F": {
        "name": "NS_E_ARCHIVE_GAP_DETECTED",
        "explanation": "The archive plug-in detected an interrupt in the source.",
    },
    "0xC00D1590": {
        "name": "NS_E_AUTHORIZATION_FILE_NOT_FOUND",
        "explanation": "The system cannot find the file specified.",
    },
    "0xC00D1B58": {
        "name": "NS_E_BAD_MARKIN",
        "explanation": "The mark-in time should be greater than 0 and less than the mark-out time.",
    },
    "0xC00D1B59": {
        "name": "NS_E_BAD_MARKOUT",
        "explanation": "The mark-out time should be greater than the mark-in time and less than the file duration.",
    },
    "0xC00D1B5A": {
        "name": "NS_E_NOMATCHING_MEDIASOURCE",
        "explanation": "No matching media type is found in the source %1.",
    },
    "0xC00D1B5B": {"name": "NS_E_UNSUPPORTED_SOURCETYPE", "explanation": "The specified source type is not supported."},
    "0xC00D1B5C": {
        "name": "NS_E_TOO_MANY_AUDIO",
        "explanation": "It is not possible to specify more than one audio input.",
    },
    "0xC00D1B5D": {
        "name": "NS_E_TOO_MANY_VIDEO",
        "explanation": "It is not possible to specify more than two video inputs.",
    },
    "0xC00D1B5E": {"name": "NS_E_NOMATCHING_ELEMENT", "explanation": "No matching element is found in the list."},
    "0xC00D1B5F": {
        "name": "NS_E_MISMATCHED_MEDIACONTENT",
        "explanation": "The profile's media types must match the media types defined for the session.",
    },
    "0xC00D1B60": {
        "name": "NS_E_CANNOT_DELETE_ACTIVE_SOURCEGROUP",
        "explanation": "It is not possible to remove an active source while encoding.",
    },
    "0xC00D1B61": {
        "name": "NS_E_AUDIODEVICE_BUSY",
        "explanation": "It is not possible to open the specified audio capture device because it is currently in use.",
    },
    "0xC00D1B62": {
        "name": "NS_E_AUDIODEVICE_UNEXPECTED",
        "explanation": "It is not possible to open the specified audio capture device because an unexpected error has occurred.",
    },
    "0xC00D1B63": {
        "name": "NS_E_AUDIODEVICE_BADFORMAT",
        "explanation": "The audio capture device does not support the specified audio format.",
    },
    "0xC00D1B64": {
        "name": "NS_E_VIDEODEVICE_BUSY",
        "explanation": "It is not possible to open the specified video capture device because it is currently in use.",
    },
    "0xC00D1B65": {
        "name": "NS_E_VIDEODEVICE_UNEXPECTED",
        "explanation": "It is not possible to open the specified video capture device because an unexpected error has occurred.",
    },
    "0xC00D1B66": {
        "name": "NS_E_INVALIDCALL_WHILE_ENCODER_RUNNING",
        "explanation": "This operation is not allowed while encoding.",
    },
    "0xC00D1B67": {"name": "NS_E_NO_PROFILE_IN_SOURCEGROUP", "explanation": "No profile is set for the source."},
    "0xC00D1B68": {
        "name": "NS_E_VIDEODRIVER_UNSTABLE",
        "explanation": "The video capture driver returned an unrecoverable error. It is now in an unstable state.",
    },
    "0xC00D1B69": {"name": "NS_E_VIDCAPSTARTFAILED", "explanation": "It was not possible to start the video device."},
    "0xC00D1B6A": {
        "name": "NS_E_VIDSOURCECOMPRESSION",
        "explanation": "The video source does not support the requested output format or color depth.",
    },
    "0xC00D1B6B": {
        "name": "NS_E_VIDSOURCESIZE",
        "explanation": "The video source does not support the requested capture size.",
    },
    "0xC00D1B6C": {
        "name": "NS_E_ICMQUERYFORMAT",
        "explanation": "It was not possible to obtain output information from the video compressor.",
    },
    "0xC00D1B6D": {
        "name": "NS_E_VIDCAPCREATEWINDOW",
        "explanation": "It was not possible to create a video capture window.",
    },
    "0xC00D1B6E": {
        "name": "NS_E_VIDCAPDRVINUSE",
        "explanation": "There is already a stream active on this video device.",
    },
    "0xC00D1B6F": {"name": "NS_E_NO_MEDIAFORMAT_IN_SOURCE", "explanation": "No media format is set in source."},
    "0xC00D1B70": {
        "name": "NS_E_NO_VALID_OUTPUT_STREAM",
        "explanation": "Cannot find a valid output stream from the source.",
    },
    "0xC00D1B71": {
        "name": "NS_E_NO_VALID_SOURCE_PLUGIN",
        "explanation": "It was not possible to find a valid source plug-in for the specified source.",
    },
    "0xC00D1B72": {"name": "NS_E_NO_ACTIVE_SOURCEGROUP", "explanation": "No source is currently active."},
    "0xC00D1B73": {"name": "NS_E_NO_SCRIPT_STREAM", "explanation": "No script stream is set in the current source."},
    "0xC00D1B74": {
        "name": "NS_E_INVALIDCALL_WHILE_ARCHIVAL_RUNNING",
        "explanation": "This operation is not allowed while archiving.",
    },
    "0xC00D1B75": {
        "name": "NS_E_INVALIDPACKETSIZE",
        "explanation": "The setting for the maximum packet size is not valid.",
    },
    "0xC00D1B76": {"name": "NS_E_PLUGIN_CLSID_INVALID", "explanation": "The plug-in CLSID specified is not valid."},
    "0xC00D1B77": {"name": "NS_E_UNSUPPORTED_ARCHIVETYPE", "explanation": "This archive type is not supported."},
    "0xC00D1B78": {
        "name": "NS_E_UNSUPPORTED_ARCHIVEOPERATION",
        "explanation": "This archive operation is not supported.",
    },
    "0xC00D1B79": {"name": "NS_E_ARCHIVE_FILENAME_NOTSET", "explanation": "The local archive file name was not set."},
    "0xC00D1B7A": {"name": "NS_E_SOURCEGROUP_NOTPREPARED", "explanation": "The source is not yet prepared."},
    "0xC00D1B7B": {"name": "NS_E_PROFILE_MISMATCH", "explanation": "Profiles on the sources do not match."},
    "0xC00D1B7C": {"name": "NS_E_INCORRECTCLIPSETTINGS", "explanation": "The specified crop values are not valid."},
    "0xC00D1B7D": {"name": "NS_E_NOSTATSAVAILABLE", "explanation": "No statistics are available at this time."},
    "0xC00D1B7E": {"name": "NS_E_NOTARCHIVING", "explanation": "The encoder is not archiving."},
    "0xC00D1B7F": {
        "name": "NS_E_INVALIDCALL_WHILE_ENCODER_STOPPED",
        "explanation": "This operation is only allowed during encoding.",
    },
    "0xC00D1B80": {
        "name": "NS_E_NOSOURCEGROUPS",
        "explanation": "This SourceGroupCollection doesn't contain any SourceGroups.",
    },
    "0xC00D1B81": {
        "name": "NS_E_INVALIDINPUTFPS",
        "explanation": "This source does not have a frame rate of 30 fps. Therefore, it is not possible to apply the inverse telecine filter to the source.",
    },
    "0xC00D1B82": {
        "name": "NS_E_NO_DATAVIEW_SUPPORT",
        "explanation": "It is not possible to display your source or output video in the Video panel.",
    },
    "0xC00D1B83": {
        "name": "NS_E_CODEC_UNAVAILABLE",
        "explanation": "One or more codecs required to open this content could not be found.",
    },
    "0xC00D1B84": {
        "name": "NS_E_ARCHIVE_SAME_AS_INPUT",
        "explanation": "The archive file has the same name as an input file. Change one of the names before continuing.",
    },
    "0xC00D1B85": {"name": "NS_E_SOURCE_NOTSPECIFIED", "explanation": "The source has not been set up completely."},
    "0xC00D1B86": {
        "name": "NS_E_NO_REALTIME_TIMECOMPRESSION",
        "explanation": "It is not possible to apply time compression to a broadcast session.",
    },
    "0xC00D1B87": {"name": "NS_E_UNSUPPORTED_ENCODER_DEVICE", "explanation": "It is not possible to open this device."},
    "0xC00D1B88": {
        "name": "NS_E_UNEXPECTED_DISPLAY_SETTINGS",
        "explanation": "It is not possible to start encoding because the display size or color has changed since the current session was defined. Restore the previous settings or create a new session.",
    },
    "0xC00D1B89": {
        "name": "NS_E_NO_AUDIODATA",
        "explanation": "No audio data has been received for several seconds. Check the audio source and restart the encoder.",
    },
    "0xC00D1B8A": {
        "name": "NS_E_INPUTSOURCE_PROBLEM",
        "explanation": "One or all of the specified sources are not working properly. Check that the sources are configured correctly.",
    },
    "0xC00D1B8B": {
        "name": "NS_E_WME_VERSION_MISMATCH",
        "explanation": "The supplied configuration file is not supported by this version of the encoder.",
    },
    "0xC00D1B8C": {
        "name": "NS_E_NO_REALTIME_PREPROCESS",
        "explanation": "It is not possible to use image preprocessing with live encoding.",
    },
    "0xC00D1B8D": {
        "name": "NS_E_NO_REPEAT_PREPROCESS",
        "explanation": "It is not possible to use two-pass encoding when the source is set to loop.",
    },
    "0xC00D1B8E": {
        "name": "NS_E_CANNOT_PAUSE_LIVEBROADCAST",
        "explanation": "It is not possible to pause encoding during a broadcast.",
    },
    "0xC00D1B8F": {
        "name": "NS_E_DRM_PROFILE_NOT_SET",
        "explanation": "A DRM profile has not been set for the current session.",
    },
    "0xC00D1B90": {
        "name": "NS_E_DUPLICATE_DRMPROFILE",
        "explanation": "The profile ID is already used by a DRM profile. Specify a different profile ID.",
    },
    "0xC00D1B91": {
        "name": "NS_E_INVALID_DEVICE",
        "explanation": "The setting of the selected device does not support control for playing back tapes.",
    },
    "0xC00D1B92": {
        "name": "NS_E_SPEECHEDL_ON_NON_MIXEDMODE",
        "explanation": "You must specify a mixed voice and audio mode in order to use an optimization definition file.",
    },
    "0xC00D1B93": {
        "name": "NS_E_DRM_PASSWORD_TOO_LONG",
        "explanation": "The specified password is too long. Type a password with fewer than 8 characters.",
    },
    "0xC00D1B94": {
        "name": "NS_E_DEVCONTROL_FAILED_SEEK",
        "explanation": "It is not possible to seek to the specified mark-in point.",
    },
    "0xC00D1B95": {
        "name": "NS_E_INTERLACE_REQUIRE_SAMESIZE",
        "explanation": "When you choose to maintain the interlacing in your video, the output video size must match the input video size.",
    },
    "0xC00D1B96": {
        "name": "NS_E_TOO_MANY_DEVICECONTROL",
        "explanation": "Only one device control plug-in can control a device.",
    },
    "0xC00D1B97": {
        "name": "NS_E_NO_MULTIPASS_FOR_LIVEDEVICE",
        "explanation": "You must also enable storing content to hard disk temporarily in order to use two-pass encoding with the input device.",
    },
    "0xC00D1B98": {
        "name": "NS_E_MISSING_AUDIENCE",
        "explanation": "An audience is missing from the output stream configuration.",
    },
    "0xC00D1B99": {
        "name": "NS_E_AUDIENCE_CONTENTTYPE_MISMATCH",
        "explanation": "All audiences in the output tree must have the same content type.",
    },
    "0xC00D1B9A": {
        "name": "NS_E_MISSING_SOURCE_INDEX",
        "explanation": "A source index is missing from the output stream configuration.",
    },
    "0xC00D1B9B": {
        "name": "NS_E_NUM_LANGUAGE_MISMATCH",
        "explanation": "The same source index in different audiences should have the same number of languages.",
    },
    "0xC00D1B9C": {
        "name": "NS_E_LANGUAGE_MISMATCH",
        "explanation": "The same source index in different audiences should have the same languages.",
    },
    "0xC00D1B9D": {
        "name": "NS_E_VBRMODE_MISMATCH",
        "explanation": "The same source index in different audiences should use the same VBR encoding mode.",
    },
    "0xC00D1B9E": {
        "name": "NS_E_INVALID_INPUT_AUDIENCE_INDEX",
        "explanation": "The bit rate index specified is not valid.",
    },
    "0xC00D1B9F": {"name": "NS_E_INVALID_INPUT_LANGUAGE", "explanation": "The specified language is not valid."},
    "0xC00D1BA0": {"name": "NS_E_INVALID_INPUT_STREAM", "explanation": "The specified source type is not valid."},
    "0xC00D1BA1": {"name": "NS_E_EXPECT_MONO_WAV_INPUT", "explanation": "The source must be a mono channel .wav file."},
    "0xC00D1BA2": {
        "name": "NS_E_INPUT_WAVFORMAT_MISMATCH",
        "explanation": "All the source .wav files must have the same format.",
    },
    "0xC00D1BA3": {
        "name": "NS_E_RECORDQ_DISK_FULL",
        "explanation": "The hard disk being used for temporary storage of content has reached the minimum allowed disk space. Create more space on the hard disk and restart encoding.",
    },
    "0xC00D1BA4": {
        "name": "NS_E_NO_PAL_INVERSE_TELECINE",
        "explanation": "It is not possible to apply the inverse telecine feature to PAL content.",
    },
    "0xC00D1BA5": {
        "name": "NS_E_ACTIVE_SG_DEVICE_DISCONNECTED",
        "explanation": "A capture device in the current active source is no longer available.",
    },
    "0xC00D1BA6": {
        "name": "NS_E_ACTIVE_SG_DEVICE_CONTROL_DISCONNECTED",
        "explanation": "A device used in the current active source for device control is no longer available.",
    },
    "0xC00D1BA7": {
        "name": "NS_E_NO_FRAMES_SUBMITTED_TO_ANALYZER",
        "explanation": "No frames have been submitted to the analyzer for analysis.",
    },
    "0xC00D1BA8": {
        "name": "NS_E_INPUT_DOESNOT_SUPPORT_SMPTE",
        "explanation": "The source video does not support time codes.",
    },
    "0xC00D1BA9": {
        "name": "NS_E_NO_SMPTE_WITH_MULTIPLE_SOURCEGROUPS",
        "explanation": "It is not possible to generate a time code when there are multiple sources in a session.",
    },
    "0xC00D1BAA": {
        "name": "NS_E_BAD_CONTENTEDL",
        "explanation": "The voice codec optimization definition file cannot be found or is corrupted.",
    },
    "0xC00D1BAB": {
        "name": "NS_E_INTERLACEMODE_MISMATCH",
        "explanation": "The same source index in different audiences should have the same interlace mode.",
    },
    "0xC00D1BAC": {
        "name": "NS_E_NONSQUAREPIXELMODE_MISMATCH",
        "explanation": "The same source index in different audiences should have the same nonsquare pixel mode.",
    },
    "0xC00D1BAD": {
        "name": "NS_E_SMPTEMODE_MISMATCH",
        "explanation": "The same source index in different audiences should have the same time code mode.",
    },
    "0xC00D1BAE": {
        "name": "NS_E_END_OF_TAPE",
        "explanation": "Either the end of the tape has been reached or there is no tape. Check the device and tape.",
    },
    "0xC00D1BAF": {"name": "NS_E_NO_MEDIA_IN_AUDIENCE", "explanation": "No audio or video input has been specified."},
    "0xC00D1BB0": {"name": "NS_E_NO_AUDIENCES", "explanation": "The profile must contain a bit rate."},
    "0xC00D1BB1": {
        "name": "NS_E_NO_AUDIO_COMPAT",
        "explanation": "You must specify at least one audio stream to be compatible with Windows Media Player 7.1.",
    },
    "0xC00D1BB2": {
        "name": "NS_E_INVALID_VBR_COMPAT",
        "explanation": "Using a VBR encoding mode is not compatible with Windows Media Player 7.1.",
    },
    "0xC00D1BB3": {"name": "NS_E_NO_PROFILE_NAME", "explanation": "You must specify a profile name."},
    "0xC00D1BB4": {
        "name": "NS_E_INVALID_VBR_WITH_UNCOMP",
        "explanation": "It is not possible to use a VBR encoding mode with uncompressed audio or video.",
    },
    "0xC00D1BB5": {
        "name": "NS_E_MULTIPLE_VBR_AUDIENCES",
        "explanation": "It is not possible to use MBR encoding with VBR encoding.",
    },
    "0xC00D1BB6": {
        "name": "NS_E_UNCOMP_COMP_COMBINATION",
        "explanation": "It is not possible to mix uncompressed and compressed content in a session.",
    },
    "0xC00D1BB7": {"name": "NS_E_MULTIPLE_AUDIO_CODECS", "explanation": "All audiences must use the same audio codec."},
    "0xC00D1BB8": {
        "name": "NS_E_MULTIPLE_AUDIO_FORMATS",
        "explanation": "All audiences should use the same audio format to be compatible with Windows Media Player 7.1.",
    },
    "0xC00D1BB9": {
        "name": "NS_E_AUDIO_BITRATE_STEPDOWN",
        "explanation": "The audio bit rate for an audience with a higher total bit rate must be greater than one with a lower total bit rate.",
    },
    "0xC00D1BBA": {
        "name": "NS_E_INVALID_AUDIO_PEAKRATE",
        "explanation": "The audio peak bit rate setting is not valid.",
    },
    "0xC00D1BBB": {
        "name": "NS_E_INVALID_AUDIO_PEAKRATE_2",
        "explanation": "The audio peak bit rate setting must be greater than the audio bit rate setting.",
    },
    "0xC00D1BBC": {
        "name": "NS_E_INVALID_AUDIO_BUFFERMAX",
        "explanation": "The setting for the maximum buffer size for audio is not valid.",
    },
    "0xC00D1BBD": {"name": "NS_E_MULTIPLE_VIDEO_CODECS", "explanation": "All audiences must use the same video codec."},
    "0xC00D1BBE": {
        "name": "NS_E_MULTIPLE_VIDEO_SIZES",
        "explanation": "All audiences should use the same video size to be compatible with Windows Media Player 7.1.",
    },
    "0xC00D1BBF": {"name": "NS_E_INVALID_VIDEO_BITRATE", "explanation": "The video bit rate setting is not valid."},
    "0xC00D1BC0": {
        "name": "NS_E_VIDEO_BITRATE_STEPDOWN",
        "explanation": "The video bit rate for an audience with a higher total bit rate must be greater than one with a lower total bit rate.",
    },
    "0xC00D1BC1": {
        "name": "NS_E_INVALID_VIDEO_PEAKRATE",
        "explanation": "The video peak bit rate setting is not valid.",
    },
    "0xC00D1BC2": {
        "name": "NS_E_INVALID_VIDEO_PEAKRATE_2",
        "explanation": "The video peak bit rate setting must be greater than the video bit rate setting.",
    },
    "0xC00D1BC3": {"name": "NS_E_INVALID_VIDEO_WIDTH", "explanation": "The video width setting is not valid."},
    "0xC00D1BC4": {"name": "NS_E_INVALID_VIDEO_HEIGHT", "explanation": "The video height setting is not valid."},
    "0xC00D1BC5": {"name": "NS_E_INVALID_VIDEO_FPS", "explanation": "The video frame rate setting is not valid."},
    "0xC00D1BC6": {"name": "NS_E_INVALID_VIDEO_KEYFRAME", "explanation": "The video key frame setting is not valid."},
    "0xC00D1BC7": {
        "name": "NS_E_INVALID_VIDEO_IQUALITY",
        "explanation": "The video image quality setting is not valid.",
    },
    "0xC00D1BC8": {
        "name": "NS_E_INVALID_VIDEO_CQUALITY",
        "explanation": "The video codec quality setting is not valid.",
    },
    "0xC00D1BC9": {"name": "NS_E_INVALID_VIDEO_BUFFER", "explanation": "The video buffer setting is not valid."},
    "0xC00D1BCA": {
        "name": "NS_E_INVALID_VIDEO_BUFFERMAX",
        "explanation": "The setting for the maximum buffer size for video is not valid.",
    },
    "0xC00D1BCB": {
        "name": "NS_E_INVALID_VIDEO_BUFFERMAX_2",
        "explanation": "The value of the video maximum buffer size setting must be greater than the video buffer size setting.",
    },
    "0xC00D1BCC": {
        "name": "NS_E_INVALID_VIDEO_WIDTH_ALIGN",
        "explanation": "The alignment of the video width is not valid.",
    },
    "0xC00D1BCD": {
        "name": "NS_E_INVALID_VIDEO_HEIGHT_ALIGN",
        "explanation": "The alignment of the video height is not valid.",
    },
    "0xC00D1BCE": {
        "name": "NS_E_MULTIPLE_SCRIPT_BITRATES",
        "explanation": "All bit rates must have the same script bit rate.",
    },
    "0xC00D1BCF": {"name": "NS_E_INVALID_SCRIPT_BITRATE", "explanation": "The script bit rate specified is not valid."},
    "0xC00D1BD0": {
        "name": "NS_E_MULTIPLE_FILE_BITRATES",
        "explanation": "All bit rates must have the same file transfer bit rate.",
    },
    "0xC00D1BD1": {"name": "NS_E_INVALID_FILE_BITRATE", "explanation": "The file transfer bit rate is not valid."},
    "0xC00D1BD2": {
        "name": "NS_E_SAME_AS_INPUT_COMBINATION",
        "explanation": "All audiences in a profile should either be same as input or have video width and height specified.",
    },
    "0xC00D1BD3": {"name": "NS_E_SOURCE_CANNOT_LOOP", "explanation": "This source type does not support looping."},
    "0xC00D1BD4": {
        "name": "NS_E_INVALID_FOLDDOWN_COEFFICIENTS",
        "explanation": "The fold-down value needs to be between -144 and 0.",
    },
    "0xC00D1BD5": {
        "name": "NS_E_DRMPROFILE_NOTFOUND",
        "explanation": "The specified DRM profile does not exist in the system.",
    },
    "0xC00D1BD6": {"name": "NS_E_INVALID_TIMECODE", "explanation": "The specified time code is not valid."},
    "0xC00D1BD7": {
        "name": "NS_E_NO_AUDIO_TIMECOMPRESSION",
        "explanation": "It is not possible to apply time compression to a video-only session.",
    },
    "0xC00D1BD8": {
        "name": "NS_E_NO_TWOPASS_TIMECOMPRESSION",
        "explanation": "It is not possible to apply time compression to a session that is using two-pass encoding.",
    },
    "0xC00D1BD9": {
        "name": "NS_E_TIMECODE_REQUIRES_VIDEOSTREAM",
        "explanation": "It is not possible to generate a time code for an audio-only session.",
    },
    "0xC00D1BDA": {
        "name": "NS_E_NO_MBR_WITH_TIMECODE",
        "explanation": "It is not possible to generate a time code when you are encoding content at multiple bit rates.",
    },
    "0xC00D1BDB": {
        "name": "NS_E_INVALID_INTERLACEMODE",
        "explanation": "The video codec selected does not support maintaining interlacing in video.",
    },
    "0xC00D1BDC": {
        "name": "NS_E_INVALID_INTERLACE_COMPAT",
        "explanation": "Maintaining interlacing in video is not compatible with Windows Media Player 7.1.",
    },
    "0xC00D1BDD": {
        "name": "NS_E_INVALID_NONSQUAREPIXEL_COMPAT",
        "explanation": "Allowing nonsquare pixel output is not compatible with Windows Media Player 7.1.",
    },
    "0xC00D1BDE": {
        "name": "NS_E_INVALID_SOURCE_WITH_DEVICE_CONTROL",
        "explanation": "Only capture devices can be used with device control.",
    },
    "0xC00D1BDF": {
        "name": "NS_E_CANNOT_GENERATE_BROADCAST_INFO_FOR_QUALITYVBR",
        "explanation": "It is not possible to generate the stream format file if you are using quality-based VBR encoding for the audio or video stream. Instead use the Windows Media file generated after encoding to create the announcement file.",
    },
    "0xC00D1BE0": {
        "name": "NS_E_EXCEED_MAX_DRM_PROFILE_LIMIT",
        "explanation": "It is not possible to create a DRM profile because the maximum number of profiles has been reached. You must delete some DRM profiles before creating new ones.",
    },
    "0xC00D1BE1": {
        "name": "NS_E_DEVICECONTROL_UNSTABLE",
        "explanation": "The device is in an unstable state. Check that the device is functioning properly and a tape is in place.",
    },
    "0xC00D1BE2": {
        "name": "NS_E_INVALID_PIXEL_ASPECT_RATIO",
        "explanation": "The pixel aspect ratio value must be between 1 and 255.",
    },
    "0xC00D1BE3": {
        "name": "NS_E_AUDIENCE__LANGUAGE_CONTENTTYPE_MISMATCH",
        "explanation": "All streams with different languages in the same audience must have same properties.",
    },
    "0xC00D1BE4": {
        "name": "NS_E_INVALID_PROFILE_CONTENTTYPE",
        "explanation": "The profile must contain at least one audio or video stream.",
    },
    "0xC00D1BE5": {
        "name": "NS_E_TRANSFORM_PLUGIN_NOT_FOUND",
        "explanation": "The transform plug-in could not be found.",
    },
    "0xC00D1BE6": {
        "name": "NS_E_TRANSFORM_PLUGIN_INVALID",
        "explanation": "The transform plug-in is not valid. It might be damaged or you might not have the required permissions to access the plug-in.",
    },
    "0xC00D1BE7": {
        "name": "NS_E_EDL_REQUIRED_FOR_DEVICE_MULTIPASS",
        "explanation": "To use two-pass encoding, you must enable device control and setup an edit decision list (EDL) that has at least one entry.",
    },
    "0xC00D1BE8": {
        "name": "NS_E_INVALID_VIDEO_WIDTH_FOR_INTERLACED_ENCODING",
        "explanation": "When you choose to maintain the interlacing in your video, the output video size must be a multiple of 4.",
    },
    "0xC00D1BE9": {
        "name": "NS_E_MARKIN_UNSUPPORTED",
        "explanation": "Markin/Markout is unsupported with this source type.",
    },
    "0xC00D2711": {
        "name": "NS_E_DRM_INVALID_APPLICATION",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact product support for this application.",
    },
    "0xC00D2712": {
        "name": "NS_E_DRM_LICENSE_STORE_ERROR",
        "explanation": "License storage is not working. Contact Microsoft product support.",
    },
    "0xC00D2713": {
        "name": "NS_E_DRM_SECURE_STORE_ERROR",
        "explanation": "Secure storage is not working. Contact Microsoft product support.",
    },
    "0xC00D2714": {
        "name": "NS_E_DRM_LICENSE_STORE_SAVE_ERROR",
        "explanation": "License acquisition did not work. Acquire a new license or contact the content provider for further assistance.",
    },
    "0xC00D2715": {
        "name": "NS_E_DRM_SECURE_STORE_UNLOCK_ERROR",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2716": {
        "name": "NS_E_DRM_INVALID_CONTENT",
        "explanation": "The media file is corrupted. Contact the content provider to get a new file.",
    },
    "0xC00D2717": {
        "name": "NS_E_DRM_UNABLE_TO_OPEN_LICENSE",
        "explanation": "The license is corrupted. Acquire a new license.",
    },
    "0xC00D2718": {
        "name": "NS_E_DRM_INVALID_LICENSE",
        "explanation": "The license is corrupted or invalid. Acquire a new license",
    },
    "0xC00D2719": {
        "name": "NS_E_DRM_INVALID_MACHINE",
        "explanation": "Licenses cannot be copied from one computer to another. Use License Management to transfer licenses, or get a new license for the media file.",
    },
    "0xC00D271B": {
        "name": "NS_E_DRM_ENUM_LICENSE_FAILED",
        "explanation": "License storage is not working. Contact Microsoft product support.",
    },
    "0xC00D271C": {
        "name": "NS_E_DRM_INVALID_LICENSE_REQUEST",
        "explanation": "The media file is corrupted. Contact the content provider to get a new file.",
    },
    "0xC00D271D": {
        "name": "NS_E_DRM_UNABLE_TO_INITIALIZE",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D271E": {
        "name": "NS_E_DRM_UNABLE_TO_ACQUIRE_LICENSE",
        "explanation": "The license could not be acquired. Try again later.",
    },
    "0xC00D271F": {
        "name": "NS_E_DRM_INVALID_LICENSE_ACQUIRED",
        "explanation": "License acquisition did not work. Acquire a new license or contact the content provider for further assistance.",
    },
    "0xC00D2720": {
        "name": "NS_E_DRM_NO_RIGHTS",
        "explanation": "The requested operation cannot be performed on this file.",
    },
    "0xC00D2721": {
        "name": "NS_E_DRM_KEY_ERROR",
        "explanation": "The requested action cannot be performed because a problem occurred with the Windows Media Digital Rights Management (DRM) components on your computer.",
    },
    "0xC00D2722": {
        "name": "NS_E_DRM_ENCRYPT_ERROR",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2723": {
        "name": "NS_E_DRM_DECRYPT_ERROR",
        "explanation": "The media file is corrupted. Contact the content provider to get a new file.",
    },
    "0xC00D2725": {
        "name": "NS_E_DRM_LICENSE_INVALID_XML",
        "explanation": "The license is corrupted. Acquire a new license.",
    },
    "0xC00D2728": {
        "name": "NS_E_DRM_NEEDS_INDIVIDUALIZATION",
        "explanation": "A security upgrade is required to perform the operation on this media file.",
    },
    "0xC00D2729": {
        "name": "NS_E_DRM_ALREADY_INDIVIDUALIZED",
        "explanation": "You already have the latest security components. No upgrade is necessary at this time.",
    },
    "0xC00D272A": {
        "name": "NS_E_DRM_ACTION_NOT_QUERIED",
        "explanation": "The application cannot perform this action. Contact product support for this application.",
    },
    "0xC00D272B": {
        "name": "NS_E_DRM_ACQUIRING_LICENSE",
        "explanation": "You cannot begin a new license acquisition process until the current one has been completed.",
    },
    "0xC00D272C": {
        "name": "NS_E_DRM_INDIVIDUALIZING",
        "explanation": "You cannot begin a new security upgrade until the current one has been completed.",
    },
    "0xC00D272D": {"name": "NS_E_BACKUP_RESTORE_FAILURE", "explanation": "Failure in Backup-Restore."},
    "0xC00D272E": {"name": "NS_E_BACKUP_RESTORE_BAD_REQUEST_ID", "explanation": "Bad Request ID in Backup-Restore."},
    "0xC00D272F": {
        "name": "NS_E_DRM_PARAMETERS_MISMATCHED",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2730": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_LICENSE_OBJECT",
        "explanation": "A license cannot be created for this media file. Reinstall the application.",
    },
    "0xC00D2731": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_INDI_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2732": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_ENCRYPT_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2733": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_DECRYPT_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2734": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_PROPERTIES_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2735": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_BACKUP_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2736": {
        "name": "NS_E_DRM_INDIVIDUALIZE_ERROR",
        "explanation": "The security upgrade failed. Try again later.",
    },
    "0xC00D2737": {
        "name": "NS_E_DRM_LICENSE_OPEN_ERROR",
        "explanation": "License storage is not working. Contact Microsoft product support.",
    },
    "0xC00D2738": {
        "name": "NS_E_DRM_LICENSE_CLOSE_ERROR",
        "explanation": "License storage is not working. Contact Microsoft product support.",
    },
    "0xC00D2739": {
        "name": "NS_E_DRM_GET_LICENSE_ERROR",
        "explanation": "License storage is not working. Contact Microsoft product support.",
    },
    "0xC00D273A": {
        "name": "NS_E_DRM_QUERY_ERROR",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D273B": {
        "name": "NS_E_DRM_REPORT_ERROR",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact product support for this application.",
    },
    "0xC00D273C": {
        "name": "NS_E_DRM_GET_LICENSESTRING_ERROR",
        "explanation": "License storage is not working. Contact Microsoft product support.",
    },
    "0xC00D273D": {
        "name": "NS_E_DRM_GET_CONTENTSTRING_ERROR",
        "explanation": "The media file is corrupted. Contact the content provider to get a new file.",
    },
    "0xC00D273E": {
        "name": "NS_E_DRM_MONITOR_ERROR",
        "explanation": "A problem has occurred in the Digital Rights Management component. Try again later.",
    },
    "0xC00D273F": {
        "name": "NS_E_DRM_UNABLE_TO_SET_PARAMETER",
        "explanation": "The application has made an invalid call to the Digital Rights Management component. Contact product support for this application.",
    },
    "0xC00D2740": {
        "name": "NS_E_DRM_INVALID_APPDATA",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2741": {
        "name": "NS_E_DRM_INVALID_APPDATA_VERSION",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact product support for this application.",
    },
    "0xC00D2742": {"name": "NS_E_DRM_BACKUP_EXISTS", "explanation": "Licenses are already backed up in this location."},
    "0xC00D2743": {
        "name": "NS_E_DRM_BACKUP_CORRUPT",
        "explanation": "One or more backed-up licenses are missing or corrupt.",
    },
    "0xC00D2744": {
        "name": "NS_E_DRM_BACKUPRESTORE_BUSY",
        "explanation": "You cannot begin a new backup process until the current process has been completed.",
    },
    "0xC00D2745": {"name": "NS_E_BACKUP_RESTORE_BAD_DATA", "explanation": "Bad Data sent to Backup-Restore."},
    "0xC00D2748": {
        "name": "NS_E_DRM_LICENSE_UNUSABLE",
        "explanation": "The license is invalid. Contact the content provider for further assistance.",
    },
    "0xC00D2749": {
        "name": "NS_E_DRM_INVALID_PROPERTY",
        "explanation": "A required property was not set by the application. Contact product support for this application.",
    },
    "0xC00D274A": {
        "name": "NS_E_DRM_SECURE_STORE_NOT_FOUND",
        "explanation": "A problem has occurred in the Digital Rights Management component of this application. Try to acquire a license again.",
    },
    "0xC00D274B": {
        "name": "NS_E_DRM_CACHED_CONTENT_ERROR",
        "explanation": "A license cannot be found for this media file. Use License Management to transfer a license for this file from the original computer, or acquire a new license.",
    },
    "0xC00D274C": {
        "name": "NS_E_DRM_INDIVIDUALIZATION_INCOMPLETE",
        "explanation": "A problem occurred during the security upgrade. Try again later.",
    },
    "0xC00D274D": {
        "name": "NS_E_DRM_DRIVER_AUTH_FAILURE",
        "explanation": "Certified driver components are required to play this media file. Contact Windows Update to see whether updated drivers are available for your hardware.",
    },
    "0xC00D274E": {
        "name": "NS_E_DRM_NEED_UPGRADE_MSSAP",
        "explanation": "One or more of the Secure Audio Path components were not found or an entry point in those components was not found.",
    },
    "0xC00D274F": {"name": "NS_E_DRM_REOPEN_CONTENT", "explanation": "Status message: Reopen the file."},
    "0xC00D2750": {
        "name": "NS_E_DRM_DRIVER_DIGIOUT_FAILURE",
        "explanation": "Certain driver functionality is required to play this media file. Contact Windows Update to see whether updated drivers are available for your hardware.",
    },
    "0xC00D2751": {
        "name": "NS_E_DRM_INVALID_SECURESTORE_PASSWORD",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2752": {
        "name": "NS_E_DRM_APPCERT_REVOKED",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2753": {"name": "NS_E_DRM_RESTORE_FRAUD", "explanation": "You cannot restore your license(s)."},
    "0xC00D2754": {
        "name": "NS_E_DRM_HARDWARE_INCONSISTENT",
        "explanation": "The licenses for your media files are corrupted. Contact Microsoft product support.",
    },
    "0xC00D2755": {
        "name": "NS_E_DRM_SDMI_TRIGGER",
        "explanation": "To transfer this media file, you must upgrade the application.",
    },
    "0xC00D2756": {
        "name": "NS_E_DRM_SDMI_NOMORECOPIES",
        "explanation": "You cannot make any more copies of this media file.",
    },
    "0xC00D2757": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_HEADER_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2758": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_KEYS_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2759": {"name": "NS_E_DRM_LICENSE_NOTACQUIRED", "explanation": "Unable to obtain license."},
    "0xC00D275A": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_CODING_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D275B": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_STATE_DATA_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D275C": {"name": "NS_E_DRM_BUFFER_TOO_SMALL", "explanation": "The buffer supplied is not sufficient."},
    "0xC00D275D": {"name": "NS_E_DRM_UNSUPPORTED_PROPERTY", "explanation": "The property requested is not supported."},
    "0xC00D275E": {
        "name": "NS_E_DRM_ERROR_BAD_NET_RESP",
        "explanation": "The specified server cannot perform the requested operation.",
    },
    "0xC00D275F": {"name": "NS_E_DRM_STORE_NOTALLSTORED", "explanation": "Some of the licenses could not be stored."},
    "0xC00D2760": {
        "name": "NS_E_DRM_SECURITY_COMPONENT_SIGNATURE_INVALID",
        "explanation": "The Digital Rights Management security upgrade component could not be validated. Contact Microsoft product support.",
    },
    "0xC00D2761": {"name": "NS_E_DRM_INVALID_DATA", "explanation": "Invalid or corrupt data was encountered."},
    "0xC00D2762": {
        "name": "NS_E_DRM_POLICY_DISABLE_ONLINE",
        "explanation": "The Windows Media Digital Rights Management system cannot perform the requested action because your computer or network administrator has enabled the group policy Prevent Windows Media DRM Internet Access. For assistance, contact your administrator.",
    },
    "0xC00D2763": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_AUTHENTICATION_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2764": {
        "name": "NS_E_DRM_NOT_CONFIGURED",
        "explanation": "Not all of the necessary properties for DRM have been set.",
    },
    "0xC00D2765": {
        "name": "NS_E_DRM_DEVICE_ACTIVATION_CANCELED",
        "explanation": "The portable device does not have the security required to copy protected files to it. To obtain the additional security, try to copy the file to your portable device again. When a message appears, click OK.",
    },
    "0xC00D2766": {"name": "NS_E_BACKUP_RESTORE_TOO_MANY_RESETS", "explanation": "Too many resets in Backup-Restore."},
    "0xC00D2767": {
        "name": "NS_E_DRM_DEBUGGING_NOT_ALLOWED",
        "explanation": "Running this process under a debugger while using DRM content is not allowed.",
    },
    "0xC00D2768": {"name": "NS_E_DRM_OPERATION_CANCELED", "explanation": "The user canceled the DRM operation."},
    "0xC00D2769": {
        "name": "NS_E_DRM_RESTRICTIONS_NOT_RETRIEVED",
        "explanation": "The license you are using has assocaited output restrictions. This license is unusable until these restrictions are queried.",
    },
    "0xC00D276A": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_PLAYLIST_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D276B": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_PLAYLIST_BURN_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D276C": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_DEVICE_REGISTRATION_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D276D": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_METERING_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2770": {
        "name": "NS_E_DRM_TRACK_EXCEEDED_PLAYLIST_RESTICTION",
        "explanation": "The specified track has exceeded it's specified playlist burn limit in this playlist.",
    },
    "0xC00D2771": {
        "name": "NS_E_DRM_TRACK_EXCEEDED_TRACKBURN_RESTRICTION",
        "explanation": "The specified track has exceeded it's track burn limit.",
    },
    "0xC00D2772": {
        "name": "NS_E_DRM_UNABLE_TO_GET_DEVICE_CERT",
        "explanation": "A problem has occurred in obtaining the device's certificate. Contact Microsoft product support.",
    },
    "0xC00D2773": {
        "name": "NS_E_DRM_UNABLE_TO_GET_SECURE_CLOCK",
        "explanation": "A problem has occurred in obtaining the device's secure clock. Contact Microsoft product support.",
    },
    "0xC00D2774": {
        "name": "NS_E_DRM_UNABLE_TO_SET_SECURE_CLOCK",
        "explanation": "A problem has occurred in setting the device's secure clock. Contact Microsoft product support.",
    },
    "0xC00D2775": {
        "name": "NS_E_DRM_UNABLE_TO_GET_SECURE_CLOCK_FROM_SERVER",
        "explanation": "A problem has occurred in obtaining the secure clock from server. Contact Microsoft product support.",
    },
    "0xC00D2776": {
        "name": "NS_E_DRM_POLICY_METERING_DISABLED",
        "explanation": "This content requires the metering policy to be enabled.",
    },
    "0xC00D2777": {
        "name": "NS_E_DRM_TRANSFER_CHAINED_LICENSES_UNSUPPORTED",
        "explanation": "Transfer of chained licenses unsupported.",
    },
    "0xC00D2778": {
        "name": "NS_E_DRM_SDK_VERSIONMISMATCH",
        "explanation": "The Digital Rights Management component is not installed properly. Reinstall the Player.",
    },
    "0xC00D2779": {
        "name": "NS_E_DRM_LIC_NEEDS_DEVICE_CLOCK_SET",
        "explanation": "The file could not be transferred because the device clock is not set.",
    },
    "0xC00D277A": {
        "name": "NS_E_LICENSE_HEADER_MISSING_URL",
        "explanation": "The content header is missing an acquisition URL.",
    },
    "0xC00D277B": {
        "name": "NS_E_DEVICE_NOT_WMDRM_DEVICE",
        "explanation": "The current attached device does not support WMDRM.",
    },
    "0xC00D277C": {
        "name": "NS_E_DRM_INVALID_APPCERT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D277D": {
        "name": "NS_E_DRM_PROTOCOL_FORCEFUL_TERMINATION_ON_PETITION",
        "explanation": "The client application has been forcefully terminated during a DRM petition.",
    },
    "0xC00D277E": {
        "name": "NS_E_DRM_PROTOCOL_FORCEFUL_TERMINATION_ON_CHALLENGE",
        "explanation": "The client application has been forcefully terminated during a DRM challenge.",
    },
    "0xC00D277F": {
        "name": "NS_E_DRM_CHECKPOINT_FAILED",
        "explanation": "Secure storage protection error. Restore your licenses from a previous backup and try again.",
    },
    "0xC00D2780": {
        "name": "NS_E_DRM_BB_UNABLE_TO_INITIALIZE",
        "explanation": "A problem has occurred in the Digital Rights Management root of trust. Contact Microsoft product support.",
    },
    "0xC00D2781": {
        "name": "NS_E_DRM_UNABLE_TO_LOAD_HARDWARE_ID",
        "explanation": "A problem has occurred in retrieving the Digital Rights Management machine identification. Contact Microsoft product support.",
    },
    "0xC00D2782": {
        "name": "NS_E_DRM_UNABLE_TO_OPEN_DATA_STORE",
        "explanation": "A problem has occurred in opening the Digital Rights Management data storage file. Contact Microsoft product.",
    },
    "0xC00D2783": {
        "name": "NS_E_DRM_DATASTORE_CORRUPT",
        "explanation": "The Digital Rights Management data storage is not functioning properly. Contact Microsoft product support.",
    },
    "0xC00D2784": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_INMEMORYSTORE_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2785": {
        "name": "NS_E_DRM_STUBLIB_REQUIRED",
        "explanation": "A secured library is required to access the requested functionality.",
    },
    "0xC00D2786": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_CERTIFICATE_OBJECT",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2787": {
        "name": "NS_E_DRM_MIGRATION_TARGET_NOT_ONLINE",
        "explanation": "A problem has occurred in the Digital Rights Management component during license migration. Contact Microsoft product support.",
    },
    "0xC00D2788": {
        "name": "NS_E_DRM_INVALID_MIGRATION_IMAGE",
        "explanation": "A problem has occurred in the Digital Rights Management component during license migration. Contact Microsoft product support.",
    },
    "0xC00D2789": {
        "name": "NS_E_DRM_MIGRATION_TARGET_STATES_CORRUPTED",
        "explanation": "A problem has occurred in the Digital Rights Management component during license migration. Contact Microsoft product support.",
    },
    "0xC00D278A": {
        "name": "NS_E_DRM_MIGRATION_IMPORTER_NOT_AVAILABLE",
        "explanation": "A problem has occurred in the Digital Rights Management component during license migration. Contact Microsoft product support.",
    },
    "0xC00D278B": {
        "name": "NS_DRM_E_MIGRATION_UPGRADE_WITH_DIFF_SID",
        "explanation": "A problem has occurred in the Digital Rights Management component during license migration. Contact Microsoft product support.",
    },
    "0xC00D278C": {
        "name": "NS_DRM_E_MIGRATION_SOURCE_MACHINE_IN_USE",
        "explanation": "The Digital Rights Management component is in use during license migration. Contact Microsoft product support.",
    },
    "0xC00D278D": {
        "name": "NS_DRM_E_MIGRATION_TARGET_MACHINE_LESS_THAN_LH",
        "explanation": "Licenses are being migrated to a machine running XP or downlevel OS. This operation can only be performed on Windows Vista or a later OS. Contact Microsoft product support.",
    },
    "0xC00D278E": {
        "name": "NS_DRM_E_MIGRATION_IMAGE_ALREADY_EXISTS",
        "explanation": "Migration Image already exists. Contact Microsoft product support.",
    },
    "0xC00D278F": {
        "name": "NS_E_DRM_HARDWAREID_MISMATCH",
        "explanation": "The requested action cannot be performed because a hardware configuration change has been detected by the Windows Media Digital Rights Management (DRM) components on your computer.",
    },
    "0xC00D2790": {
        "name": "NS_E_INVALID_DRMV2CLT_STUBLIB",
        "explanation": "The wrong stublib has been linked to an application or DLL using drmv2clt.dll.",
    },
    "0xC00D2791": {
        "name": "NS_E_DRM_MIGRATION_INVALID_LEGACYV2_DATA",
        "explanation": "The legacy V2 data being imported is invalid.",
    },
    "0xC00D2792": {
        "name": "NS_E_DRM_MIGRATION_LICENSE_ALREADY_EXISTS",
        "explanation": "The license being imported already exists.",
    },
    "0xC00D2793": {
        "name": "NS_E_DRM_MIGRATION_INVALID_LEGACYV2_SST_PASSWORD",
        "explanation": "The password of the Legacy V2 SST entry being imported is incorrect.",
    },
    "0xC00D2794": {
        "name": "NS_E_DRM_MIGRATION_NOT_SUPPORTED",
        "explanation": "Migration is not supported by the plugin.",
    },
    "0xC00D2795": {
        "name": "NS_E_DRM_UNABLE_TO_CREATE_MIGRATION_IMPORTER_OBJECT",
        "explanation": "A migration importer cannot be created for this media file. Reinstall the application.",
    },
    "0xC00D2796": {
        "name": "NS_E_DRM_CHECKPOINT_MISMATCH",
        "explanation": "The requested action cannot be performed because a problem occurred with the Windows Media Digital Rights Management (DRM) components on your computer.",
    },
    "0xC00D2797": {
        "name": "NS_E_DRM_CHECKPOINT_CORRUPT",
        "explanation": "The requested action cannot be performed because a problem occurred with the Windows Media Digital Rights Management (DRM) components on your computer.",
    },
    "0xC00D2798": {
        "name": "NS_E_REG_FLUSH_FAILURE",
        "explanation": "The requested action cannot be performed because a problem occurred with the Windows Media Digital Rights Management (DRM) components on your computer.",
    },
    "0xC00D2799": {
        "name": "NS_E_HDS_KEY_MISMATCH",
        "explanation": "The requested action cannot be performed because a problem occurred with the Windows Media Digital Rights Management (DRM) components on your computer.",
    },
    "0xC00D279A": {
        "name": "NS_E_DRM_MIGRATION_OPERATION_CANCELLED",
        "explanation": "Migration was canceled by the user.",
    },
    "0xC00D279B": {
        "name": "NS_E_DRM_MIGRATION_OBJECT_IN_USE",
        "explanation": "Migration object is already in use and cannot be called until the current operation completes.",
    },
    "0xC00D279C": {
        "name": "NS_E_DRM_MALFORMED_CONTENT_HEADER",
        "explanation": "The content header does not comply with DRM requirements and cannot be used.",
    },
    "0xC00D27D8": {
        "name": "NS_E_DRM_LICENSE_EXPIRED",
        "explanation": "The license for this file has expired and is no longer valid. Contact your content provider for further assistance.",
    },
    "0xC00D27D9": {
        "name": "NS_E_DRM_LICENSE_NOTENABLED",
        "explanation": "The license for this file is not valid yet, but will be at a future date.",
    },
    "0xC00D27DA": {
        "name": "NS_E_DRM_LICENSE_APPSECLOW",
        "explanation": "The license for this file requires a higher level of security than the player you are currently using has. Try using a different player or download a newer version of your current player.",
    },
    "0xC00D27DB": {
        "name": "NS_E_DRM_STORE_NEEDINDI",
        "explanation": "The license cannot be stored as it requires security upgrade of Digital Rights Management component.",
    },
    "0xC00D27DC": {
        "name": "NS_E_DRM_STORE_NOTALLOWED",
        "explanation": "Your machine does not meet the requirements for storing the license.",
    },
    "0xC00D27DD": {
        "name": "NS_E_DRM_LICENSE_APP_NOTALLOWED",
        "explanation": "The license for this file requires an upgraded version of your player or a different player.",
    },
    "0xC00D27DF": {
        "name": "NS_E_DRM_LICENSE_CERT_EXPIRED",
        "explanation": "The license server's certificate expired. Make sure your system clock is set correctly. Contact your content provider for further assistance.",
    },
    "0xC00D27E0": {
        "name": "NS_E_DRM_LICENSE_SECLOW",
        "explanation": "The license for this file requires a higher level of security than the player you are currently using has. Try using a different player or download a newer version of your current player.",
    },
    "0xC00D27E1": {
        "name": "NS_E_DRM_LICENSE_CONTENT_REVOKED",
        "explanation": "The content owner for the license you just acquired is no longer supporting their content. Contact the content owner for a newer version of the content.",
    },
    "0xC00D27E2": {
        "name": "NS_E_DRM_DEVICE_NOT_REGISTERED",
        "explanation": "The content owner for the license you just acquired requires your device to register to the current machine.",
    },
    "0xC00D280A": {
        "name": "NS_E_DRM_LICENSE_NOSAP",
        "explanation": "The license for this file requires a feature that is not supported in your current player or operating system. You can try with newer version of your current player or contact your content provider for further assistance.",
    },
    "0xC00D280B": {
        "name": "NS_E_DRM_LICENSE_NOSVP",
        "explanation": "The license for this file requires a feature that is not supported in your current player or operating system. You can try with newer version of your current player or contact your content provider for further assistance.",
    },
    "0xC00D280C": {
        "name": "NS_E_DRM_LICENSE_NOWDM",
        "explanation": "The license for this file requires Windows Driver Model (WDM) audio drivers. Contact your sound card manufacturer for further assistance.",
    },
    "0xC00D280D": {
        "name": "NS_E_DRM_LICENSE_NOTRUSTEDCODEC",
        "explanation": "The license for this file requires a higher level of security than the player you are currently using has. Try using a different player or download a newer version of your current player.",
    },
    "0xC00D280E": {
        "name": "NS_E_DRM_SOURCEID_NOT_SUPPORTED",
        "explanation": "The license for this file is not supported by your current player. You can try with newer version of your current player or contact your content provider for further assistance.",
    },
    "0xC00D283D": {
        "name": "NS_E_DRM_NEEDS_UPGRADE_TEMPFILE",
        "explanation": "An updated version of your media player is required to play the selected content.",
    },
    "0xC00D283E": {
        "name": "NS_E_DRM_NEED_UPGRADE_PD",
        "explanation": "A new version of the Digital Rights Management component is required. Contact product support for this application to get the latest version.",
    },
    "0xC00D283F": {
        "name": "NS_E_DRM_SIGNATURE_FAILURE",
        "explanation": "Failed to either create or verify the content header.",
    },
    "0xC00D2840": {
        "name": "NS_E_DRM_LICENSE_SERVER_INFO_MISSING",
        "explanation": "Could not read the necessary information from the system registry.",
    },
    "0xC00D2841": {
        "name": "NS_E_DRM_BUSY",
        "explanation": "The DRM subsystem is currently locked by another application or user. Try again later.",
    },
    "0xC00D2842": {
        "name": "NS_E_DRM_PD_TOO_MANY_DEVICES",
        "explanation": "There are too many target devices registered on the portable media.",
    },
    "0xC00D2843": {
        "name": "NS_E_DRM_INDIV_FRAUD",
        "explanation": "The security upgrade cannot be completed because the allowed number of daily upgrades has been exceeded. Try again tomorrow.",
    },
    "0xC00D2844": {
        "name": "NS_E_DRM_INDIV_NO_CABS",
        "explanation": "The security upgrade cannot be completed because the server is unable to perform the operation. Try again later.",
    },
    "0xC00D2845": {
        "name": "NS_E_DRM_INDIV_SERVICE_UNAVAILABLE",
        "explanation": "The security upgrade cannot be performed because the server is not available. Try again later.",
    },
    "0xC00D2846": {
        "name": "NS_E_DRM_RESTORE_SERVICE_UNAVAILABLE",
        "explanation": "Windows Media Player cannot restore your licenses because the server is not available. Try again later.",
    },
    "0xC00D2847": {
        "name": "NS_E_DRM_CLIENT_CODE_EXPIRED",
        "explanation": "Windows Media Player cannot play the protected file. Verify that your computer's date is set correctly. If it is correct, on the Help menu, click Check for Player Updates to install the latest version of the Player.",
    },
    "0xC00D2848": {
        "name": "NS_E_DRM_NO_UPLINK_LICENSE",
        "explanation": "The chained license cannot be created because the referenced uplink license does not exist.",
    },
    "0xC00D2849": {"name": "NS_E_DRM_INVALID_KID", "explanation": "The specified KID is invalid."},
    "0xC00D284A": {
        "name": "NS_E_DRM_LICENSE_INITIALIZATION_ERROR",
        "explanation": "License initialization did not work. Contact Microsoft product support.",
    },
    "0xC00D284C": {
        "name": "NS_E_DRM_CHAIN_TOO_LONG",
        "explanation": "The uplink license of a chained license cannot itself be a chained license.",
    },
    "0xC00D284D": {
        "name": "NS_E_DRM_UNSUPPORTED_ALGORITHM",
        "explanation": "The specified encryption algorithm is unsupported.",
    },
    "0xC00D284E": {
        "name": "NS_E_DRM_LICENSE_DELETION_ERROR",
        "explanation": "License deletion did not work. Contact Microsoft product support.",
    },
    "0xC00D28A0": {
        "name": "NS_E_DRM_INVALID_CERTIFICATE",
        "explanation": "The client's certificate is corrupted or the signature cannot be verified.",
    },
    "0xC00D28A1": {"name": "NS_E_DRM_CERTIFICATE_REVOKED", "explanation": "The client's certificate has been revoked."},
    "0xC00D28A2": {
        "name": "NS_E_DRM_LICENSE_UNAVAILABLE",
        "explanation": "There is no license available for the requested action.",
    },
    "0xC00D28A3": {
        "name": "NS_E_DRM_DEVICE_LIMIT_REACHED",
        "explanation": "The maximum number of devices in use has been reached. Unable to open additional devices.",
    },
    "0xC00D28A4": {
        "name": "NS_E_DRM_UNABLE_TO_VERIFY_PROXIMITY",
        "explanation": "The proximity detection procedure could not confirm that the receiver is near the transmitter in the network.",
    },
    "0xC00D28A5": {
        "name": "NS_E_DRM_MUST_REGISTER",
        "explanation": "The client must be registered before executing the intended operation.",
    },
    "0xC00D28A6": {
        "name": "NS_E_DRM_MUST_APPROVE",
        "explanation": "The client must be approved before executing the intended operation.",
    },
    "0xC00D28A7": {
        "name": "NS_E_DRM_MUST_REVALIDATE",
        "explanation": "The client must be revalidated before executing the intended operation.",
    },
    "0xC00D28A8": {
        "name": "NS_E_DRM_INVALID_PROXIMITY_RESPONSE",
        "explanation": "The response to the proximity detection challenge is invalid.",
    },
    "0xC00D28A9": {"name": "NS_E_DRM_INVALID_SESSION", "explanation": "The requested session is invalid."},
    "0xC00D28AA": {
        "name": "NS_E_DRM_DEVICE_NOT_OPEN",
        "explanation": "The device must be opened before it can be used to receive content.",
    },
    "0xC00D28AB": {
        "name": "NS_E_DRM_DEVICE_ALREADY_REGISTERED",
        "explanation": "Device registration failed because the device is already registered.",
    },
    "0xC00D28AC": {
        "name": "NS_E_DRM_UNSUPPORTED_PROTOCOL_VERSION",
        "explanation": "Unsupported WMDRM-ND protocol version.",
    },
    "0xC00D28AD": {"name": "NS_E_DRM_UNSUPPORTED_ACTION", "explanation": "The requested action is not supported."},
    "0xC00D28AE": {
        "name": "NS_E_DRM_CERTIFICATE_SECURITY_LEVEL_INADEQUATE",
        "explanation": "The certificate does not have an adequate security level for the requested action.",
    },
    "0xC00D28AF": {
        "name": "NS_E_DRM_UNABLE_TO_OPEN_PORT",
        "explanation": "Unable to open the specified port for receiving Proximity messages.",
    },
    "0xC00D28B0": {"name": "NS_E_DRM_BAD_REQUEST", "explanation": "The message format is invalid."},
    "0xC00D28B1": {
        "name": "NS_E_DRM_INVALID_CRL",
        "explanation": "The Certificate Revocation List is invalid or corrupted.",
    },
    "0xC00D28B2": {
        "name": "NS_E_DRM_ATTRIBUTE_TOO_LONG",
        "explanation": "The length of the attribute name or value is too long.",
    },
    "0xC00D28B3": {
        "name": "NS_E_DRM_EXPIRED_LICENSEBLOB",
        "explanation": "The license blob passed in the cardea request is expired.",
    },
    "0xC00D28B4": {
        "name": "NS_E_DRM_INVALID_LICENSEBLOB",
        "explanation": "The license blob passed in the cardea request is invalid. Contact Microsoft product support.",
    },
    "0xC00D28B5": {
        "name": "NS_E_DRM_INCLUSION_LIST_REQUIRED",
        "explanation": "The requested operation cannot be performed because the license does not contain an inclusion list.",
    },
    "0xC00D28B6": {
        "name": "NS_E_DRM_DRMV2CLT_REVOKED",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D28B7": {
        "name": "NS_E_DRM_RIV_TOO_SMALL",
        "explanation": "A problem has occurred in the Digital Rights Management component. Contact Microsoft product support.",
    },
    "0xC00D2904": {
        "name": "NS_E_OUTPUT_PROTECTION_LEVEL_UNSUPPORTED",
        "explanation": "Windows Media Player does not support the level of output protection required by the content.",
    },
    "0xC00D2905": {
        "name": "NS_E_COMPRESSED_DIGITAL_VIDEO_PROTECTION_LEVEL_UNSUPPORTED",
        "explanation": "Windows Media Player does not support the level of protection required for compressed digital video.",
    },
    "0xC00D2906": {
        "name": "NS_E_UNCOMPRESSED_DIGITAL_VIDEO_PROTECTION_LEVEL_UNSUPPORTED",
        "explanation": "Windows Media Player does not support the level of protection required for uncompressed digital video.",
    },
    "0xC00D2907": {
        "name": "NS_E_ANALOG_VIDEO_PROTECTION_LEVEL_UNSUPPORTED",
        "explanation": "Windows Media Player does not support the level of protection required for analog video.",
    },
    "0xC00D2908": {
        "name": "NS_E_COMPRESSED_DIGITAL_AUDIO_PROTECTION_LEVEL_UNSUPPORTED",
        "explanation": "Windows Media Player does not support the level of protection required for compressed digital audio.",
    },
    "0xC00D2909": {
        "name": "NS_E_UNCOMPRESSED_DIGITAL_AUDIO_PROTECTION_LEVEL_UNSUPPORTED",
        "explanation": "Windows Media Player does not support the level of protection required for uncompressed digital audio.",
    },
    "0xC00D290A": {
        "name": "NS_E_OUTPUT_PROTECTION_SCHEME_UNSUPPORTED",
        "explanation": "Windows Media Player does not support the scheme of output protection required by the content.",
    },
    "0xC00D2AFA": {
        "name": "NS_E_REBOOT_RECOMMENDED",
        "explanation": "Installation was not successful and some file cleanup is not complete. For best results, restart your computer.",
    },
    "0xC00D2AFB": {
        "name": "NS_E_REBOOT_REQUIRED",
        "explanation": "Installation was not successful. To continue, you must restart your computer.",
    },
    "0xC00D2AFC": {"name": "NS_E_SETUP_INCOMPLETE", "explanation": "Installation was not successful."},
    "0xC00D2AFD": {
        "name": "NS_E_SETUP_DRM_MIGRATION_FAILED",
        "explanation": "Setup cannot migrate the Windows Media Digital Rights Management (DRM) components.",
    },
    "0xC00D2AFE": {
        "name": "NS_E_SETUP_IGNORABLE_FAILURE",
        "explanation": "Some skin or playlist components cannot be installed.",
    },
    "0xC00D2AFF": {
        "name": "NS_E_SETUP_DRM_MIGRATION_FAILED_AND_IGNORABLE_FAILURE",
        "explanation": "Setup cannot migrate the Windows Media Digital Rights Management (DRM) components. In addition, some skin or playlist components cannot be installed.",
    },
    "0xC00D2B00": {
        "name": "NS_E_SETUP_BLOCKED",
        "explanation": "Installation is blocked because your computer does not meet one or more of the setup requirements.",
    },
    "0xC00D2EE0": {"name": "NS_E_UNKNOWN_PROTOCOL", "explanation": "The specified protocol is not supported."},
    "0xC00D2EE1": {"name": "NS_E_REDIRECT_TO_PROXY", "explanation": "The client is redirected to a proxy server."},
    "0xC00D2EE2": {
        "name": "NS_E_INTERNAL_SERVER_ERROR",
        "explanation": "The server encountered an unexpected condition which prevented it from fulfilling the request.",
    },
    "0xC00D2EE3": {"name": "NS_E_BAD_REQUEST", "explanation": "The request could not be understood by the server."},
    "0xC00D2EE4": {
        "name": "NS_E_ERROR_FROM_PROXY",
        "explanation": "The proxy experienced an error while attempting to contact the media server.",
    },
    "0xC00D2EE5": {
        "name": "NS_E_PROXY_TIMEOUT",
        "explanation": "The proxy did not receive a timely response while attempting to contact the media server.",
    },
    "0xC00D2EE6": {
        "name": "NS_E_SERVER_UNAVAILABLE",
        "explanation": "The server is currently unable to handle the request due to a temporary overloading or maintenance of the server.",
    },
    "0xC00D2EE7": {
        "name": "NS_E_REFUSED_BY_SERVER",
        "explanation": "The server is refusing to fulfill the requested operation.",
    },
    "0xC00D2EE8": {
        "name": "NS_E_INCOMPATIBLE_SERVER",
        "explanation": "The server is not a compatible streaming media server.",
    },
    "0xC00D2EE9": {
        "name": "NS_E_MULTICAST_DISABLED",
        "explanation": "The content cannot be streamed because the Multicast protocol has been disabled.",
    },
    "0xC00D2EEA": {
        "name": "NS_E_INVALID_REDIRECT",
        "explanation": "The server redirected the player to an invalid location.",
    },
    "0xC00D2EEB": {
        "name": "NS_E_ALL_PROTOCOLS_DISABLED",
        "explanation": "The content cannot be streamed because all protocols have been disabled.",
    },
    "0xC00D2EEC": {
        "name": "NS_E_MSBD_NO_LONGER_SUPPORTED",
        "explanation": "The MSBD protocol is no longer supported. Please use HTTP to connect to the Windows Media stream.",
    },
    "0xC00D2EED": {
        "name": "NS_E_PROXY_NOT_FOUND",
        "explanation": "The proxy server could not be located. Please check your proxy server configuration.",
    },
    "0xC00D2EEE": {
        "name": "NS_E_CANNOT_CONNECT_TO_PROXY",
        "explanation": "Unable to establish a connection to the proxy server. Please check your proxy server configuration.",
    },
    "0xC00D2EEF": {
        "name": "NS_E_SERVER_DNS_TIMEOUT",
        "explanation": "Unable to locate the media server. The operation timed out.",
    },
    "0xC00D2EF0": {
        "name": "NS_E_PROXY_DNS_TIMEOUT",
        "explanation": "Unable to locate the proxy server. The operation timed out.",
    },
    "0xC00D2EF1": {"name": "NS_E_CLOSED_ON_SUSPEND", "explanation": "Media closed because Windows was shut down."},
    "0xC00D2EF2": {
        "name": "NS_E_CANNOT_READ_PLAYLIST_FROM_MEDIASERVER",
        "explanation": "Unable to read the contents of a playlist file from a media server.",
    },
    "0xC00D2EF3": {"name": "NS_E_SESSION_NOT_FOUND", "explanation": "Session not found."},
    "0xC00D2EF4": {
        "name": "NS_E_REQUIRE_STREAMING_CLIENT",
        "explanation": "Content requires a streaming media client.",
    },
    "0xC00D2EF5": {
        "name": "NS_E_PLAYLIST_ENTRY_HAS_CHANGED",
        "explanation": "A command applies to a previous playlist entry.",
    },
    "0xC00D2EF6": {
        "name": "NS_E_PROXY_ACCESSDENIED",
        "explanation": "The proxy server is denying access. The username and/or password might be incorrect.",
    },
    "0xC00D2EF7": {
        "name": "NS_E_PROXY_SOURCE_ACCESSDENIED",
        "explanation": "The proxy could not provide valid authentication credentials to the media server.",
    },
    "0xC00D2EF8": {
        "name": "NS_E_NETWORK_SINK_WRITE",
        "explanation": "The network sink failed to write data to the network.",
    },
    "0xC00D2EF9": {
        "name": "NS_E_FIREWALL",
        "explanation": "Packets are not being received from the server. The packets might be blocked by a filtering device, such as a network firewall.",
    },
    "0xC00D2EFA": {
        "name": "NS_E_MMS_NOT_SUPPORTED",
        "explanation": "The MMS protocol is not supported. Please use HTTP or RTSP to connect to the Windows Media stream.",
    },
    "0xC00D2EFB": {
        "name": "NS_E_SERVER_ACCESSDENIED",
        "explanation": "The Windows Media server is denying access. The username and/or password might be incorrect.",
    },
    "0xC00D2EFC": {
        "name": "NS_E_RESOURCE_GONE",
        "explanation": "The Publishing Point or file on the Windows Media Server is no longer available.",
    },
    "0xC00D2EFD": {
        "name": "NS_E_NO_EXISTING_PACKETIZER",
        "explanation": "There is no existing packetizer plugin for a stream.",
    },
    "0xC00D2EFE": {
        "name": "NS_E_BAD_SYNTAX_IN_SERVER_RESPONSE",
        "explanation": "The response from the media server could not be understood. This might be caused by an incompatible proxy server or media server.",
    },
    "0xC00D2F00": {
        "name": "NS_E_RESET_SOCKET_CONNECTION",
        "explanation": "The Windows Media Server reset the network connection.",
    },
    "0xC00D2F02": {
        "name": "NS_E_TOO_MANY_HOPS",
        "explanation": "The request could not reach the media server (too many hops).",
    },
    "0xC00D2F05": {
        "name": "NS_E_TOO_MUCH_DATA_FROM_SERVER",
        "explanation": "The server is sending too much data. The connection has been terminated.",
    },
    "0xC00D2F06": {
        "name": "NS_E_CONNECT_TIMEOUT",
        "explanation": "It was not possible to establish a connection to the media server in a timely manner. The media server might be down for maintenance, or it might be necessary to use a proxy server to access this media server.",
    },
    "0xC00D2F07": {
        "name": "NS_E_PROXY_CONNECT_TIMEOUT",
        "explanation": "It was not possible to establish a connection to the proxy server in a timely manner. Please check your proxy server configuration.",
    },
    "0xC00D2F08": {"name": "NS_E_SESSION_INVALID", "explanation": "Session not found."},
    "0xC00D2F0A": {"name": "NS_E_PACKETSINK_UNKNOWN_FEC_STREAM", "explanation": "Unknown packet sink stream."},
    "0xC00D2F0B": {
        "name": "NS_E_PUSH_CANNOTCONNECT",
        "explanation": "Unable to establish a connection to the server. Ensure Windows Media Services is started and the HTTP Server control protocol is properly enabled.",
    },
    "0xC00D2F0C": {
        "name": "NS_E_INCOMPATIBLE_PUSH_SERVER",
        "explanation": "The Server service that received the HTTP push request is not a compatible version of Windows Media Services (WMS). This error might indicate the push request was received by IIS instead of WMS. Ensure WMS is started and has the HTTP Server control protocol properly enabled and try again.",
    },
    "0xC00D32C8": {"name": "NS_E_END_OF_PLAYLIST", "explanation": "The playlist has reached its end."},
    "0xC00D32C9": {"name": "NS_E_USE_FILE_SOURCE", "explanation": "Use file source."},
    "0xC00D32CA": {"name": "NS_E_PROPERTY_NOT_FOUND", "explanation": "The property was not found."},
    "0xC00D32CC": {"name": "NS_E_PROPERTY_READ_ONLY", "explanation": "The property is read only."},
    "0xC00D32CD": {"name": "NS_E_TABLE_KEY_NOT_FOUND", "explanation": "The table key was not found."},
    "0xC00D32CF": {"name": "NS_E_INVALID_QUERY_OPERATOR", "explanation": "Invalid query operator."},
    "0xC00D32D0": {"name": "NS_E_INVALID_QUERY_PROPERTY", "explanation": "Invalid query property."},
    "0xC00D32D2": {"name": "NS_E_PROPERTY_NOT_SUPPORTED", "explanation": "The property is not supported."},
    "0xC00D32D4": {"name": "NS_E_SCHEMA_CLASSIFY_FAILURE", "explanation": "Schema classification failure."},
    "0xC00D32D5": {
        "name": "NS_E_METADATA_FORMAT_NOT_SUPPORTED",
        "explanation": "The metadata format is not supported.",
    },
    "0xC00D32D6": {"name": "NS_E_METADATA_NO_EDITING_CAPABILITY", "explanation": "Cannot edit the metadata."},
    "0xC00D32D7": {"name": "NS_E_METADATA_CANNOT_SET_LOCALE", "explanation": "Cannot set the locale id."},
    "0xC00D32D8": {
        "name": "NS_E_METADATA_LANGUAGE_NOT_SUPORTED",
        "explanation": "The language is not supported in the format.",
    },
    "0xC00D32D9": {
        "name": "NS_E_METADATA_NO_RFC1766_NAME_FOR_LOCALE",
        "explanation": "There is no RFC1766 name translation for the supplied locale id.",
    },
    "0xC00D32DA": {
        "name": "NS_E_METADATA_NOT_AVAILABLE",
        "explanation": "The metadata (or metadata item) is not available.",
    },
    "0xC00D32DB": {
        "name": "NS_E_METADATA_CACHE_DATA_NOT_AVAILABLE",
        "explanation": "The cached metadata (or metadata item) is not available.",
    },
    "0xC00D32DC": {"name": "NS_E_METADATA_INVALID_DOCUMENT_TYPE", "explanation": "The metadata document is invalid."},
    "0xC00D32DD": {
        "name": "NS_E_METADATA_IDENTIFIER_NOT_AVAILABLE",
        "explanation": "The metadata content identifier is not available.",
    },
    "0xC00D32DE": {
        "name": "NS_E_METADATA_CANNOT_RETRIEVE_FROM_OFFLINE_CACHE",
        "explanation": "Cannot retrieve metadata from the offline metadata cache.",
    },
    "0xC0261003": {
        "name": "ERROR_MONITOR_INVALID_DESCRIPTOR_CHECKSUM",
        "explanation": "Checksum of the obtained monitor descriptor is invalid.",
    },
    "0xC0261004": {
        "name": "ERROR_MONITOR_INVALID_STANDARD_TIMING_BLOCK",
        "explanation": "Monitor descriptor contains an invalid standard timing block.",
    },
    "0xC0261005": {
        "name": "ERROR_MONITOR_WMI_DATABLOCK_REGISTRATION_FAILED",
        "explanation": "Windows Management Instrumentation (WMI) data block registration failed for one of the MSMonitorClass WMI subclasses.",
    },
    "0xC0261006": {
        "name": "ERROR_MONITOR_INVALID_SERIAL_NUMBER_MONDSC_BLOCK",
        "explanation": "Provided monitor descriptor block is either corrupted or does not contain the monitor's detailed serial number.",
    },
    "0xC0261007": {
        "name": "ERROR_MONITOR_INVALID_USER_FRIENDLY_MONDSC_BLOCK",
        "explanation": "Provided monitor descriptor block is either corrupted or does not contain the monitor's user-friendly name.",
    },
    "0xC0261008": {
        "name": "ERROR_MONITOR_NO_MORE_DESCRIPTOR_DATA",
        "explanation": "There is no monitor descriptor data at the specified (offset, size) region.",
    },
    "0xC0261009": {
        "name": "ERROR_MONITOR_INVALID_DETAILED_TIMING_BLOCK",
        "explanation": "Monitor descriptor contains an invalid detailed timing block.",
    },
    "0xC0262000": {
        "name": "ERROR_GRAPHICS_NOT_EXCLUSIVE_MODE_OWNER",
        "explanation": "Exclusive mode ownership is needed to create unmanaged primary allocation.",
    },
    "0xC0262001": {
        "name": "ERROR_GRAPHICS_INSUFFICIENT_DMA_BUFFER",
        "explanation": "The driver needs more direct memory access (DMA) buffer space to complete the requested operation.",
    },
    "0xC0262002": {
        "name": "ERROR_GRAPHICS_INVALID_DISPLAY_ADAPTER",
        "explanation": "Specified display adapter handle is invalid.",
    },
    "0xC0262003": {
        "name": "ERROR_GRAPHICS_ADAPTER_WAS_RESET",
        "explanation": "Specified display adapter and all of its state has been reset.",
    },
    "0xC0262004": {
        "name": "ERROR_GRAPHICS_INVALID_DRIVER_MODEL",
        "explanation": "The driver stack does not match the expected driver model.",
    },
    "0xC0262005": {
        "name": "ERROR_GRAPHICS_PRESENT_MODE_CHANGED",
        "explanation": "Present happened but ended up into the changed desktop mode.",
    },
    "0xC0262006": {
        "name": "ERROR_GRAPHICS_PRESENT_OCCLUDED",
        "explanation": "Nothing to present due to desktop occlusion.",
    },
    "0xC0262007": {
        "name": "ERROR_GRAPHICS_PRESENT_DENIED",
        "explanation": "Not able to present due to denial of desktop access.",
    },
    "0xC0262008": {
        "name": "ERROR_GRAPHICS_CANNOTCOLORCONVERT",
        "explanation": "Not able to present with color conversion.",
    },
    "0xC0262100": {
        "name": "ERROR_GRAPHICS_NO_VIDEO_MEMORY",
        "explanation": "Not enough video memory available to complete the operation.",
    },
    "0xC0262101": {
        "name": "ERROR_GRAPHICS_CANT_LOCK_MEMORY",
        "explanation": "Could not probe and lock the underlying memory of an allocation.",
    },
    "0xC0262102": {"name": "ERROR_GRAPHICS_ALLOCATION_BUSY", "explanation": "The allocation is currently busy."},
    "0xC0262103": {
        "name": "ERROR_GRAPHICS_TOO_MANY_REFERENCES",
        "explanation": "An object being referenced has reach the maximum reference count already and cannot be referenced further.",
    },
    "0xC0262104": {
        "name": "ERROR_GRAPHICS_TRY_AGAIN_LATER",
        "explanation": "A problem could not be solved due to some currently existing condition. The problem should be tried again later.",
    },
    "0xC0262105": {
        "name": "ERROR_GRAPHICS_TRY_AGAIN_NOW",
        "explanation": "A problem could not be solved due to some currently existing condition. The problem should be tried again immediately.",
    },
    "0xC0262106": {"name": "ERROR_GRAPHICS_ALLOCATION_INVALID", "explanation": "The allocation is invalid."},
    "0xC0262107": {
        "name": "ERROR_GRAPHICS_UNSWIZZLING_APERTURE_UNAVAILABLE",
        "explanation": "No more unswizzling apertures are currently available.",
    },
    "0xC0262108": {
        "name": "ERROR_GRAPHICS_UNSWIZZLING_APERTURE_UNSUPPORTED",
        "explanation": "The current allocation cannot be unswizzled by an aperture.",
    },
    "0xC0262109": {
        "name": "ERROR_GRAPHICS_CANT_EVICT_PINNED_ALLOCATION",
        "explanation": "The request failed because a pinned allocation cannot be evicted.",
    },
    "0xC0262110": {
        "name": "ERROR_GRAPHICS_INVALID_ALLOCATION_USAGE",
        "explanation": "The allocation cannot be used from its current segment location for the specified operation.",
    },
    "0xC0262111": {
        "name": "ERROR_GRAPHICS_CANT_RENDER_LOCKED_ALLOCATION",
        "explanation": "A locked allocation cannot be used in the current command buffer.",
    },
    "0xC0262112": {
        "name": "ERROR_GRAPHICS_ALLOCATION_CLOSED",
        "explanation": "The allocation being referenced has been closed permanently.",
    },
    "0xC0262113": {
        "name": "ERROR_GRAPHICS_INVALID_ALLOCATION_INSTANCE",
        "explanation": "An invalid allocation instance is being referenced.",
    },
    "0xC0262114": {
        "name": "ERROR_GRAPHICS_INVALID_ALLOCATION_HANDLE",
        "explanation": "An invalid allocation handle is being referenced.",
    },
    "0xC0262115": {
        "name": "ERROR_GRAPHICS_WRONG_ALLOCATION_DEVICE",
        "explanation": "The allocation being referenced does not belong to the current device.",
    },
    "0xC0262116": {
        "name": "ERROR_GRAPHICS_ALLOCATION_CONTENT_LOST",
        "explanation": "The specified allocation lost its content.",
    },
    "0xC0262200": {
        "name": "ERROR_GRAPHICS_GPU_EXCEPTION_ON_DEVICE",
        "explanation": "Graphics processing unit (GPU) exception is detected on the given device. The device is not able to be scheduled.",
    },
    "0xC0262300": {
        "name": "ERROR_GRAPHICS_INVALID_VIDPN_TOPOLOGY",
        "explanation": "Specified video present network (VidPN) topology is invalid.",
    },
    "0xC0262301": {
        "name": "ERROR_GRAPHICS_VIDPN_TOPOLOGY_NOT_SUPPORTED",
        "explanation": "Specified VidPN topology is valid but is not supported by this model of the display adapter.",
    },
    "0xC0262302": {
        "name": "ERROR_GRAPHICS_VIDPN_TOPOLOGY_CURRENTLY_NOT_SUPPORTED",
        "explanation": "Specified VidPN topology is valid but is not supported by the display adapter at this time, due to current allocation of its resources.",
    },
    "0xC0262303": {"name": "ERROR_GRAPHICS_INVALID_VIDPN", "explanation": "Specified VidPN handle is invalid."},
    "0xC0262304": {
        "name": "ERROR_GRAPHICS_INVALID_VIDEO_PRESENT_SOURCE",
        "explanation": "Specified video present source is invalid.",
    },
    "0xC0262305": {
        "name": "ERROR_GRAPHICS_INVALID_VIDEO_PRESENT_TARGET",
        "explanation": "Specified video present target is invalid.",
    },
    "0xC0262306": {
        "name": "ERROR_GRAPHICS_VIDPN_MODALITY_NOT_SUPPORTED",
        "explanation": "Specified VidPN modality is not supported (for example, at least two of the pinned modes are not cofunctional).",
    },
    "0xC0262308": {
        "name": "ERROR_GRAPHICS_INVALID_VIDPN_SOURCEMODESET",
        "explanation": "Specified VidPN source mode set is invalid.",
    },
    "0xC0262309": {
        "name": "ERROR_GRAPHICS_INVALID_VIDPN_TARGETMODESET",
        "explanation": "Specified VidPN target mode set is invalid.",
    },
    "0xC026230A": {
        "name": "ERROR_GRAPHICS_INVALID_FREQUENCY",
        "explanation": "Specified video signal frequency is invalid.",
    },
    "0xC026230B": {
        "name": "ERROR_GRAPHICS_INVALID_ACTIVE_REGION",
        "explanation": "Specified video signal active region is invalid.",
    },
    "0xC026230C": {
        "name": "ERROR_GRAPHICS_INVALID_TOTAL_REGION",
        "explanation": "Specified video signal total region is invalid.",
    },
    "0xC0262310": {
        "name": "ERROR_GRAPHICS_INVALID_VIDEO_PRESENT_SOURCE_MODE",
        "explanation": "Specified video present source mode is invalid.",
    },
    "0xC0262311": {
        "name": "ERROR_GRAPHICS_INVALID_VIDEO_PRESENT_TARGET_MODE",
        "explanation": "Specified video present target mode is invalid.",
    },
    "0xC0262312": {
        "name": "ERROR_GRAPHICS_PINNED_MODE_MUST_REMAIN_IN_SET",
        "explanation": "Pinned mode must remain in the set on VidPN's cofunctional modality enumeration.",
    },
    "0xC0262313": {
        "name": "ERROR_GRAPHICS_PATH_ALREADY_IN_TOPOLOGY",
        "explanation": "Specified video present path is already in the VidPN topology.",
    },
    "0xC0262314": {
        "name": "ERROR_GRAPHICS_MODE_ALREADY_IN_MODESET",
        "explanation": "Specified mode is already in the mode set.",
    },
    "0xC0262315": {
        "name": "ERROR_GRAPHICS_INVALID_VIDEOPRESENTSOURCESET",
        "explanation": "Specified video present source set is invalid.",
    },
    "0xC0262316": {
        "name": "ERROR_GRAPHICS_INVALID_VIDEOPRESENTTARGETSET",
        "explanation": "Specified video present target set is invalid.",
    },
    "0xC0262317": {
        "name": "ERROR_GRAPHICS_SOURCE_ALREADY_IN_SET",
        "explanation": "Specified video present source is already in the video present source set.",
    },
    "0xC0262318": {
        "name": "ERROR_GRAPHICS_TARGET_ALREADY_IN_SET",
        "explanation": "Specified video present target is already in the video present target set.",
    },
    "0xC0262319": {
        "name": "ERROR_GRAPHICS_INVALID_VIDPN_PRESENT_PATH",
        "explanation": "Specified VidPN present path is invalid.",
    },
    "0xC026231A": {
        "name": "ERROR_GRAPHICS_NO_RECOMMENDED_VIDPN_TOPOLOGY",
        "explanation": "Miniport has no recommendation for augmentation of the specified VidPN topology.",
    },
    "0xC026231B": {
        "name": "ERROR_GRAPHICS_INVALID_MONITOR_FREQUENCYRANGESET",
        "explanation": "Specified monitor frequency range set is invalid.",
    },
    "0xC026231C": {
        "name": "ERROR_GRAPHICS_INVALID_MONITOR_FREQUENCYRANGE",
        "explanation": "Specified monitor frequency range is invalid.",
    },
    "0xC026231D": {
        "name": "ERROR_GRAPHICS_FREQUENCYRANGE_NOT_IN_SET",
        "explanation": "Specified frequency range is not in the specified monitor frequency range set.",
    },
    "0xC026231F": {
        "name": "ERROR_GRAPHICS_FREQUENCYRANGE_ALREADY_IN_SET",
        "explanation": "Specified frequency range is already in the specified monitor frequency range set.",
    },
    "0xC0262320": {
        "name": "ERROR_GRAPHICS_STALE_MODESET",
        "explanation": "Specified mode set is stale. Reacquire the new mode set.",
    },
    "0xC0262321": {
        "name": "ERROR_GRAPHICS_INVALID_MONITOR_SOURCEMODESET",
        "explanation": "Specified monitor source mode set is invalid.",
    },
    "0xC0262322": {
        "name": "ERROR_GRAPHICS_INVALID_MONITOR_SOURCE_MODE",
        "explanation": "Specified monitor source mode is invalid.",
    },
    "0xC0262323": {
        "name": "ERROR_GRAPHICS_NO_RECOMMENDED_FUNCTIONAL_VIDPN",
        "explanation": "Miniport does not have any recommendation regarding the request to provide a functional VidPN given the current display adapter configuration.",
    },
    "0xC0262324": {
        "name": "ERROR_GRAPHICS_MODE_ID_MUST_BE_UNIQUE",
        "explanation": "ID of the specified mode is already used by another mode in the set.",
    },
    "0xC0262325": {
        "name": "ERROR_GRAPHICS_EMPTY_ADAPTER_MONITOR_MODE_SUPPORT_INTERSECTION",
        "explanation": "System failed to determine a mode that is supported by both the display adapter and the monitor connected to it.",
    },
    "0xC0262326": {
        "name": "ERROR_GRAPHICS_VIDEO_PRESENT_TARGETS_LESS_THAN_SOURCES",
        "explanation": "Number of video present targets must be greater than or equal to the number of video present sources.",
    },
    "0xC0262327": {
        "name": "ERROR_GRAPHICS_PATH_NOT_IN_TOPOLOGY",
        "explanation": "Specified present path is not in the VidPN topology.",
    },
    "0xC0262328": {
        "name": "ERROR_GRAPHICS_ADAPTER_MUST_HAVE_AT_LEAST_ONE_SOURCE",
        "explanation": "Display adapter must have at least one video present source.",
    },
    "0xC0262329": {
        "name": "ERROR_GRAPHICS_ADAPTER_MUST_HAVE_AT_LEAST_ONE_TARGET",
        "explanation": "Display adapter must have at least one video present target.",
    },
    "0xC026232A": {
        "name": "ERROR_GRAPHICS_INVALID_MONITORDESCRIPTORSET",
        "explanation": "Specified monitor descriptor set is invalid.",
    },
    "0xC026232B": {
        "name": "ERROR_GRAPHICS_INVALID_MONITORDESCRIPTOR",
        "explanation": "Specified monitor descriptor is invalid.",
    },
    "0xC026232C": {
        "name": "ERROR_GRAPHICS_MONITORDESCRIPTOR_NOT_IN_SET",
        "explanation": "Specified descriptor is not in the specified monitor descriptor set.",
    },
    "0xC026232D": {
        "name": "ERROR_GRAPHICS_MONITORDESCRIPTOR_ALREADY_IN_SET",
        "explanation": "Specified descriptor is already in the specified monitor descriptor set.",
    },
    "0xC026232E": {
        "name": "ERROR_GRAPHICS_MONITORDESCRIPTOR_ID_MUST_BE_UNIQUE",
        "explanation": "ID of the specified monitor descriptor is already used by another descriptor in the set.",
    },
    "0xC026232F": {
        "name": "ERROR_GRAPHICS_INVALID_VIDPN_TARGET_SUBSET_TYPE",
        "explanation": "Specified video present target subset type is invalid.",
    },
    "0xC0262330": {
        "name": "ERROR_GRAPHICS_RESOURCES_NOT_RELATED",
        "explanation": "Two or more of the specified resources are not related to each other, as defined by the interface semantics.",
    },
    "0xC0262331": {
        "name": "ERROR_GRAPHICS_SOURCE_ID_MUST_BE_UNIQUE",
        "explanation": "ID of the specified video present source is already used by another source in the set.",
    },
    "0xC0262332": {
        "name": "ERROR_GRAPHICS_TARGET_ID_MUST_BE_UNIQUE",
        "explanation": "ID of the specified video present target is already used by another target in the set.",
    },
    "0xC0262333": {
        "name": "ERROR_GRAPHICS_NO_AVAILABLE_VIDPN_TARGET",
        "explanation": "Specified VidPN source cannot be used because there is no available VidPN target to connect it to.",
    },
    "0xC0262334": {
        "name": "ERROR_GRAPHICS_MONITOR_COULD_NOT_BE_ASSOCIATED_WITH_ADAPTER",
        "explanation": "Newly arrived monitor could not be associated with a display adapter.",
    },
    "0xC0262335": {
        "name": "ERROR_GRAPHICS_NO_VIDPNMGR",
        "explanation": "Display adapter in question does not have an associated VidPN manager.",
    },
    "0xC0262336": {
        "name": "ERROR_GRAPHICS_NO_ACTIVE_VIDPN",
        "explanation": "VidPN manager of the display adapter in question does not have an active VidPN.",
    },
    "0xC0262337": {
        "name": "ERROR_GRAPHICS_STALE_VIDPN_TOPOLOGY",
        "explanation": "Specified VidPN topology is stale. Re-acquire the new topology.",
    },
    "0xC0262338": {
        "name": "ERROR_GRAPHICS_MONITOR_NOT_CONNECTED",
        "explanation": "There is no monitor connected on the specified video present target.",
    },
    "0xC0262339": {
        "name": "ERROR_GRAPHICS_SOURCE_NOT_IN_TOPOLOGY",
        "explanation": "Specified source is not part of the specified VidPN topology.",
    },
    "0xC026233A": {
        "name": "ERROR_GRAPHICS_INVALID_PRIMARYSURFACE_SIZE",
        "explanation": "Specified primary surface size is invalid.",
    },
    "0xC026233B": {
        "name": "ERROR_GRAPHICS_INVALID_VISIBLEREGION_SIZE",
        "explanation": "Specified visible region size is invalid.",
    },
    "0xC026233C": {"name": "ERROR_GRAPHICS_INVALID_STRIDE", "explanation": "Specified stride is invalid."},
    "0xC026233D": {"name": "ERROR_GRAPHICS_INVALID_PIXELFORMAT", "explanation": "Specified pixel format is invalid."},
    "0xC026233E": {"name": "ERROR_GRAPHICS_INVALID_COLORBASIS", "explanation": "Specified color basis is invalid."},
    "0xC026233F": {
        "name": "ERROR_GRAPHICS_INVALID_PIXELVALUEACCESSMODE",
        "explanation": "Specified pixel value access mode is invalid.",
    },
    "0xC0262340": {
        "name": "ERROR_GRAPHICS_TARGET_NOT_IN_TOPOLOGY",
        "explanation": "Specified target is not part of the specified VidPN topology.",
    },
    "0xC0262341": {
        "name": "ERROR_GRAPHICS_NO_DISPLAY_MODE_MANAGEMENT_SUPPORT",
        "explanation": "Failed to acquire display mode management interface.",
    },
    "0xC0262342": {
        "name": "ERROR_GRAPHICS_VIDPN_SOURCE_IN_USE",
        "explanation": "Specified VidPN source is already owned by a display mode manager (DMM) client and cannot be used until that client releases it.",
    },
    "0xC0262343": {
        "name": "ERROR_GRAPHICS_CANT_ACCESS_ACTIVE_VIDPN",
        "explanation": "Specified VidPN is active and cannot be accessed.",
    },
    "0xC0262344": {
        "name": "ERROR_GRAPHICS_INVALID_PATH_IMPORTANCE_ORDINAL",
        "explanation": "Specified VidPN present path importance ordinal is invalid.",
    },
    "0xC0262345": {
        "name": "ERROR_GRAPHICS_INVALID_PATH_CONTENT_GEOMETRY_TRANSFORMATION",
        "explanation": "Specified VidPN present path content geometry transformation is invalid.",
    },
    "0xC0262346": {
        "name": "ERROR_GRAPHICS_PATH_CONTENT_GEOMETRY_TRANSFORMATION_NOT_SUPPORTED",
        "explanation": "Specified content geometry transformation is not supported on the respective VidPN present path.",
    },
    "0xC0262347": {"name": "ERROR_GRAPHICS_INVALID_GAMMA_RAMP", "explanation": "Specified gamma ramp is invalid."},
    "0xC0262348": {
        "name": "ERROR_GRAPHICS_GAMMA_RAMP_NOT_SUPPORTED",
        "explanation": "Specified gamma ramp is not supported on the respective VidPN present path.",
    },
    "0xC0262349": {
        "name": "ERROR_GRAPHICS_MULTISAMPLING_NOT_SUPPORTED",
        "explanation": "Multisampling is not supported on the respective VidPN present path.",
    },
    "0xC026234A": {
        "name": "ERROR_GRAPHICS_MODE_NOT_IN_MODESET",
        "explanation": "Specified mode is not in the specified mode set.",
    },
    "0xC026234D": {
        "name": "ERROR_GRAPHICS_INVALID_VIDPN_TOPOLOGY_RECOMMENDATION_REASON",
        "explanation": "Specified VidPN topology recommendation reason is invalid.",
    },
    "0xC026234E": {
        "name": "ERROR_GRAPHICS_INVALID_PATH_CONTENT_TYPE",
        "explanation": "Specified VidPN present path content type is invalid.",
    },
    "0xC026234F": {
        "name": "ERROR_GRAPHICS_INVALID_COPYPROTECTION_TYPE",
        "explanation": "Specified VidPN present path copy protection type is invalid.",
    },
    "0xC0262350": {
        "name": "ERROR_GRAPHICS_UNASSIGNED_MODESET_ALREADY_EXISTS",
        "explanation": "No more than one unassigned mode set can exist at any given time for a given VidPN source or target.",
    },
    "0xC0262352": {
        "name": "ERROR_GRAPHICS_INVALID_SCANLINE_ORDERING",
        "explanation": "The specified scan line ordering type is invalid.",
    },
    "0xC0262353": {
        "name": "ERROR_GRAPHICS_TOPOLOGY_CHANGES_NOT_ALLOWED",
        "explanation": "Topology changes are not allowed for the specified VidPN.",
    },
    "0xC0262354": {
        "name": "ERROR_GRAPHICS_NO_AVAILABLE_IMPORTANCE_ORDINALS",
        "explanation": "All available importance ordinals are already used in the specified topology.",
    },
    "0xC0262355": {
        "name": "ERROR_GRAPHICS_INCOMPATIBLE_PRIVATE_FORMAT",
        "explanation": "Specified primary surface has a different private format attribute than the current primary surface.",
    },
    "0xC0262356": {
        "name": "ERROR_GRAPHICS_INVALID_MODE_PRUNING_ALGORITHM",
        "explanation": "Specified mode pruning algorithm is invalid.",
    },
    "0xC0262400": {
        "name": "ERROR_GRAPHICS_SPECIFIED_CHILD_ALREADY_CONNECTED",
        "explanation": "Specified display adapter child device already has an external device connected to it.",
    },
    "0xC0262401": {
        "name": "ERROR_GRAPHICS_CHILD_DESCRIPTOR_NOT_SUPPORTED",
        "explanation": "The display adapter child device does not support reporting a descriptor.",
    },
    "0xC0262430": {
        "name": "ERROR_GRAPHICS_NOT_A_LINKED_ADAPTER",
        "explanation": "The display adapter is not linked to any other adapters.",
    },
    "0xC0262431": {
        "name": "ERROR_GRAPHICS_LEADLINK_NOT_ENUMERATED",
        "explanation": "Lead adapter in a linked configuration was not enumerated yet.",
    },
    "0xC0262432": {
        "name": "ERROR_GRAPHICS_CHAINLINKS_NOT_ENUMERATED",
        "explanation": "Some chain adapters in a linked configuration were not enumerated yet.",
    },
    "0xC0262433": {
        "name": "ERROR_GRAPHICS_ADAPTER_CHAIN_NOT_READY",
        "explanation": "The chain of linked adapters is not ready to start because of an unknown failure.",
    },
    "0xC0262434": {
        "name": "ERROR_GRAPHICS_CHAINLINKS_NOT_STARTED",
        "explanation": "An attempt was made to start a lead link display adapter when the chain links were not started yet.",
    },
    "0xC0262435": {
        "name": "ERROR_GRAPHICS_CHAINLINKS_NOT_POWERED_ON",
        "explanation": "An attempt was made to turn on a lead link display adapter when the chain links were turned off.",
    },
    "0xC0262436": {
        "name": "ERROR_GRAPHICS_INCONSISTENT_DEVICE_LINK_STATE",
        "explanation": "The adapter link was found to be in an inconsistent state. Not all adapters are in an expected PNP or power state.",
    },
    "0xC0262438": {
        "name": "ERROR_GRAPHICS_NOT_POST_DEVICE_DRIVER",
        "explanation": "The driver trying to start is not the same as the driver for the posted display adapter.",
    },
    "0xC0262500": {
        "name": "ERROR_GRAPHICS_OPM_NOT_SUPPORTED",
        "explanation": "The driver does not support Output Protection Manager (OPM).",
    },
    "0xC0262501": {
        "name": "ERROR_GRAPHICS_COPP_NOT_SUPPORTED",
        "explanation": "The driver does not support Certified Output Protection Protocol (COPP).",
    },
    "0xC0262502": {
        "name": "ERROR_GRAPHICS_UAB_NOT_SUPPORTED",
        "explanation": "The driver does not support a user-accessible bus (UAB).",
    },
    "0xC0262503": {
        "name": "ERROR_GRAPHICS_OPM_INVALID_ENCRYPTED_PARAMETERS",
        "explanation": "The specified encrypted parameters are invalid.",
    },
    "0xC0262504": {
        "name": "ERROR_GRAPHICS_OPM_PARAMETER_ARRAY_TOO_SMALL",
        "explanation": "An array passed to a function cannot hold all of the data that the function wants to put in it.",
    },
    "0xC0262505": {
        "name": "ERROR_GRAPHICS_OPM_NO_VIDEO_OUTPUTS_EXIST",
        "explanation": "The GDI display device passed to this function does not have any active video outputs.",
    },
    "0xC0262506": {
        "name": "ERROR_GRAPHICS_PVP_NO_DISPLAY_DEVICE_CORRESPONDS_TO_NAME",
        "explanation": "The protected video path (PVP) cannot find an actual GDI display device that corresponds to the passed-in GDI display device name.",
    },
    "0xC0262507": {
        "name": "ERROR_GRAPHICS_PVP_DISPLAY_DEVICE_NOT_ATTACHED_TO_DESKTOP",
        "explanation": "This function failed because the GDI display device passed to it was not attached to the Windows desktop.",
    },
    "0xC0262508": {
        "name": "ERROR_GRAPHICS_PVP_MIRRORING_DEVICES_NOT_SUPPORTED",
        "explanation": "The PVP does not support mirroring display devices because they do not have video outputs.",
    },
    "0xC026250A": {
        "name": "ERROR_GRAPHICS_OPM_INVALID_POINTER",
        "explanation": "The function failed because an invalid pointer parameter was passed to it. A pointer parameter is invalid if it is null, it points to an invalid address, it points to a kernel mode address, or it is not correctly aligned.",
    },
    "0xC026250B": {
        "name": "ERROR_GRAPHICS_OPM_INTERNAL_ERROR",
        "explanation": "An internal error caused this operation to fail.",
    },
    "0xC026250C": {
        "name": "ERROR_GRAPHICS_OPM_INVALID_HANDLE",
        "explanation": "The function failed because the caller passed in an invalid OPM user mode handle.",
    },
    "0xC026250D": {
        "name": "ERROR_GRAPHICS_PVP_NO_MONITORS_CORRESPOND_TO_DISPLAY_DEVICE",
        "explanation": "This function failed because the GDI device passed to it did not have any monitors associated with it.",
    },
    "0xC026250E": {
        "name": "ERROR_GRAPHICS_PVP_INVALID_CERTIFICATE_LENGTH",
        "explanation": "A certificate could not be returned because the certificate buffer passed to the function was too small.",
    },
    "0xC026250F": {
        "name": "ERROR_GRAPHICS_OPM_SPANNING_MODE_ENABLED",
        "explanation": "A video output could not be created because the frame buffer is in spanning mode.",
    },
    "0xC0262510": {
        "name": "ERROR_GRAPHICS_OPM_THEATER_MODE_ENABLED",
        "explanation": "A video output could not be created because the frame buffer is in theater mode.",
    },
    "0xC0262511": {
        "name": "ERROR_GRAPHICS_PVP_HFS_FAILED",
        "explanation": "The function call failed because the display adapter's hardware functionality scan failed to validate the graphics hardware.",
    },
    "0xC0262512": {
        "name": "ERROR_GRAPHICS_OPM_INVALID_SRM",
        "explanation": "The High-Bandwidth Digital Content Protection (HDCP) System Renewability Message (SRM) passed to this function did not comply with section 5 of the HDCP 1.1 specification.",
    },
    "0xC0262513": {
        "name": "ERROR_GRAPHICS_OPM_OUTPUT_DOES_NOT_SUPPORT_HDCP",
        "explanation": "The video output cannot enable the HDCP system because it does not support it.",
    },
    "0xC0262514": {
        "name": "ERROR_GRAPHICS_OPM_OUTPUT_DOES_NOT_SUPPORT_ACP",
        "explanation": "The video output cannot enable analog copy protection because it does not support it.",
    },
    "0xC0262515": {
        "name": "ERROR_GRAPHICS_OPM_OUTPUT_DOES_NOT_SUPPORT_CGMSA",
        "explanation": "The video output cannot enable the Content Generation Management System Analog (CGMS-A) protection technology because it does not support it.",
    },
    "0xC0262516": {
        "name": "ERROR_GRAPHICS_OPM_HDCP_SRM_NEVER_SET",
        "explanation": "IOPMVideoOutput's GetInformation() method cannot return the version of the SRM being used because the application never successfully passed an SRM to the video output.",
    },
    "0xC0262517": {
        "name": "ERROR_GRAPHICS_OPM_RESOLUTION_TOO_HIGH",
        "explanation": "IOPMVideoOutput's Configure() method cannot enable the specified output protection technology because the output's screen resolution is too high.",
    },
    "0xC0262518": {
        "name": "ERROR_GRAPHICS_OPM_ALL_HDCP_HARDWARE_ALREADY_IN_USE",
        "explanation": "IOPMVideoOutput's Configure() method cannot enable HDCP because the display adapter's HDCP hardware is already being used by other physical outputs.",
    },
    "0xC0262519": {
        "name": "ERROR_GRAPHICS_OPM_VIDEO_OUTPUT_NO_LONGER_EXISTS",
        "explanation": "The operating system asynchronously destroyed this OPM video output because the operating system's state changed. This error typically occurs because the monitor physical device object (PDO) associated with this video output was removed, the monitor PDO associated with this video output was stopped, the video output's session became a nonconsole session or the video output's desktop became an inactive desktop.",
    },
    "0xC026251A": {
        "name": "ERROR_GRAPHICS_OPM_SESSION_TYPE_CHANGE_IN_PROGRESS",
        "explanation": "IOPMVideoOutput's methods cannot be called when a session is changing its type. There are currently three types of sessions: console, disconnected and remote (remote desktop protocol [RDP] or Independent Computing Architecture [ICA]).",
    },
    "0xC0262580": {
        "name": "ERROR_GRAPHICS_I2C_NOT_SUPPORTED",
        "explanation": "The monitor connected to the specified video output does not have an I2C bus.",
    },
    "0xC0262581": {
        "name": "ERROR_GRAPHICS_I2C_DEVICE_DOES_NOT_EXIST",
        "explanation": "No device on the I2C bus has the specified address.",
    },
    "0xC0262582": {
        "name": "ERROR_GRAPHICS_I2C_ERROR_TRANSMITTING_DATA",
        "explanation": "An error occurred while transmitting data to the device on the I2C bus.",
    },
    "0xC0262583": {
        "name": "ERROR_GRAPHICS_I2C_ERROR_RECEIVING_DATA",
        "explanation": "An error occurred while receiving data from the device on the I2C bus.",
    },
    "0xC0262584": {
        "name": "ERROR_GRAPHICS_DDCCI_VCP_NOT_SUPPORTED",
        "explanation": "The monitor does not support the specified Virtual Control Panel (VCP) code.",
    },
    "0xC0262585": {
        "name": "ERROR_GRAPHICS_DDCCI_INVALID_DATA",
        "explanation": "The data received from the monitor is invalid.",
    },
    "0xC0262586": {
        "name": "ERROR_GRAPHICS_DDCCI_MONITOR_RETURNED_INVALID_TIMING_STATUS_BYTE",
        "explanation": "A function call failed because a monitor returned an invalid Timing Status byte when the operating system used the Display Data Channel Command Interface (DDC/CI) Get Timing Report and Timing Message command to get a timing report from a monitor.",
    },
    "0xC0262587": {
        "name": "ERROR_GRAPHICS_MCA_INVALID_CAPABILITIES_STRING",
        "explanation": "The monitor returned a DDC/CI capabilities string that did not comply with the ACCESS.bus 3.0, DDC/CI 1.1 or MCCS 2 Revision 1 specification.",
    },
    "0xC0262588": {
        "name": "ERROR_GRAPHICS_MCA_INTERNAL_ERROR",
        "explanation": "An internal Monitor Configuration API error occurred.",
    },
    "0xC0262589": {
        "name": "ERROR_GRAPHICS_DDCCI_INVALID_MESSAGE_COMMAND",
        "explanation": "An operation failed because a DDC/CI message had an invalid value in its command field.",
    },
    "0xC026258A": {
        "name": "ERROR_GRAPHICS_DDCCI_INVALID_MESSAGE_LENGTH",
        "explanation": "This error occurred because a DDC/CI message length field contained an invalid value.",
    },
    "0xC026258B": {
        "name": "ERROR_GRAPHICS_DDCCI_INVALID_MESSAGE_CHECKSUM",
        "explanation": "This error occurred because the value in a DDC/CI message checksum field did not match the message's computed checksum value. This error implies that the data was corrupted while it was being transmitted from a monitor to a computer.",
    },
    "0xC02625D6": {
        "name": "ERROR_GRAPHICS_PMEA_INVALID_MONITOR",
        "explanation": "The HMONITOR no longer exists, is not attached to the desktop, or corresponds to a mirroring device.",
    },
    "0xC02625D7": {
        "name": "ERROR_GRAPHICS_PMEA_INVALID_D3D_DEVICE",
        "explanation": "The Direct3D (D3D) device's GDI display device no longer exists, is not attached to the desktop, or is a mirroring display device.",
    },
    "0xC02625D8": {
        "name": "ERROR_GRAPHICS_DDCCI_CURRENT_CURRENT_VALUE_GREATER_THAN_MAXIMUM_VALUE",
        "explanation": "A continuous VCP code's current value is greater than its maximum value. This error code indicates that a monitor returned an invalid value.",
    },
    "0xC02625D9": {
        "name": "ERROR_GRAPHICS_MCA_INVALID_VCP_VERSION",
        "explanation": "The monitor's VCP Version (0xDF) VCP code returned an invalid version value.",
    },
    "0xC02625DA": {
        "name": "ERROR_GRAPHICS_MCA_MONITOR_VIOLATES_MCCS_SPECIFICATION",
        "explanation": "The monitor does not comply with the Monitor Control Command Set (MCCS) specification it claims to support.",
    },
    "0xC02625DB": {
        "name": "ERROR_GRAPHICS_MCA_MCCS_VERSION_MISMATCH",
        "explanation": "The MCCS version in a monitor's mccs_ver capability does not match the MCCS version the monitor reports when the VCP Version (0xDF) VCP code is used.",
    },
    "0xC02625DC": {
        "name": "ERROR_GRAPHICS_MCA_UNSUPPORTED_MCCS_VERSION",
        "explanation": "The Monitor Configuration API only works with monitors that support the MCCS 1.0 specification, the MCCS 2.0 specification, or the MCCS 2.0 Revision 1 specification.",
    },
    "0xC02625DE": {
        "name": "ERROR_GRAPHICS_MCA_INVALID_TECHNOLOGY_TYPE_RETURNED",
        "explanation": "The monitor returned an invalid monitor technology type. CRT, plasma, and LCD (TFT) are examples of monitor technology types. This error implies that the monitor violated the MCCS 2.0 or MCCS 2.0 Revision 1 specification.",
    },
    "0xC02625DF": {
        "name": "ERROR_GRAPHICS_MCA_UNSUPPORTED_COLOR_TEMPERATURE",
        "explanation": "The SetMonitorColorTemperature() caller passed a color temperature to it that the current monitor did not support. CRT, plasma, and LCD (TFT) are examples of monitor technology types. This error implies that the monitor violated the MCCS 2.0 or MCCS 2.0 Revision 1 specification.",
    },
    "0xC02625E0": {
        "name": "ERROR_GRAPHICS_ONLY_CONSOLE_SESSION_SUPPORTED",
        "explanation": "This function can be used only if a program is running in the local console session. It cannot be used if the program is running on a remote desktop session or on a terminal server session.",
    },
}
