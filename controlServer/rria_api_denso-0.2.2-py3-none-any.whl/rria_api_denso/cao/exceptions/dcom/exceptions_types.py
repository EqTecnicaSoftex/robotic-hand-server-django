class DComCommonError(Exception):
    def __init__(self, error_code, table):
        error_details = table[error_code]
        self.__message = error_details["name"]
        self.__explanation = error_details["explanation"]
        self.__error_code = error_code
        super().__init__(self.__message)

    def __str__(self):
        return f"DComCommonError(\n\tCode: {self.__error_code}\n\tMessage: {self.__message}\n\tExplanation: {self.__explanation}\n)"
