from rria_api_denso.cao.exceptions.cao.exception_builder import ControllerExceptionBuilder
from rria_api_denso.cao.exceptions.dcom.exception_builder import DComExceptionBuilder


class DensoExceptionHandler(Exception):
    def __init__(self, error_tuple):
        comm_error_code = error_tuple[0]
        controller_error_code = error_tuple[2][5]
        self.__communication = DComExceptionBuilder(comm_error_code)
        self.__controller = ControllerExceptionBuilder(controller_error_code)

    def __str__(self):
        return f"{self.__communication}\n{self.__controller}"
