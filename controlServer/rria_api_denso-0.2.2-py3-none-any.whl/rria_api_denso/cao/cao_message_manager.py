class CAOMessageManager:
    """
    This class contains methods for manipulate the CAOMessage object. CAOMessage is responsible for creating the
    CAOMessage object.

    From the CaoController object, it is possible to use all the other related methods.
    """

    def __init__(self, cao_message):
        self.cao_message = cao_message

    def reply(self, data):
        """
        Method to reply to a message.

        Args:
            data:
        """
        self.cao_message.Reply(data)

    def clear(self):
        """
        Method to clear a message.
        """
        self.cao_message.Clear()

    def get_datetime(self):
        """
        Method to get the datetime of a message.
        Returns:
            CaoMessage DateTime: Datetime of the message
        """
        return self.cao_message.DateTime

    def get_description(self):
        """
        Method to get the description of a message.
        Returns:
            CaoMessage Description: Description of the message
        """
        return self.cao_message.Description

    def get_destination(self):
        """
        Method to get the destination of a message.
        Returns:
            CaoMessage Destination: Destination of the message
        """
        return self.cao_message.Destination

    def get_number(self):
        """
        Method to get the number of a message.
        Returns:
            CaoMessage Number: Number of the message
        """
        return self.cao_message.Number

    def get_serial_number(self):
        """
        Method to get the serial number of a message.
        Returns:
            CaoMessage SerialNumber: Serial number of the message
        """
        return self.cao_message.SerialNumber

    def get_source(self):
        """
        Method to get the source of a message.
        Returns:
            CaoMessage Source: Source of the message
        """
        return self.cao_message.Source

    def get_value(self):
        """
        Method to get the value of a message.
        Returns:
            CaoMessage Value: Value of the message
        """
        return self.cao_message.Value
