import os
import subprocess

from rria_api_denso.cao.cao_command_manager import CAOCommandManager
from rria_api_denso.cao.cao_controller import CAOController
from rria_api_denso.cao.cao_engine import CAOEngine as CAOEngineObject
from rria_api_denso.cao.cao_extension_manager import CAOExtensionManager
from rria_api_denso.cao.cao_file_manager import CAOFileManager
from rria_api_denso.cao.cao_message_manager import CAOMessageManager
from rria_api_denso.cao.cao_robot_manager import CAORobotManager
from rria_api_denso.cao.cao_task_manager import CAOTaskManager
from rria_api_denso.cao.cao_variable_manager import CAOVariableManager
from rria_api_denso.cao.cao_workspace import CAOWorkspace
from rria_api_denso.cao.enumerates.controller_enum import ControllerExecuteEnum
from rria_api_denso.cao.enumerates.robot_enum import RobotExecuteEnum
from rria_api_denso.utils.install_checker import install_check_denso_library

if install_check_denso_library():
    subprocess.run(
        ["python", "-m", "win32com.client.makepy", "cao.CaoEngine"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
elif os.environ.get("USING_ROBOT_TEST") is None:
    raise ImportError("ORiN2 SDK installation not found on your system")
