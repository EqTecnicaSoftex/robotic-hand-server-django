import pythoncom
from win32com import client


class CAOEngine:
    """
    A common function to the cao provider and the cao interface are offered to the client with the cao engine by
    middleware (EXE) that mounts the interface of cao. A common function to the cao provider includes the collection
    function, the message output, and the CRD switch function, etc.
    """

    cao_engine = None

    def __init__(self):
        """
        Create a cao engine object and store in the cao_engine variable.

        This object is used to access the cao engine methods and is related to the dispatch object.

        For access the cao engine object, use the cao_engine variable through the method get_dcom_dispatch.
        """
        self.cao_engine = client.Dispatch("cao.CaoEngine", pythoncom.CoInitialize())

    def get_dcom_dispatch(self):
        """
        Acquisition of a cao engine object.

        Args:
            ...
        Returns:
            CAOEngine: cao engine object
        """
        return self.cao_engine

    def get_engine_status(self):
        """
        Acquisition of an engine status object.

        Args:
            ...
        Returns:
            CAOEngine Status: Engine status
        """
        return self.cao_engine.EngineStatus

    def get_workspaces(self):
        """
         Acquisition of a workspace collection.

        Args:
            ...
        Returns:
            CAOEngine Workspaces: Workspaces list
        """
        return self.cao_engine.Workspaces

    def workspace_remove(self, workspace_index):
        """
        Remove workspace from cao engine.This method uses the Workspaces.Remove of the cao engine method.
        Args:
            workspace_index:

        Returns:
            True if the workspace was removed, False otherwise.
        """
        workspaces_prev_count = self.cao_engine.Workspaces.Count
        self.cao_engine.Workspaces.Remove(workspace_index)
        return workspaces_prev_count == self.cao_engine.Workspaces.Count + 1

    def release_dcom(self):
        """
        Release the cao engine handlers (stop cao.exe) and delete all related objects.
        """
        del self.cao_engine

    def get_workspaces_names(self):
        len_workspaces = self.cao_engine.Workspaces.Count
        names = []
        for i in range(len_workspaces):
            names.append(self.cao_engine.Workspaces[i].Name)

        return names
