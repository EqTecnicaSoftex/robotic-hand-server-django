from rria_api_denso.cao.cao_command_manager import CAOCommandManager
from rria_api_denso.cao.cao_extension_manager import CAOExtensionManager
from rria_api_denso.cao.cao_file_manager import CAOFileManager
from rria_api_denso.cao.cao_message_manager import CAOMessageManager
from rria_api_denso.cao.cao_robot_manager import CAORobotManager
from rria_api_denso.cao.cao_task_manager import CAOTaskManager
from rria_api_denso.cao.cao_variable_manager import CAOVariableManager
from rria_api_denso.cao.executes.controller_execute import ControllerExecute


class CAOController:
    """
    This class contains all methods and objects available in python related to CaoWorkspace and CaoController.

    CaoWorkspace is responsible for creating the CaoController object through the set_parameters and
    workspace_add_controller methods.

    From the CaoController object, it is possible to use all the other related methods.

    This class is also responsible for creating from CaoController, other objects, such as
    CaoRobot, CaoFile, CaoTask, CaoVariable, CaoCommand, CaoExtension and CaoMessage, but the last three are not
    functional in this API in python.
    """

    def __init__(self, cao_controller):
        self.cao_controller = cao_controller

        self.controller_execute = None

        self.cao_file = None
        self.cao_file_dispatch = None

        self.cao_extension = None
        self.cao_extension_dispatch = None

        self.cao_robot = None
        self.cao_robot_dispatch = None

        self.cao_task = None
        self.cao_task_dispatch = None

        self.cao_variable = None
        self.cao_variable_dispatch = None

        self.cao_command = None
        self.cao_command_dispatch = None

        self.cao_message = None
        self.cao_message_dispatch = None

    # Não foi testada, pois não temos placa de expansão!
    def controller_add_extension(self, name, option=""):
        """
        The argument of the AddExtension method of the CaoController class specifies the extended function name
        (string type).

        Args:
            name: string,
            option: string,
        Returns:
            cao_extension object
        Examples:
            >>> cao_extension = self.cao_controller.controller_add_extension("Hand0")
        """
        self.cao_extension_dispatch = self.cao_controller.AddExtension(name, option)
        self.cao_extension = CAOExtensionManager(self.cao_extension_dispatch)

        return self.cao_extension

    def controller_add_file(self, name, option=""):
        """
        The argument of the AddFile method of the CaoController class specifies the file name (string type).
        The specified "File name" is a PAC program name, system reserved file name, or directory name.

        You can specify a directory by specifying only a file path for the argument.
        If the path is not specified,
        files in the project root, which is the default directory, are specified.

        Warning: The CaoFile object does not support simultaneous access to a file.
        Be sure to implement an exclusive
        file access control routine in the application.

        Args:
            name: string,
            option: string,
        Returns:
            cao_file object
        Examples:
            >>> cao_file = self.cao_controller.controller_add_file("pro1.pcs", "")
        """
        self.cao_file_dispatch = self.cao_controller.AddFile(name, option)
        self.cao_file = CAOFileManager(self.cao_file_dispatch)

        return self.cao_file

    def controller_add_robot(self, name, option=""):
        """
        A CaoRobot object is retrieved by calling the AddRobot method. The argument of the AddRobot method of the
        CaoController class specifies the robot name (string type). "Robot name" specified here is any string and there
        is no restriction for naming. For example, you can specify AddRobot ("Robot1").

        Args:
            name: string,
            option: string,
        Returns:
            cao_robot object
        Examples:
            >>> cao_robot = self.cao_controller.controller_add_robot("Robot1", "")
        """
        self.cao_robot_dispatch = self.cao_controller.AddRobot(name, option)
        self.cao_robot = CAORobotManager(self.cao_robot_dispatch)

        return self.cao_robot

    def controller_add_task(self, name, option=""):
        """
        The argument of the AddTask method of the CaoController class specifies the task name (string type).
        "Task name" specified here specifies a PAC program name. For instance, the CaoTask object is retrieved in
        the expression like AddTask("pro1").

        Args:
            name: string,
            option: string,
        Returns:
            cao_task object
        Examples:
            >>> cao_task = self.cao_controller.controller_add_task("pro1", "")
        """
        self.cao_task_dispatch = self.cao_controller.AddTask(name, option)
        self.cao_task = CAOTaskManager(self.cao_task_dispatch)

        return self.cao_task

    def controller_add_variable(self, name, option=""):
        """
        The AddVariable method of this CaoController class is a method for the access to the variable. In the RC8
        provider, both the user variable and the system variable can be specified for the variable name.

        User variables support the following variables, i.e., RC8 controller global variables (I, F, V, P, J, D, T, S)
        and I/O.

        Variable identifier: I, F, V, P, J, D, T, S or IO, IOB, IOW, IOD, IOF. The characters are not case-sensitive
        (uppercase and lowercase have the same meaning). The I/O values are processed as follows: IO in Bits,
        IOB in Bytes, IOW in Words, IOD in Double Words (Long), and IOF in Float (Single).

        Number: Variable's number specified by the identifier or "*" or "*_<Numeric value>" The number is specified by
        a decimal number.
        The specification of "*" is handled as the initial value of 0. The variable's number can be retrieved and
        changed by 'ID' property of the variable object. Specify the numeric value in *_<Numeric value> as a decimal n
        umber.
        Wild card for variables of the same type (*): This is an identification number that enables to specify multiple
        definitions, and the value has no special meaning.

        Args:
            name: string,
            option: string,
        Returns:
            cao_variable object
        Examples:
            >>> cao_variable = self.cao_controller.AddVariable("I1")
        """
        self.cao_variable_dispatch = self.cao_controller.AddVariable(name, option)
        self.cao_variable = CAOVariableManager(self.cao_variable_dispatch)

        return self.cao_variable

    def controller_add_command(self, name, option=""):
        """
        The AddCommand method of this CaoController class is a method for the access to the command. In the RC8
        provider, both the user command and the system command can be specified for the command name.

        THIS METHOD IS NOT WORKING!

        Args:
            name: string,
            option: string,

        Returns:
            cao_command object
        """
        raise RuntimeError("THIS METHOD IS NOT WORKING!")
        self.cao_command_dispatch = self.cao_controller.AddCommand(name, option)
        self.cao_command = CAOCommandManager(self.cao_command_dispatch)

        return self.cao_command

    def controller_add_message(self, name, option=""):
        """
        The AddMessage method of this CaoController class is a method for the access to the message. In the RC8
        provider, both the user message and the system message can be specified for the message name.

        THIS METHOD IS NOT WORKING!

        Args:
            name: string,
            option: string,

        Returns:
            cao_message object
        """

        raise RuntimeError("THIS METHOD IS NOT WORKING!")
        self.cao_message_dispatch = self.cao_controller.AddMessage(name, option)
        self.cao_message = CAOMessageManager(self.cao_message_dispatch)

        return self.cao_message

    # Métodos do CAOController
    # Não foi testada, pois não temos placa de expansão!
    def get_extension_names(self):
        """
        Get a list of extended function names that can be specified by the AddExtension method.
        Returns:
            list of extended function names - list of strings
        """
        return self.cao_controller.ExtensionNames

    def get_file_names(self):
        """
        Get a list of file names that can be specified by the AddFile method.

        Returns:
            list of file names that are below the folder - list of strings
        Examples:
            >>> file_names = self.cao_controller.get_file_names()
        """
        return self.cao_controller.FileNames

    def get_robot_names(self):
        """
        Get a list of robot names that can be specified by the AddRobot method.

        Returns:
            list of robot names - list of strings
        Examples:
            >>> task_names = self.cao_controller.get_robot_names()
        """
        return self.cao_controller.RobotNames

    def get_task_names(self):
        """
        Get a list of task names that can be specified by the AddTask method.

        Returns:
            list of task names - list of strings
        Examples:
            >>> task_names = self.cao_controller.get_task_names()
        """
        return self.cao_controller.TaskNames

    def get_variable_names(self):
        """
        Get a list of variable names and system variable names that can be specified by the AddVariable method.
        Returns:
            list of variable names and system variable names - list of strings
        Examples:
            >>> variable_names = self.cao_controller.get_variable_names()
        """
        return self.cao_controller.VariableNames

    def get_command_names(self):
        """
        Get a list of command names and system command names that can be specified by the AddCommand method.

        THIS METHOD IS NOT WORKING!

        Returns:
            list of command names and system command names - list of strings
        """
        raise RuntimeError("THIS METHOD IS NOT WORKING!")
        return self.cao_controller.CommandNames

    def execute(self, command, param=None):
        """
        Execute a provider-specific extended command belonging to the CaoController class.
        For about arguments, specify a command as a string and a parameter as a list.

        In the first param, this string is handled from the RobotExecuteEnum class.

        See the list of extra functions used with executing on page 58 of the RC8 provider guide.

        Args:
            command: string,
            param: specific command parameters,

        Returns:
            Value of the command execution result if exist
        Examples:
            >>> self.cao_controller.execute(RobotExecuteEnum.Motor, [1, 0])
        """
        self.controller_execute = ControllerExecute(self.cao_controller)
        return self.controller_execute.execute(command, param)

    def get_attribute(self):
        """
        Get the controller attribute specified in the AddController method of the CaoWorkspace class.

        THIS METHOD IS NOT WORKING!

        Returns:
            cao_controller attribute - string
        """
        raise RuntimeError("THIS METHOD IS NOT WORKING!")
        return self.cao_controller.Attribute

    def get_help(self):
        """
        Get the controller help specified in the AddController method of the CaoWorkspace class.

        THIS METHOD IS NOT WORKING!

        Returns:
            cao_controller help - string
        """
        raise RuntimeError("THIS METHOD IS NOT WORKING!")
        return self.cao_controller.Help

    def get_name(self):
        """
        Get the controller name specified in the AddController method of the CaoWorkspace class.

        Returns:
            cao_controller name - string
        Examples:
            >>> cao_controller_name = self.cao_controller.get_name()
        """
        return self.cao_controller.Name

    def get_tag(self):
        """
        Get the controller tag specified in the AddController method of the CaoWorkspace class.
        Returns:
            cao_controller tag - string
        Examples:
            >>> cao_controller_tag = self.cao_controller.get_tag()
        """
        return self.cao_controller.Tag

    def put_tag(self, new_value):
        """
        Put the controller tag specified in the AddController method of the CaoWorkspace class.
        Args:
            new_value: value,
        Returns:
            ...
        Examples:
            >>> self.cao_controller.put_tag("new_tag")
        """
        self.cao_controller.Tag = new_value

    def get_id(self):
        """
        Get the controller ID specified in the AddController method of the CaoWorkspace class.
        Returns:
            cao_controller ID - string
        Examples:
            >>> cao_controller_id = self.cao_controller.get_id()
        """
        return self.cao_controller.ID

    def put_id(self, new_value):
        """
        Put the controller ID specified in the AddController method of the CaoWorkspace class.
        Args:
            new_value: value,
        Returns:
            ...
        Examples:
            >>> self.cao_controller.put_id("new_id")
        """
        self.cao_controller.ID = new_value

    # TODO: Testar a partir daqui
    def get_message(self):
        """
        Get a specified message.
        Returns:
            message in string format
        """
        return self.cao_controller.GetMessage()

    def on_message(self):
        """
        Get the OnMessage event of the CaoController class.
        Returns:
            ...
        """
        return self.cao_controller.OnMessage

    def get_variables(self):
        """
        Get the Variables property of the CaoController class. Acquisition of a variable collection.
        Returns:
            variable collection
        """
        return self.cao_controller.Variables

    def get_tasks(self):
        """
        Get the Tasks property of the CaoController class. Acquisition of a task collection.
        Returns:
            tasks collection
        """
        return self.cao_controller.Tasks

    def get_robots(self):
        """
        Get the Robots property of the CaoController class. Acquisition of a robot collection.
        Returns:
            robot collection
        """
        return self.cao_controller.Robots

    def get_files(self):
        """
        Get the Files property of the CaoController class. Acquisition of a file collection.
        Returns:
            files collection
        """
        return self.cao_controller.Files

    def get_extensions(self):
        """
        Get the Extensions property of the CaoController class. Acquisition of an extension collection.
        Returns:
            extension collection
        """
        return self.cao_controller.Extensions

    def get_commands(self):
        """
        Get the Commands property of the CaoController class.
        Acquisition of a command collection.
        Returns:
            commands collection
        """
        return self.cao_controller.Commands

    def get_index(self):
        """
        Get the Index property of the CaoController class. Acquisition of controller index.
        Returns:
            controller index
        """
        return self.cao_controller.Index
