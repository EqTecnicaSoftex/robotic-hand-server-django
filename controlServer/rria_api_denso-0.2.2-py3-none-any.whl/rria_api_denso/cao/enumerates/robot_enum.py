from enum import Enum


class RobotExecuteEnum(Enum):
    """Enum for robot execution"""

    # Operation
    TMul = 1
    TInv = 2
    TNorm = 3
    J2T = 4
    T2J = 5
    J2P = 6
    P2J = 7
    T2P = 8
    P2T = 9
    Dev = 10
    DevH = 11
    OutRange = 12
    MPS = 13
    RPM = 14
    DPS = 15

    # Positioning
    CurPos = 16
    DestPos = 17
    CurJnt = 18
    DestJnt = 19
    CurTrn = 20
    DestTrn = 21
    CurFig = 22
    CurPosEx = 23
    DestPosEx = 24
    HighCurPosEx = 25
    CurJntEx = 26
    DestJntEx = 27
    HighCurJntEx = 28
    CurTrnEx = 29
    DestTrnEx = 30
    HighCurTrnEx = 31

    # Speed
    SpeedMode = 32
    CurSpd = 33
    CurAcc = 34
    CurDec = 35
    CurJSpd = 36
    CurJAcc = 37
    CurJDec = 38

    # Log
    StartLog = 39
    StopLog = 40
    ClearLog = 41
    StartServoLog = 42
    ClearServoLog = 43
    StopServoLog = 44
    GetCtrlLogMaxTime = 45
    SetCtrlLogMaxTime = 46
    GetCtrlLogInterval = 47
    SetCtrlLogInterval = 48
    GetLogCount = 49
    GetLogRecord = 50

    # Robot operation
    Motor = 51
    ExtSpeed = 52
    TakeArm = 53
    GiveArm = 54
    Draw = 55
    Approach = 56
    Depart = 57
    DriveEx = 58
    DriveAEx = 59
    RotateH = 60
    Arrive = 61
    MotionSkip = 62
    MotionComplete = 63
    ArchMove = 64

    # Tool
    CurTool = 65
    GetToolDef = 66
    SetToolDef = 67

    # Work
    CurWork = 68
    GetWorkDef = 69
    SetWorkDef = 70
    WorkAttribute = 71

    # Base
    SetBaseDef = 72
    GetBaseDef = 73

    # Area
    GetAreaDef = 74
    SetAreaDef = 75
    SetArea = 76
    ResetArea = 77
    AreaSize = 78
    GetAreaEnabled = 79
    SetAreaEnabled = 80

    # Spline
    AddPathPoint = 81
    ClrPathPoint = 82
    GetPathPoint = 83
    LoadPathPoint = 84
    GetPathPointCount = 85

    # Force Controll
    ForceCtrl = 86
    ForceParam = 87
    ForceValue = 88
    ForceWaitCondition = 89
    ForceSensor = 90
    ForceChangeTable = 91
    CurForceParam = 92

    # Cooperative Control Function
    SyncTimeStart = 93
    SyncTimeEnd = 94
    SyncMoveStart = 95
    SyncMoveEnd = 96
    SetHandIO = 97
    GetHandIO = 98

    # Exclusive Control of Robot
    ExclusiveArea = 99
    SetExclusiveArea = 100
    ResetExclusiveArea = 101
    ExclusiveControlStatus = 102

    # Accuracy
    CrtMotionAllow = 103
    EncMotionAllow = 104
    EncMotionAllowJnt = 105
    HighPathAccuracy = 106

    # Status/Value Obtainment
    GetSrvData = 107
    GetSrvJntData = 108
    GetAllSrvData = 109
    RobInfo = 110

    # Settings of Functions and Conditions
    GrvCtrl = 111
    GrvOffset = 112
    MotionTimeout = 113
    ErAlw = 114
    PayLoad = 115
    SingularAvoid = 116

    # Current Limit
    CurLmt = 117
    Zforce = 118

    # Coordination with Position, Motion and I/O
    DetectOn = 119
    DetectOff = 120
    AngularTrigger = 121

    # Virtual Fence
    VirtualFence = 122

    # Misc
    GetRobotTypeName = 123
    GetPluralServoData = 124
    GenerateNonStopPath = 125

    # external speed
    CurExtSpd = 126
    CurExtAcc = 127
    CurExtDec = 128

    def __str__(self) -> str:
        full_name = super().__str__()
        scope_name = full_name.split(".")[-1]
        return scope_name


def main():
    """Main function"""
    print(RobotExecuteEnum.TMul)


if __name__ == "__main__":
    main()
