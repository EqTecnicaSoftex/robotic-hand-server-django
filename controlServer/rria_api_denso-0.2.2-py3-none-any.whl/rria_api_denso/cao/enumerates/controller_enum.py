from enum import Enum


class ControllerExecuteEnum(Enum):
    """Enum for controller execution"""

    ClearError = 1
    GetErrorDescription = 2
    GetCurErrorCount = 3
    GetCurErrorInfo = 4
    KillAll = 5
    SuspendAll = 6
    StepStopAll = 7
    ContinueStartAll = 8
    KillAllTsr = 9
    RunAllTsr = 10
    GetErrorLogCount = 11
    GetErrorLog = 12
    GetOprLogCount = 13
    GetOprLog = 14
    GetPublicValue = 15
    SetPublicValue = 16
    SysState = 17
    SysInfo = 18
    SetAllDummyIO = 19

    def __str__(self) -> str:
        full_name = super().__str__()
        scope_name = full_name.split(".")[-1]
        return scope_name
