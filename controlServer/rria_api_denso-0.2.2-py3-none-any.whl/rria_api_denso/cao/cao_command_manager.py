class CAOCommandManager:
    """
    This class contains methods for manipulate the CAOCommand object. CAOCommand is responsible for creating the
    CAOCommand object.

    From the CaoController object, it is possible to use all the other related methods.
    """

    def __init__(self, cao_command):
        self.cao_command = cao_command

    def execute(self, mode):
        """
        Execute the command.
        Args:
            mode: mode of execution
        """
        self.cao_command.Execute(mode)

    def cancel(self):
        """
        Cancel the command.
        """
        self.cao_command.Cancel()

    def get_timeout(self):
        """
        The Timeout property returns the timeout period of the command.
        Returns:
            CAOCommand Timeout: Timeout period
        """
        return self.cao_command.Timeout

    def put_timeout(self, new_value):
        """
        The Timeout property sets the timeout period of the command.
        Args:
            new_value: new timeout period
        """
        self.cao_command.Timeout = new_value

    def get_state(self):
        """
        The State property returns the state of the command.
        Returns:
            CAOCommand State: State of the command
        """
        return self.cao_command.State

    def get_parameters(self):
        """
        The Parameters property returns the parameters of the command.
        Returns:
            CAOCommand Parameters: Parameters of the command
        """
        return self.cao_command.Parameters

    def put_parameters(self, new_value):
        """
        The Parameters property sets the parameters of the command.
        Args:
            new_value: new parameters of the command
        """
        self.cao_command.Parameters = new_value

    def get_result(self):
        """
        The Result property returns the result of the command.
        Returns:
            CAOCommand Result: Result of the command
        """
        return self.cao_command.Result

    def get_attribute(self):
        """
        The Attribute property returns the attribute of the command.
        Returns:
            CAOCommand Attribute: Attribute of the command
        """
        return self.cao_command.Attribute

    def get_help(self):
        """
        The Help property returns the help of the command.
        Returns:
            CAOCommand Help: Help of the command
        """
        return self.cao_command.Help

    def get_name(self):
        """
        The Name property returns the name of the command.
        Returns:
            CAOCommand Name: Name of the command
        """
        return self.cao_command.Name

    def get_tag(self):
        """
        The Tag property returns the tag of the command.
        Returns:
            CAOCommand Tag: Tag of the command
        """
        return self.cao_command.Tag

    def put_tag(self, new_value):
        """
        The Tag property sets the tag of the command.
        Args:
            new_value: new tag of the command
        """
        self.cao_command.Tag = new_value

    def get_id(self):
        """
        The ID property returns the id of the command.
        Returns:
            CAOCommand ID: ID of the command
        """
        return self.cao_command.Id

    def put_id(self, new_value):
        """
        The ID property sets the id of the command.
        Args:
            new_value: new id of the command
        """
        self.cao_command.Id = new_value

    def get_index(self):
        """
        The Index property returns the index of the command.
        Returns:
            CAOCommand Index: Index of the command
        """
        return self.cao_command.Index
