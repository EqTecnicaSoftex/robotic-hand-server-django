class CAOFileManager:
    """
    This class contains methods for manipulate the CAOFile object. CaoFile is responsible for creating the CaoFile
    object.

    From the CaoController object, it is possible to use all the other related methods.
    """

    def __init__(self, cao_file):
        self.cao_file = cao_file

    def add_file(self, name, option=""):
        """
        The AddFile method creates a new file in the controller. The file is created in the current directory of the
        file.

        This method is not tested.

        Args:
            name: string,
            option: string,

        Returns:
            CAOFile: CAOFile object
        """
        return self.cao_file.Add(name, option)

    def add_variable(self, name, option=""):
        """
        The AddVariable method creates a new CAOVariable object from manipulate a variable.
        Args:
            name: string,
            option: string,

        Returns:
            CAOVariable: CAOVariable object
        """
        return self.cao_file.AddVariable(name, option)

    def get_file_names(self):
        """
        The FileNames property returns a collection names of the files that are registered in the controller.
        Returns:
            CAOFile FileNames: Files list
        """
        return self.cao_file.FileNames

    def get_variable_names(self):
        """
        The VariableNames property returns a collection names of the variables that are registered in the controller.
        Returns:
            CAOFile VariableNames: Variables list
        """
        return self.cao_file.VariableNames

    def execute(self, command, param=None):
        """
        The Execute method executes the specified command in the controller.
        Args:
            command: string,
            param: string,

        Returns:
            CAOFile Execute: Execute command
        """
        return self.cao_file.Execute(command, param)

    def copy(self, name, option=""):
        """
        The Copy method copies the file to the specified destination.
        Args:
            name: string,
            option: string,
        """
        self.cao_file.Copy(name, option)

    def delete(self, option=""):
        """
        The Delete method deletes the file.
        Args:
            option: string,
        """
        self.cao_file.Delete(option)

    def move(self, name, option=""):
        """
        The Move method moves the file to the specified destination.
        Args:
            name: string,
            option: string,
        """
        self.cao_file.Move(name, option)

    def run(self, option=""):
        """
        The Run method runs the file.
        Args:
            option: string,
        """
        return self.cao_file.Run(option)

    def get_date_created(self):
        """
        The DateCreated property returns the date and time when the file was created.
        Returns:
            CAOFile DateCreated: Date created
        """
        return self.cao_file.DateCreated

    def get_date_last_accessed(self):
        """
        The DateLastAccessed property returns the date and time when the file was last accessed.
        Returns:
            CAOFile DateLastAccessed: Date last accessed
        """
        return self.cao_file.DateLastAccessed

    def get_date_last_modified(self):
        """
        The DateLastModified property returns the date and time when the file was last modified.
        Returns:
            CAOFile DateLastModified: Date last modified
        """
        return self.cao_file.DateLastModified

    def get_path(self):
        """
        The Path property returns the path of the file.
        Returns:
            CAOFile Path: Path of file
        """
        return self.cao_file.Path

    def get_size(self):
        """
        The Size property returns the size of the file.
        Returns:
            CAOFile Size: Size of file
        """
        return self.cao_file.Size

    # Não funcionou!
    def get_type(self):
        """
        The Type property returns the type of the file.
        Returns:
            CAOFile Type: Type of file
        """
        return self.cao_file.Type

    def get_value(self):
        """
        The Value property returns the content of the file.
        Returns:
            CAOFile Value: Content of all files
        """
        return self.cao_file.Value

    def put_value(self, new_value):
        """
        The put_Value property sets the content of the file. This method puts the new value in the file based on the
        value passed as a parameter. This method completely replaces the contents of the file.

        Args:
            new_value: string,
        """
        self.cao_file.Value = new_value

    def get_attribute(self):
        """
        The Attribute property returns the attributes of the file.
        Returns:
            CAOFile Attribute: Attributes of file
        """
        return self.cao_file.Attribute

    def get_help(self):
        """
        The Help property returns the help.
        Returns:
            CAOFile Help: Help
        """
        return self.cao_file.Help

    def get_name(self):
        """
        The Name property returns the name of the file.
        Returns:
            CAOFile Name: Name of file
        """
        return self.cao_file.Name

    def get_tag(self):
        """
        The Tag property returns the tag of the file.
        Returns:
            CAOFile Tag: Tag of file
        """
        return self.cao_file.Tag

    def put_tag(self, new_value):
        """
        The put_Tag property sets the tag of the file.
        Args:
            new_value:
        """
        self.cao_file.Tag = new_value

    def get_id(self):
        """
        The ID property returns the identifier of the file.
        Returns:
            CAOFile ID: ID of file
        """
        return self.cao_file.ID

    # Não funcionou!
    def put_id(self, new_value):
        """
        The put_ID property sets the identifier of the file.

        THIS METHOD IS NOT WORKING!
        """
        self.cao_file.ID = new_value

    # TODO: Testar a partir daqui!
    def get_files(self):
        """
        The Files property returns a collection of the files that are registered in the controller.
        Returns:
            CAOFile Files: Files list
        """
        return self.cao_file.Files

    def get_index(self):
        """
        The Index property returns the index of the file in the collection of files that are registered in the
        controller.
        Returns:
            CAOFile Index: Index of file
        """
        return self.cao_file.Index

    def get_variables(self):
        """
        The Variables property returns a collection of the variables that are registered in the specific file.
        Returns:
            CAOFile Variables: Variables list
        """
        return self.cao_file.Variables
