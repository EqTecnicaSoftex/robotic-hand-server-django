from dataclasses import asdict, dataclass

from rria_api_denso.utils.constants import MoveType


@dataclass
class RobotCartesianCommand:
    """
    This class is a data class that represents a robot cartesian command.
    """

    type: MoveType = MoveType.CARTESIAN
    x: float = 0
    y: float = 0
    z: float = 0
    rx: float = 0
    ry: float = 0
    rz: float = 0
    fig: int = 0

    # parse to or from
    def __init__(self, x: float, y: float, z: float, rx: float, ry: float, rz: float, fig: int):
        RobotCartesianCommand.__validate_types(x, y, z, rx, ry, rz, fig)
        self.x = x
        self.y = y
        self.z = z
        self.rx = rx
        self.ry = ry
        self.rz = rz
        self.fig = fig

    @staticmethod
    def from_dict(data_dict):
        try:
            return RobotCartesianCommand(
                data_dict["x"],
                data_dict["y"],
                data_dict["z"],
                data_dict["rx"],
                data_dict["ry"],
                data_dict["rz"],
                data_dict["fig"],
            )
        except Exception as e:
            print(e)
            return None

    @staticmethod
    def from_list(data_list):
        try:
            return RobotCartesianCommand(
                data_list[0], data_list[1], data_list[2], data_list[3], data_list[4], data_list[5], data_list[6]
            )
        except Exception as e:
            print(e)
            return None

    def to_list(self):
        return [self.x, self.y, self.z, self.rx, self.ry, self.rz]

    # built-in operators
    def __iter__(self):
        return iter(asdict(self).items())

    def __add__(self, other):
        self.x += other.x
        self.y += other.y
        self.z += other.z
        self.rx += other.rx
        self.ry += other.ry
        self.rz += other.rz

        return self

    def __sub__(self, other):
        self.x -= other.x
        self.y -= other.y
        self.z -= other.z
        self.rx -= other.rx
        self.ry -= other.ry
        self.rz -= other.rz

        return self

    def __eq__(self, other):
        return (
            self.x == other.x
            and self.y == other.y
            and self.z == other.z
            and self.rx == other.rx
            and self.ry == other.ry
            and self.rz == other.rz
            and self.fig == other.fig
        )

    def __getitem__(self, key):
        return getattr(self, key)

    def __setitem__(self, key, value):
        setattr(self, key, value)

    # Utils
    @staticmethod
    def __validate_types(x, y, z, rx, ry, rz, fig):
        axis_values = [x, y, z, rx, ry, rz]

        for val in axis_values:
            if not isinstance(val, float) and not isinstance(val, int):
                raise ValueError("Expected type float or int for axis, but was received:", type(val))

        if not isinstance(fig, int):
            raise ValueError("Expected type int for figure, but was received:", type(fig))
