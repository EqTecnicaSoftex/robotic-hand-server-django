from rria_api_denso.utils.utils import get_system_installed_softwares


def install_check_denso_library() -> bool:
    software_list = get_system_installed_softwares()

    orin_sdk_info = [
        x for x in software_list if ("ORiN2 SDK" in x["name"] and "DENSO WAVE INCORPORATED" in x["publisher"])
    ]

    return len(orin_sdk_info) > 0
