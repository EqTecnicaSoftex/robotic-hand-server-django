"""
This module contains all enums used in the system.
"""
from enum import Enum, auto


class MoveType(Enum):
    JOINT = auto()
    CARTESIAN = auto()
