from dataclasses import asdict, dataclass

from rria_api_denso.utils.constants import MoveType


@dataclass
class RobotJointCommand:
    """
    This class is a data class that represents a robot joint command.
    """

    type: MoveType = MoveType.JOINT
    joint_1: float = 0
    joint_2: float = 0
    joint_3: float = 0
    joint_4: float = 0
    joint_5: float = 0
    joint_6: float = 0

    # parse to or from
    def __init__(self, j1, j2, j3, j4, j5, j6):
        RobotJointCommand.__validate_types(j1, j2, j3, j4, j5, j6)
        self.joint_1 = j1
        self.joint_2 = j2
        self.joint_3 = j3
        self.joint_4 = j4
        self.joint_5 = j5
        self.joint_6 = j6

    @staticmethod
    def from_dict(data_dict):
        try:
            return RobotJointCommand(
                data_dict["joint_1"],
                data_dict["joint_2"],
                data_dict["joint_3"],
                data_dict["joint_4"],
                data_dict["joint_5"],
                data_dict["joint_6"],
            )
        except Exception as e:
            print(e)
            return None

    @staticmethod
    def from_list(data_list):
        try:
            return RobotJointCommand(data_list[0], data_list[1], data_list[2], data_list[3], data_list[4], data_list[5])
        except Exception as e:
            print(e)
            return None

    def to_list(self):
        return [self.joint_1, self.joint_2, self.joint_3, self.joint_4, self.joint_5, self.joint_6]

    # built-in operators
    def __iter__(self):
        return iter(asdict(self).items())

    def __add__(self, other):
        self.joint_1 += other.joint_1
        self.joint_2 += other.joint_2
        self.joint_3 += other.joint_3
        self.joint_4 += other.joint_4
        self.joint_5 += other.joint_5
        self.joint_6 += other.joint_6

        return self

    def __sub__(self, other):
        self.joint_1 -= other.joint_1
        self.joint_2 -= other.joint_2
        self.joint_3 -= other.joint_3
        self.joint_4 -= other.joint_4
        self.joint_5 -= other.joint_5
        self.joint_6 -= other.joint_6

        return self

    def __eq__(self, other):
        return (
            self.joint_1 == other.joint_1
            and self.joint_2 == other.joint_2
            and self.joint_3 == other.joint_3
            and self.joint_4 == other.joint_4
            and self.joint_5 == other.joint_5
            and self.joint_6 == other.joint_6
        )

    def __getitem__(self, key):
        return getattr(self, key)

    def __setitem__(self, key, value):
        setattr(self, key, value)

    # Utils
    @staticmethod
    def __validate_types(j1, j2, j3, j4, j5, j6):
        axis_values = [j1, j2, j3, j4, j5, j6]

        for val in axis_values:
            if not isinstance(val, float) and not isinstance(val, int):
                raise ValueError("Expected type float or int for axis, but was received:", type(val))
