from rria_api_denso.cao import CAOEngineObject, CAOWorkspace, ControllerExecuteEnum, RobotExecuteEnum
from rria_api_denso.cao.exceptions.cao.exception_builder import ControllerExceptionBuilder
from rria_api_denso.cao.exceptions.denso_exception_handler import DensoExceptionHandler
from rria_api_denso.utils import MoveType, RobotCartesianCommand, RobotJointCommand


class DensoRobotAPI:
    def __init__(self, workspace_name, control_name, options):
        self.__cao_engine = None
        self.__cao_workspace = None
        self.__cao_controller = None
        self.__cao_robot = None
        self.__motor_enabled = False
        self.__connected = False

        self.__WORKSPACE_NAME = workspace_name
        self.__CONTROLLER_NAME = control_name
        self.__PROVIDER_NAME = "CaoProv.DENSO.RC8"
        self.__OPTIONS = options

    def is_connected(self) -> bool:
        return self.__connected

    def motor_enabled(self) -> bool:
        return self.__motor_enabled

    def remove_workspace(self):
        names = self.__cao_engine.get_workspaces_names()
        for i in range(len(names)):
            if names[i] == self.__WORKSPACE_NAME:
                self.__cao_engine.workspace_remove(i)

    def connect(self) -> bool:
        try:
            self.__cao_engine = CAOEngineObject()
            self.__cao_workspace = CAOWorkspace(self.__cao_engine.get_dcom_dispatch(), self.__WORKSPACE_NAME)
            self.__cao_controller = self.__cao_workspace.add_controller(
                controller_name=self.__CONTROLLER_NAME,
                provider_name=self.__PROVIDER_NAME,
                machine_name="",
                option=self.__OPTIONS,
            )
            self.__cao_robot = self.__cao_controller.controller_add_robot("Arm", "")
            self.__connected = True
            return True

        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def disconnect(self) -> bool:
        try:
            self.__cao_workspace.remove_controller(self.__cao_controller.get_index())
            self.__cao_engine.workspace_remove(self.__cao_workspace.get_index())
            self.__connected = False
            del self.__cao_robot
            del self.__cao_controller
            del self.__cao_workspace

            return True

        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def motor_on(self) -> bool:
        if self.__connected:
            try:
                self.__cao_robot.execute(RobotExecuteEnum.TakeArm, [0, 0])
                self.__cao_robot.execute(RobotExecuteEnum.Motor, [1, 0])
                self.__motor_enabled = True
                return True

            except Exception as e:
                self.__cao_robot.execute(RobotExecuteEnum.GiveArm, None)
                raise DensoExceptionHandler(e.args)
        else:
            print("Robot not connected")
            return False

    def motor_off(self) -> bool:
        if self.__connected:
            if not self.__motor_enabled:
                print("Motor not enabled to turn off")
                return False

            try:
                self.__cao_robot.execute(RobotExecuteEnum.Motor, [0, 0])
                self.__cao_robot.execute(RobotExecuteEnum.GiveArm, None)
                self.__motor_enabled = False
                return True

            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            print("Robot not connected")
            return False

    def move_joints(self, command: RobotJointCommand) -> bool:
        if isinstance(command, RobotJointCommand):
            if not self.__connected or not self.__motor_enabled:
                print("Robot or motor not started")
                return False

            try:
                self.__cao_robot.move(
                    1,
                    [
                        [
                            command.joint_1,
                            command.joint_2,
                            command.joint_3,
                            command.joint_4,
                            command.joint_5,
                            command.joint_6,
                        ],
                        "J",
                        "@E",
                    ],
                    "",
                )

                return True

            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            print("Expected RobotCartesianCommand, but was received:", type(command))
            return False

    def move_cartesian(self, command: RobotCartesianCommand) -> bool:
        if isinstance(command, RobotCartesianCommand):
            if not self.__connected or not self.__motor_enabled:
                print("Robot or motor not started")
                return False

            try:
                self.__cao_robot.move(
                    1,
                    [[command.x, command.y, command.z, command.rx, command.ry, command.rz, command.fig], "P", "@E"],
                    "",
                )

                return True

            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            print("Expected RobotCartesianCommand, but was received:", type(command))
            return False

    def move_tool_z(self, z_step: float) -> bool:
        if isinstance(z_step, float) or isinstance(z_step, int):
            if not self.__connected or not self.__motor_enabled:
                print("Robot or motor not started")
                return False

            try:
                self.__cao_robot.execute(RobotExecuteEnum.Depart, [1, "@P " + str(z_step)])

                return True

            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            print("Expected float, but was received:", type(z_step))
            return False

    def get_joints_pose(self) -> RobotJointCommand | None:
        if not self.__connected:
            print("Robot not connected")
            return None

        try:
            joints = self.__cao_robot.execute(RobotExecuteEnum.CurJnt, [])

            return RobotJointCommand(joints[0], joints[1], joints[2], joints[3], joints[4], joints[5])

        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def get_cartesian_pose(self) -> RobotCartesianCommand | None:
        if not self.__connected:
            print("Robot not connected")
            return None

        try:
            pose = self.__cao_robot.execute(RobotExecuteEnum.CurPos, [])

            return RobotCartesianCommand(pose[0], pose[1], pose[2], pose[3], pose[4], pose[5], int(pose[6]))

        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def set_arm_speed(self, speed, accel, decel) -> bool:
        param_list = [speed, accel, decel]

        if DensoRobotAPI.__validate_numeric_type(param_list) and DensoRobotAPI.__in_numeric_range(param_list, 1, 100):
            try:
                self.__cao_robot.execute(RobotExecuteEnum.ExtSpeed, param_list)
                return True
            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            return False

    def get_current_arm_speed(self) -> tuple | None:
        if not self.__connected:
            print("Robot not connected")
            return None

        try:
            speed = self.__cao_robot.execute(RobotExecuteEnum.CurExtSpd, 0)
            accel = self.__cao_robot.execute(RobotExecuteEnum.CurExtAcc, 0)
            decel = self.__cao_robot.execute(RobotExecuteEnum.CurExtDec, 0)
            return speed, accel, decel

        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def emergency_stop(self) -> bool:
        if not self.__connected:
            print("Robot not connected")
            return False

        try:
            self.__cao_controller.execute(ControllerExecuteEnum.SuspendAll)
            self.__cao_controller.execute(ControllerExecuteEnum.KillAll)
            return True
        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def clear_faults(self) -> bool:
        if not self.__connected:
            print("Robot not connected")
            return False

        try:
            self.__cao_controller.execute(ControllerExecuteEnum.ClearError)
            return True
        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def get_current_error(self):
        if not self.__connected:
            print("Robot not connected")
            return None

        try:
            if self.__cao_controller.execute(ControllerExecuteEnum.GetCurErrorCount) > 0:
                tuple_details = self.__cao_controller.execute(ControllerExecuteEnum.GetCurErrorInfo, 0)
                return ControllerExceptionBuilder(tuple_details[0])
        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def get_current_fig(self) -> int | None:
        if not self.__connected:
            print("Robot not connected")
            return None

        try:
            return self.__cao_robot.execute(RobotExecuteEnum.CurFig, [])
        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def is_out_of_range(self, robot_command: RobotCartesianCommand | RobotJointCommand) -> bool | None:
        if isinstance(robot_command, RobotCartesianCommand) or isinstance(robot_command, RobotJointCommand):
            if not self.__connected:
                print("Robot not connected")
                return None

            try:
                str_comm = ""
                if robot_command.type == MoveType.JOINT:
                    str_comm = (
                        "J("
                        + str(robot_command.joint_1)
                        + ","
                        + str(robot_command.joint_2)
                        + ","
                        + str(robot_command.joint_3)
                        + ","
                        + str(robot_command.joint_4)
                        + ","
                        + str(robot_command.joint_5)
                        + ","
                        + str(robot_command.joint_6)
                        + ")"
                    )
                else:
                    str_comm = (
                        "P("
                        + str(robot_command.x)
                        + ","
                        + str(robot_command.y)
                        + ","
                        + str(robot_command.z)
                        + ","
                        + str(robot_command.rx)
                        + ","
                        + str(robot_command.ry)
                        + ","
                        + str(robot_command.rz)
                        + ","
                        + str(int(robot_command.fig))
                        + ")"
                    )

                res = self.__cao_robot.execute(RobotExecuteEnum.OutRange, str_comm)
                return res != 0
            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            print("Expected Robot command types, but was received:", type(robot_command))
            return None

    def joint_to_cartesian(self, command: RobotJointCommand) -> RobotCartesianCommand | None:
        if isinstance(command, RobotJointCommand):
            if not self.__connected:
                print("Robot not connected")
                return None

            try:
                str_comm = (
                    "J("
                    + str(command.joint_1)
                    + ","
                    + str(command.joint_2)
                    + ","
                    + str(command.joint_3)
                    + ","
                    + str(command.joint_4)
                    + ","
                    + str(command.joint_5)
                    + ","
                    + str(command.joint_6)
                    + ")"
                )

                pose = self.__cao_robot.execute(RobotExecuteEnum.J2P, str_comm)

                return RobotCartesianCommand(pose[0], pose[1], pose[2], pose[3], pose[4], pose[5], int(pose[6]))
            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            print("Expected RobotJointCommand, but was received:", type(command))
            return None

    def cartesian_to_joint(self, command: RobotCartesianCommand) -> RobotJointCommand | None:
        if isinstance(command, RobotCartesianCommand):
            try:
                str_comm = (
                    "P("
                    + str(command.x)
                    + ","
                    + str(command.y)
                    + ","
                    + str(command.y)
                    + ","
                    + str(command.rx)
                    + ","
                    + str(command.ry)
                    + ","
                    + str(command.rz)
                    + ")"
                )

                joints = self.__cao_robot.execute(RobotExecuteEnum.P2J, str_comm)

                return RobotJointCommand(joints[0], joints[1], joints[2], joints[3], joints[4], joints[5])
            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            print("Expected RobotCartesianCommand, but was received:", type(command))

    @staticmethod
    def __validate_numeric_type(value_list):
        for val in value_list:
            if not isinstance(val, float) and not isinstance(val, int):
                print("Expected float or int, but was received:", type(val))
                return False

        return True

    @staticmethod
    def __in_numeric_range(value_list, range_min, range_max):
        for val in value_list:
            if not (range_min < val and val < range_max):
                print(
                    "Expected values between range [" + str(range_min) + ", " + str(range_max) + "] but was received:",
                    val,
                )
                return False

        return True
